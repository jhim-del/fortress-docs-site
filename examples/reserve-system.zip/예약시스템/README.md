# 공공시설 통합예약

시민체육관·구민회관·청소년수련관·평생학습관 시설 온라인 예약 서버 (2023-12 오픈, 2.x)

## 실행

    set RESERVE_ENV=prod
    python run_server.py

- 기본 포트 8080. 프론트(정적 파일)는 IIS 에서 따로 서비스, 여기는 /api 만 받음
- DB 경로 바꿀 때 `set RESERVE_DB=D:\reserve\db\reserve.sqlite`
- 로그: `logs\app.log`, 문자 발송 기록 `logs\sms_outbox.log`

## 테스트

    python -m unittest

외부 패키지 없음 (Python 3.10 이상, 표준 라이브러리만). 운영 서버가 폐쇄망이라 pip 설치 안 됨.

## 배포

1. 운영 서버 `D:\reserve` 에 소스 복사 (db 폴더 제외!! 덮어쓰면 안 됨)
2. `nssm restart reserve`
3. /api/facilities 호출해서 응답 오는지 확인

- 배치: 작업 스케줄러 매일 02:00 `python scripts\daily_batch.py`
- 공휴일: 매년 1월 `python scripts\load_holidays.py holidays_YYYY.csv` (대체공휴일·선거일 빠졌는지 확인)
- DB 백업: 02:30 `D:\backup\reserve\` (서버 작업 스케줄러, 7일 보관)

## 메모

- 요금 바뀌면 `reserve/config.py` FEE_TABLE 수정 (시설 테이블에 요금 없음)
- 환불은 PG 관리자 화면에서 처리, DB 에는 안 남음
- 공사·행사로 시설 막을 때는 관리자 화면에서 STAFF 계정으로 예약 잡아 둠
- 변경 내역은 CHANGES.txt
