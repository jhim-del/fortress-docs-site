"""운영 서버 기동 (nssm 서비스 'reserve' 가 이 파일을 실행)"""
import logging
import os
from wsgiref.simple_server import make_server

from reserve import config, db, holiday
from reserve.web import application


def main():
    os.makedirs(config.LOG_DIR, exist_ok=True)
    logging.basicConfig(
        filename=os.path.join(config.LOG_DIR, "app.log"),
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
        encoding="utf-8",
    )
    holiday.load(db.get_conn())
    httpd = make_server(config.HTTP_HOST, config.HTTP_PORT, application)
    logging.getLogger("reserve").info("start %s:%s env=%s", config.HTTP_HOST, config.HTTP_PORT, config.ENV)
    httpd.serve_forever()


if __name__ == "__main__":
    main()
