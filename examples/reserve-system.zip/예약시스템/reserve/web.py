"""HTTP API (wsgiref)

프론트(정적 파일)는 IIS 에서 따로 서비스하고, 여기는 /api 만 받는다.
"""
import json
import logging
import re
import traceback
from datetime import date
from urllib.parse import parse_qs

from . import admin, config, db, export, facility, payment, reservation, stats
from .validators import ValidationError

log = logging.getLogger("reserve.web")

_routes = []

ERROR_MESSAGE = "일시적인 오류가 발생했습니다. 잠시 후 다시 시도해 주세요."


def route(method, pattern, admin_only=False):
    def deco(fn):
        _routes.append((method, re.compile("^" + pattern + "$"), fn, admin_only))
        return fn
    return deco


def _json(start_response, status, body):
    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    start_response(status, [("Content-Type", "application/json; charset=utf-8"),
                            ("Content-Length", str(len(data)))])
    return [data]


def _body(environ):
    try:
        size = int(environ.get("CONTENT_LENGTH") or 0)
    except ValueError:
        size = 0
    raw = environ["wsgi.input"].read(size) if size else b""
    return json.loads(raw.decode("utf-8") or "{}")


def _ym(q):
    ym = q.get("ym") or date.today().strftime("%Y-%m")
    return int(ym[:4]), int(ym[5:7])


@route("GET", r"/api/facilities")
def api_facilities(env, q):
    rows = facility.list_facilities(db.get_conn(), q.get("category"))
    return [dict(r) for r in rows]


@route("GET", r"/api/facilities/(\d+)/available")
def api_available(env, q, facility_id):
    year, month = _ym(q)
    conn = db.get_conn()
    booked = reservation.booked_days(conn, int(facility_id), year, month)
    days = reservation.available_dates(year, month, booked)
    today = date.today()
    return {"facility_id": int(facility_id), "ym": "%04d-%02d" % (year, month),
            "dates": [d.isoformat() for d in days if d > today]}


@route("GET", r"/api/facilities/(\d+)/slots")
def api_slots(env, q, facility_id):
    return {"date": q.get("date"),
            "free": reservation.free_slots(db.get_conn(), int(facility_id), q.get("date"))}


@route("POST", r"/api/reservations")
def api_create(env, q):
    b = _body(env)
    rid = reservation.create_reservation(db.get_conn(), int(b["facility_id"]), int(b["member_id"]),
                                         b["reserve_date"], int(b["start_hour"]), int(b["hours"]))
    return {"reserve_id": rid}


@route("POST", r"/api/reservations/(\d+)/cancel")
def api_cancel(env, q, reserve_id):
    return {"canceled": reservation.cancel(db.get_conn(), int(reserve_id))}


@route("POST", r"/api/payments/callback")
def api_pay_callback(env, q):
    # pg_agent 가 승인 후 호출 (내부망)
    b = _body(env)
    pay_id = payment.pay(db.get_conn(), int(b["reserve_id"]), b.get("method", "CARD"), b.get("paid_at"))
    return {"pay_id": pay_id}


@route("GET", r"/api/admin/reservations", admin_only=True)
def api_admin_search(env, q):
    return admin.search_reservations(db.get_conn(), facility_id=q.get("facility_id"),
                                     date_from=q.get("from"), date_to=q.get("to"),
                                     status=q.get("status"))


@route("POST", r"/api/reservations/(\d+)/time")
def api_change_time(env, q, reserve_id):
    b = _body(env)
    return {"changed": reservation.change_time(db.get_conn(), int(reserve_id), int(b["start_hour"]))}


@route("GET", r"/api/members/(\d+)/reservations")
def api_member_reservations(env, q, member_id):
    rows = reservation.list_by_member(db.get_conn(), int(member_id), q.get("all") == "1")
    return [dict(r) for r in rows]


@route("GET", r"/api/admin/export/reservations", admin_only=True)
def api_admin_export(env, q):
    # 파일 응답은 application() 에서 bytes 그대로 내보냄
    return export.reservations_csv(db.get_conn(), q["from"], q["to"], q.get("facility_id"))


@route("GET", r"/api/admin/stats/monthly", admin_only=True)
def api_admin_stats(env, q):
    year, month = _ym(q)
    conn = db.get_conn()
    return {"usage": stats.monthly_usage(conn, year, month),
            "cancel_rate": stats.cancel_rate(conn, year, month),
            "revenue": stats.revenue(conn, year, month)}


def _is_admin(environ):
    ip = environ.get("REMOTE_ADDR", "")
    return any(ip.startswith(p) for p in config.ADMIN_IP_ALLOW)


def application(environ, start_response):
    method = environ.get("REQUEST_METHOD", "GET")
    path = environ.get("PATH_INFO", "")
    q = {k: v[0] for k, v in parse_qs(environ.get("QUERY_STRING", "")).items()}
    for m, rx, fn, admin_only in _routes:
        mt = rx.match(path)
        if not mt or m != method:
            continue
        if admin_only and not _is_admin(environ):
            return _json(start_response, "403 Forbidden", {"result": "FAIL", "message": "권한 없음"})
        try:
            data = fn(environ, q, *mt.groups())
            if isinstance(data, bytes):
                start_response("200 OK", [("Content-Type", "text/csv; charset=utf-8"),
                                          ("Content-Disposition", "attachment; filename=export.csv")])
                return [data]
            return _json(start_response, "200 OK", {"result": "OK", "data": data})
        except (ValidationError, reservation.ReservationError, payment.PaymentError) as e:
            return _json(start_response, "400 Bad Request", {"result": "FAIL", "message": str(e)})
        except Exception:
            log.error("처리 중 오류 %s %s?%s\n%s", method, path, environ.get("QUERY_STRING", ""),
                      traceback.format_exc())
            return _json(start_response, "500 Internal Server Error",
                         {"result": "ERROR", "message": ERROR_MESSAGE})
    return _json(start_response, "404 Not Found", {"result": "FAIL", "message": "not found"})
