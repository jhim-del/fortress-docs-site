# -*- coding: utf-8 -*-
"""운영 설정

운영 서버는 RESERVE_ENV=prod 로 기동한다.
"""
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

ENV = os.environ.get("RESERVE_ENV", "dev")

DB_PATH = os.environ.get("RESERVE_DB", os.path.join(BASE_DIR, "db", "reserve.sqlite"))
LOG_DIR = os.path.join(BASE_DIR, "logs")

HTTP_HOST = "0.0.0.0"
HTTP_PORT = int(os.environ.get("RESERVE_PORT", "8080"))

# ---- 예약 규칙 ----
MAX_HOURS_PER_RESERVATION = 4      # DB CHECK(hours BETWEEN 1 AND 4) 와 맞출 것
MAX_ADVANCE_DAYS = 60              # 2025-03-10 조례 개정 (이전 30일)
PAYMENT_DUE_HOURS = 24             # 규정상 24시간. 실제 자동취소는 daily_batch 참고
CANCEL_DEADLINE_DAYS = 1           # 이용 전날까지 취소 가능
NOSHOW_LIMIT = 3                   # 30일 안에 노쇼 3회면
NOSHOW_PENALTY_DAYS = 30           # 30일 예약 제한

# ---- 이용료(원/시간) ----
# 시설 테이블에 요금 컬럼이 없어서 시설명 키워드로 찾는다. 위에서부터 먼저 맞는 것.
# 2025-01-02 인상분 반영 (2024년 요금은 약 10% 낮았음)
FEE_TABLE = [
    ("주경기장", 60000),
    ("보조경기장", 35000),
    ("배드민턴장", 6000),
    ("탁구장", 4000),
    ("풋살장", 30000),
    ("테니스장", 8000),
    ("대강당", 90000),
    ("소강당", 40000),
    ("다목적실", 25000),
    ("세미나실", 20000),
    ("강의실", 18000),
    ("회의실", 15000),
    ("야외공연장", 70000),
    ("주차장", 50000),
]
DEFAULT_FEE = 20000

# 감면율: VIP = 감면 대상(장애인·국가유공자·다자녀), STAFF = 내부 행사(결제 없음)
DISCOUNT_RATE = {"NORMAL": 0.0, "VIP": 0.5, "STAFF": 1.0}

# ---- 문자 ----
SMS_ENABLED = ENV == "prod"
SMS_SENDER = "02-0000-0000"
SMS_GATEWAY_URL = "http://10.10.20.15:9090/sms/send"   # 내부망 문자 중계 서버
SMS_TIMEOUT = 3
SMS_OUTBOX = os.path.join(LOG_DIR, "sms_outbox.log")

# 관리자 API 허용 대역
ADMIN_IP_ALLOW = ("10.10.", "127.0.0.1")
