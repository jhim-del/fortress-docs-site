"""sqlite 연결 공통"""
import sqlite3
import threading
from contextlib import contextmanager

from . import config

_local = threading.local()


def connect(path=None):
    conn = sqlite3.connect(path or config.DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def get_conn():
    """요청 스레드마다 연결 하나"""
    conn = getattr(_local, "conn", None)
    if conn is None:
        conn = connect()
        _local.conn = conn
    return conn


def close():
    conn = getattr(_local, "conn", None)
    if conn is not None:
        conn.close()
        _local.conn = None


@contextmanager
def transaction(conn):
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise


def fetch_all(conn, sql, args=()):
    return conn.execute(sql, args).fetchall()


def fetch_one(conn, sql, args=()):
    return conn.execute(sql, args).fetchone()


def scalar(conn, sql, args=(), default=None):
    row = conn.execute(sql, args).fetchone()
    if row is None or row[0] is None:
        return default
    return row[0]
