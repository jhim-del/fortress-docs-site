"""문자 발송

운영: 내부 문자 중계 서버(config.SMS_GATEWAY_URL)로 POST
개발: logs/sms_outbox.log 에 기록만
"""
import json
import logging
import os
import urllib.request
from datetime import datetime

from . import config

log = logging.getLogger("reserve.sms")

SITE_NAME = "통합예약"

TEMPLATES = {
    "REQUESTED": "[{site}] {date} {start}시 {facility} 예약 신청이 접수되었습니다. 이용 2일 전까지 결제해 주세요.",
    "CONFIRMED": "[{site}] {date} {start}시~{end}시 {facility} 예약이 확정되었습니다.",
    "CANCELED": "[{site}] {date} {start}시 {facility} 예약이 취소되었습니다. 환불은 결제 수단으로 3~5일 내 처리됩니다.",
    "REMIND": "[{site}] 내일 {date} {start}시 {facility} 이용 예정입니다. 취소는 오늘까지 가능합니다.",
    "NOSHOW": "[{site}] {date} {facility} 미이용(노쇼) 처리되었습니다. 30일 내 3회 시 예약이 제한됩니다.",
}


def build_message(kind, facility, date, start, hours=1):
    tpl = TEMPLATES[kind]
    return tpl.format(site=SITE_NAME, facility=facility, date=date, start=start, end=start + hours)


def _outbox(phone, text):
    os.makedirs(os.path.dirname(config.SMS_OUTBOX), exist_ok=True)
    with open(config.SMS_OUTBOX, "a", encoding="utf-8") as f:
        f.write("%s\t%s\t%s\n" % (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), phone, text))


def send_sms(phone, text):
    if not phone:
        return False
    if not config.SMS_ENABLED:
        _outbox(phone, text)
        return True
    body = json.dumps({"from": config.SMS_SENDER, "to": phone, "text": text}).encode("utf-8")
    req = urllib.request.Request(config.SMS_GATEWAY_URL, data=body,
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=config.SMS_TIMEOUT) as resp:
            return resp.status == 200
    except Exception as e:      # 문자 실패로 예약 처리가 막히면 안 됨
        log.warning("sms fail %s %s", phone[-4:], e)
        return False


# def send_kakao(phone, template_code, params):
#     # 알림톡 전환 검토 -> 보류 (2025-09 예산 미반영)
#     pass


def notify_reservation(conn, reserve_id, kind):
    row = conn.execute(
        "SELECT r.reserve_date, r.start_hour, r.hours, f.name AS facility, m.phone "
        "FROM reservation r JOIN facility f ON f.facility_id = r.facility_id "
        "JOIN member m ON m.member_id = r.member_id WHERE r.reserve_id = ?",
        (reserve_id,),
    ).fetchone()
    if row is None:
        return False
    text = build_message(kind, row["facility"], row["reserve_date"], row["start_hour"], row["hours"])
    return send_sms(row["phone"], text)
