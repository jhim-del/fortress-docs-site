"""휴관일(공휴일)

양력 고정 공휴일은 FIXED 로, 설·추석·부처님오신날·대체공휴일·선거일은 holiday 테이블에서.
holiday 테이블은 매년 1월 scripts/load_holidays.py 로 입력한다.
시설은 공휴일 전부 휴관 (조례 제12조).
"""
from datetime import date

FIXED = {
    (1, 1): "신정",
    (3, 1): "삼일절",
    (5, 5): "어린이날",
    (6, 6): "현충일",
    (8, 15): "광복절",
    (10, 3): "개천절",
    (10, 9): "한글날",
    (12, 25): "성탄절",
}

_cache = {}        # 'YYYY-MM-DD' -> title


def load(conn):
    """DB 휴일 읽어서 캐시 (서버 기동 시, 2.6.2 부터 배치에서도)"""
    _cache.clear()
    for row in conn.execute("SELECT holiday_date, title FROM holiday"):
        _cache[row[0]] = row[1]
    return len(_cache)


def clear_cache():
    _cache.clear()


def is_holiday(d):
    if (d.month, d.day) in FIXED:
        return True
    return d.strftime("%Y-%m-%d") in _cache


def title_of(d):
    if (d.month, d.day) in FIXED:
        return FIXED[(d.month, d.day)]
    return _cache.get(d.strftime("%Y-%m-%d"))


def list_year(conn, year):
    rows = conn.execute(
        "SELECT holiday_date, title FROM holiday WHERE holiday_date LIKE ? ORDER BY holiday_date",
        ("%d-%%" % year,),
    ).fetchall()
    return [(r[0], r[1]) for r in rows]


def add(conn, d, title):
    conn.execute("INSERT OR REPLACE INTO holiday (holiday_date, title) VALUES (?, ?)",
                 (d.strftime("%Y-%m-%d"), title))
    conn.commit()
    _cache[d.strftime("%Y-%m-%d")] = title
