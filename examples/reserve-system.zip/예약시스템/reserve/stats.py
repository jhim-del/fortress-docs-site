"""통계 (2.4.0, 월별 보고용)

월간 보고서는 매월 3일 담당 주무관이 관리자 화면에서 내려받는다.
"""
from __future__ import annotations

from collections import Counter

from . import facility, holiday
from .calendar_util import fmt_date, iter_month_days, month_range
from .reservation import CANCEL_STATUSES


def _ym_bounds(year: int, month: int) -> tuple[str, str]:
    first, last = month_range(year, month)
    return fmt_date(first), fmt_date(last)


def monthly_usage(conn, year: int, month: int) -> dict[str, int]:
    """시설별 확정 이용시간 합계 (v_daily_usage 기준)"""
    lo, hi = _ym_bounds(year, month)
    rows = conn.execute(
        "SELECT facility, SUM(used_hours) FROM v_daily_usage "
        "WHERE reserve_date BETWEEN ? AND ? GROUP BY facility ORDER BY 2 DESC",
        (lo, hi),
    ).fetchall()
    return {r[0]: r[1] for r in rows}


def cancel_rate(conn, year: int, month: int) -> float:
    lo, hi = _ym_bounds(year, month)
    rows = conn.execute(
        "SELECT status, COUNT(*) FROM reservation WHERE reserve_date BETWEEN ? AND ? GROUP BY status",
        (lo, hi),
    ).fetchall()
    total = sum(r[1] for r in rows)
    if total == 0:
        return 0.0
    canceled = sum(r[1] for r in rows if r[0] in CANCEL_STATUSES)
    return round(canceled / total, 4)


def revenue(conn, year: int, month: int) -> dict[str, int]:
    """결제일 기준 수입 (환불 미반영 - PG 정산서와 차이 날 수 있음)"""
    ym = "%04d-%02d" % (year, month)
    rows = conn.execute(
        "SELECT method, SUM(amount) FROM payment WHERE substr(paid_at, 1, 7) = ? GROUP BY method",
        (ym,),
    ).fetchall()
    return {r[0]: r[1] for r in rows}


def hourly_distribution(conn, year: int, month: int) -> list[int]:
    lo, hi = _ym_bounds(year, month)
    out = [0] * 24
    for r in conn.execute(
        "SELECT start_hour, hours FROM reservation WHERE status = 'CONFIRMED' AND reserve_date BETWEEN ? AND ?",
        (lo, hi),
    ):
        for h in range(r[0], min(24, r[0] + r[1])):
            out[h] += 1
    return out


def weekday_distribution(conn, year: int, month: int) -> Counter:
    lo, hi = _ym_bounds(year, month)
    cnt: Counter = Counter()
    for r in conn.execute(
        "SELECT strftime('%w', reserve_date) FROM reservation WHERE status = 'CONFIRMED' "
        "AND reserve_date BETWEEN ? AND ?",
        (lo, hi),
    ):
        cnt[int(r[0])] += 1          # 0=일요일 (sqlite 기준)
    return cnt


def utilization(conn, year: int, month: int) -> dict[str, float]:
    """가동률 = 확정 이용시간 / (운영시간 x 개관일)"""
    open_days = sum(1 for d in iter_month_days(year, month) if not holiday.is_holiday(d))
    used = monthly_usage(conn, year, month)
    out = {}
    for f in facility.list_facilities(conn):
        cap = facility.open_hours(f) * open_days
        out[f["name"]] = round(used.get(f["name"], 0) / cap, 3) if cap else 0.0
    return out


def yearly_summary(conn, year: int) -> list[dict]:
    """연간 보고 (의회 자료 요구 대응용, 2025-10 추가)"""
    out = []
    for m in range(1, 13):
        lo, hi = _ym_bounds(year, m)
        n = conn.execute("SELECT COUNT(*) FROM reservation WHERE reserve_date BETWEEN ? AND ?", (lo, hi)).fetchone()[0]
        out.append({
            "month": m,
            "reservations": n,
            "used_hours": sum(monthly_usage(conn, year, m).values()),
            "cancel_rate": cancel_rate(conn, year, m),
            "revenue": sum(revenue(conn, year, m).values()),
        })
    return out


def monthly_report(conn, year: int, month: int) -> str:
    usage = monthly_usage(conn, year, month)
    rev = revenue(conn, year, month)
    lines = [f"[{year}년 {month}월 시설 이용 현황]",
             f"- 취소율 {cancel_rate(conn, year, month) * 100:.1f}%",
             f"- 수입 {sum(rev.values()):,}원 (카드 {rev.get('CARD', 0):,} / 이체 {rev.get('BANK', 0):,} / 현금 {rev.get('CASH', 0):,})",
             "- 시설별 이용시간 상위 10"]
    for name, h in list(usage.items())[:10]:
        lines.append(f"  {name}: {h}시간")
    return "\n".join(lines)
