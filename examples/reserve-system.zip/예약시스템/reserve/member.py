# -*- coding: utf-8 -*-
# 회원
#
# 회원 가입은 통합 포털(SSO)에서 하고 여기에는 예약에 필요한 것만 들고 있다.
# 1차 시스템 회원은 2023-11-28 일괄 이관 (전화번호 없는 회원 있음)
from datetime import timedelta

from . import config
from .validators import ValidationError, check_grade, check_phone


def get(conn, member_id):
    return conn.execute("SELECT * FROM member WHERE member_id = ?", (member_id,)).fetchone()


def find_by_phone(conn, phone):
    return conn.execute("SELECT * FROM member WHERE phone = ?", (phone,)).fetchone()


def register(conn, name, phone, grade="NORMAL", created_at=None):
    phone = check_phone(phone)
    check_grade(grade)
    if phone and find_by_phone(conn, phone) is not None:
        raise ValidationError("이미 등록된 전화번호입니다")
    if created_at:
        cur = conn.execute("INSERT INTO member (name, phone, grade, created_at) VALUES (?,?,?,?)",
                           (name, phone, grade, created_at))
    else:
        cur = conn.execute("INSERT INTO member (name, phone, grade) VALUES (?,?,?)",
                           (name, phone, grade))
    conn.commit()
    return cur.lastrowid


def mask_phone(phone):
    if not phone:
        return ""
    parts = phone.split("-")
    if len(parts) != 3:
        return phone[:3] + "****"
    return "%s-%s-%s" % (parts[0], "*" * len(parts[1]), parts[2])


def mask_name(name):
    if not name:
        return ""
    if len(name) <= 2:
        return name[0] + "*"
    return name[0] + "*" * (len(name) - 2) + name[-1]


def noshow_count(conn, member_id, since):
    row = conn.execute(
        "SELECT COUNT(*) FROM reservation WHERE member_id = ? AND status = 'NOSHOW' AND reserve_date >= ?",
        (member_id, since),
    ).fetchone()
    return row[0]


def is_restricted(conn, member_id, today):
    """노쇼 누적 제한 (2024-08 도입)"""
    m = get(conn, member_id)
    if m is not None and m["grade"] == "STAFF":
        return False
    since = (today - timedelta(days=config.NOSHOW_PENALTY_DAYS)).strftime("%Y-%m-%d")
    return noshow_count(conn, member_id, since) >= config.NOSHOW_LIMIT


def grade_of(conn, member_id):
    m = get(conn, member_id)
    return m["grade"] if m else None


def search(conn, keyword, limit=50):
    # 관리자 화면 회원 검색 (이름 또는 전화 뒷자리)
    keyword = (keyword or "").strip()
    if not keyword:
        return []
    if keyword.isdigit() and len(keyword) == 4:
        sql = "SELECT * FROM member WHERE phone LIKE ? ORDER BY member_id DESC LIMIT ?"
        args = ("%-" + keyword, limit)
    else:
        sql = "SELECT * FROM member WHERE name LIKE ? ORDER BY member_id DESC LIMIT ?"
        args = ("%" + keyword + "%", limit)
    return conn.execute(sql, args).fetchall()


WITHDRAWN_NAME = "탈퇴회원"


def withdraw(conn, member_id):
    """탈퇴 - 개인정보만 지우고 행은 남긴다 (예약·결제 이력 보존, 2024-09 개인정보 점검 지적)

    TODO: 보존기간(5년) 지난 탈퇴회원 예약 이력 정리 배치
    """
    active = conn.execute(
        "SELECT COUNT(*) FROM reservation WHERE member_id = ? AND status IN ('REQUESTED', 'CONFIRMED') "
        "AND reserve_date >= date('now', 'localtime')",
        (member_id,),
    ).fetchone()[0]
    if active:
        raise ValidationError("이용 예정 예약이 있어 탈퇴할 수 없습니다 (%d건)" % active)
    conn.execute("UPDATE member SET name = ?, phone = NULL WHERE member_id = ?", (WITHDRAWN_NAME, member_id))
    conn.commit()
