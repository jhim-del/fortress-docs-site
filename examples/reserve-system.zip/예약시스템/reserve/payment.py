# -*- coding: utf-8 -*-
"""결제

PG 연동은 운영 서버의 pg_agent(별도 프로세스)가 하고, 승인 결과만 /api/payments/callback 으로 넘어온다.
환불은 PG 관리자 화면에서 처리 - 이 테이블에는 환불 기록이 남지 않는다 (2024-05 회의).
"""
from datetime import datetime

from . import config, facility, reservation

METHODS = ("CARD", "BANK", "CASH")


class PaymentError(Exception):
    pass


def calc_amount(facility_name, hours, grade):
    fee = facility.fee_per_hour(facility_name)
    rate = config.DISCOUNT_RATE.get(grade, 0.0)
    amount = fee * hours * (1 - rate)
    return int(round(amount / 100.0)) * 100      # 100원 단위


def _target(conn, reserve_id):
    row = conn.execute(
        "SELECT r.reserve_id, r.status, r.hours, f.name AS facility_name, m.grade "
        "FROM reservation r JOIN facility f ON f.facility_id = r.facility_id "
        "JOIN member m ON m.member_id = r.member_id WHERE r.reserve_id = ?",
        (reserve_id,),
    ).fetchone()
    if row is None:
        raise PaymentError("없는 예약입니다: %s" % reserve_id)
    return row


def pay(conn, reserve_id, method="CARD", paid_at=None):
    """결제 승인 반영 -> 예약 확정. STAFF(내부 행사)는 결제 없이 확정하고 None 반환"""
    if method not in METHODS:
        raise PaymentError("결제 수단 오류: %s" % method)
    row = _target(conn, reserve_id)
    if row["status"] != "REQUESTED":
        raise PaymentError("결제 대기 상태가 아닙니다: %s" % row["status"])
    amount = calc_amount(row["facility_name"], row["hours"], row["grade"])
    pay_id = None
    if amount > 0:
        paid_at = paid_at or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cur = conn.execute(
            "INSERT INTO payment (reserve_id, amount, paid_at, method) VALUES (?, ?, ?, ?)",
            (reserve_id, amount, paid_at, method),
        )
        pay_id = cur.lastrowid
    reservation.set_status(conn, reserve_id, "CONFIRMED")
    return pay_id


def total_paid(conn, reserve_id):
    row = conn.execute("SELECT COALESCE(SUM(amount), 0) FROM payment WHERE reserve_id = ?",
                       (reserve_id,)).fetchone()
    return row[0]


def daily_settlement(conn, day):
    """일 정산 (회계 담당 엑셀 양식에 옮겨 적음)"""
    rows = conn.execute(
        "SELECT method, COUNT(*) AS cnt, SUM(amount) AS total FROM payment "
        "WHERE substr(paid_at, 1, 10) = ? GROUP BY method",
        (day,),
    ).fetchall()
    out = {m: {"cnt": 0, "total": 0} for m in METHODS}
    for r in rows:
        out[r["method"]] = {"cnt": r["cnt"], "total": r["total"]}
    return out
