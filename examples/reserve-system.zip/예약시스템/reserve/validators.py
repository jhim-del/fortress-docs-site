import re

from . import config

PHONE_RE = re.compile(r"^0\d{1,2}-\d{3,4}-\d{4}$")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
GRADES = ("NORMAL", "VIP", "STAFF")


class ValidationError(ValueError):
    pass


def check_phone(phone):
    if phone is None or phone == "":
        return None          # 1차 이관 회원은 전화번호 없는 경우 있음
    phone = phone.strip()
    if not PHONE_RE.match(phone):
        raise ValidationError("전화번호 형식이 아닙니다: %s" % phone)
    return phone


def check_hours(hours):
    if not isinstance(hours, int) or not 1 <= hours <= config.MAX_HOURS_PER_RESERVATION:
        raise ValidationError("이용 시간은 1~%d시간입니다" % config.MAX_HOURS_PER_RESERVATION)
    return hours


def check_date_str(s):
    if not s or not DATE_RE.match(s):
        raise ValidationError("날짜 형식(YYYY-MM-DD)이 아닙니다: %s" % s)
    return s


def check_grade(grade):
    if grade not in GRADES:
        raise ValidationError("회원 등급 오류: %s" % grade)
    return grade
