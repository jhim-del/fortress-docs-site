# -*- coding: utf-8 -*-
"""예약 신청·조회·취소

수정 이력
  2023-11-20  최초 작성 (2.0 구축)
  2024-03-18  취소 상태값 CANCELED 로 통일 (기존 CANCELLED 데이터는 그대로 둠)
  2024-07-02  관리자 삭제 -> 취소 처리로 변경 (#88)
  2025-03-10  사전 신청 기간 30일 -> 60일 (조례 개정)
  2026-08-14  예약 가능일 조회 정리 (#212)
"""
import sqlite3
from datetime import date

from . import config, holiday, member
from .calendar_util import fmt_date, parse_date
from .validators import check_hours

ACTIVE_STATUSES = ("REQUESTED", "CONFIRMED")
CANCEL_STATUSES = ("CANCELED", "CANCELLED")   # 2024-03 이전 데이터 철자 혼재


class ReservationError(Exception):
    pass


def next_month_first(d: date) -> date:
    """다음 달 1일"""
    return date(d.year, d.month + 1, 1)


def days_in_month(year: int, month: int) -> int:
    first = date(year, month, 1)
    return (next_month_first(first) - first).days


def available_dates(year: int, month: int, booked: set[int]) -> list[date]:
    """그 달의 예약 가능일: 휴관일(공휴일)·마감된 날 제외"""
    out = []
    for day in range(1, days_in_month(year, month) + 1):
        d = date(year, month, day)
        if holiday.is_holiday(d) or day in booked:
            continue
        out.append(d)
    return out


def _facility(conn, facility_id):
    fac = conn.execute(
        "SELECT facility_id, name, open_hour, close_hour FROM facility WHERE facility_id = ?",
        (facility_id,),
    ).fetchone()
    if fac is None:
        raise ReservationError("없는 시설입니다: %s" % facility_id)
    return fac


def booked_days(conn, facility_id, year, month):
    """운영시간이 다 찬 날(마감일)의 일자 집합"""
    fac = _facility(conn, facility_id)
    open_hours = fac["close_hour"] - fac["open_hour"]
    first = date(year, month, 1)
    rows = conn.execute(
        "SELECT reserve_date, SUM(hours) AS h FROM reservation "
        "WHERE facility_id = ? AND reserve_date >= ? AND reserve_date < ? "
        "AND status IN ('REQUESTED', 'CONFIRMED') GROUP BY reserve_date",
        (facility_id, fmt_date(first), fmt_date(next_month_first(first))),
    ).fetchall()
    return {int(r["reserve_date"][8:10]) for r in rows if r["h"] >= open_hours}


def _occupied_hours(conn, facility_id, d):
    rows = conn.execute(
        "SELECT start_hour, hours FROM reservation "
        "WHERE facility_id = ? AND reserve_date = ? AND status IN ('REQUESTED', 'CONFIRMED')",
        (facility_id, fmt_date(d)),
    ).fetchall()
    busy = set()
    for r in rows:
        busy.update(range(r["start_hour"], r["start_hour"] + r["hours"]))
    return busy


def free_slots(conn, facility_id, d):
    """그날 비어 있는 시작 시각 목록 (1시간 단위)"""
    d = parse_date(d)
    fac = _facility(conn, facility_id)
    busy = _occupied_hours(conn, facility_id, d)
    return [h for h in range(fac["open_hour"], fac["close_hour"]) if h not in busy]


def create_reservation(conn, facility_id, member_id, reserve_date, start_hour, hours, today=None):
    today = today or date.today()
    d = parse_date(reserve_date)
    check_hours(hours)
    if d <= today:
        raise ReservationError("당일·지난 날짜는 신청할 수 없습니다")
    if (d - today).days > config.MAX_ADVANCE_DAYS:
        raise ReservationError("%d일 이후 날짜는 아직 신청할 수 없습니다" % config.MAX_ADVANCE_DAYS)
    if holiday.is_holiday(d):
        raise ReservationError("휴관일입니다")
    fac = _facility(conn, facility_id)
    if start_hour < fac["open_hour"] or start_hour + hours > fac["close_hour"]:
        raise ReservationError("운영시간(%02d~%02d시) 밖입니다" % (fac["open_hour"], fac["close_hour"]))
    want = set(range(start_hour, start_hour + hours))
    if _occupied_hours(conn, facility_id, d) & want:
        raise ReservationError("이미 예약된 시간이 포함되어 있습니다")
    if member.is_restricted(conn, member_id, today):
        raise ReservationError("노쇼 누적으로 예약이 제한된 회원입니다")
    try:
        cur = conn.execute(
            "INSERT INTO reservation (facility_id, member_id, reserve_date, start_hour, hours, status) "
            "VALUES (?, ?, ?, ?, ?, 'REQUESTED')",
            (facility_id, member_id, fmt_date(d), start_hour, hours),
        )
    except sqlite3.IntegrityError:
        # TODO(#156): 같은 시작 시각에 취소된 예약이 있으면 UNIQUE 에 걸림. 화면에서 다른 시각 안내
        conn.rollback()
        raise ReservationError("해당 시각은 신청할 수 없습니다. 다른 시각을 선택해 주세요")
    conn.commit()
    return cur.lastrowid


def get(conn, reserve_id):
    return conn.execute(
        "SELECT r.*, f.name AS facility_name FROM reservation r "
        "JOIN facility f ON f.facility_id = r.facility_id WHERE r.reserve_id = ?",
        (reserve_id,),
    ).fetchone()


def list_by_member(conn, member_id, include_canceled=False):
    sql = "SELECT * FROM reservation WHERE member_id = ?"
    if not include_canceled:
        sql += " AND status NOT IN ('CANCELED', 'CANCELLED')"
    sql += " ORDER BY reserve_date DESC, start_hour"
    return conn.execute(sql, (member_id,)).fetchall()


def change_time(conn, reserve_id, new_start, today=None):
    """같은 날 안에서 시작 시각만 변경 (날짜·시설 변경은 취소 후 재신청)"""
    today = today or date.today()
    row = get(conn, reserve_id)
    if row is None or row["status"] not in ACTIVE_STATUSES:
        raise ReservationError("변경할 수 없는 예약입니다")
    d = parse_date(row["reserve_date"])
    if (d - today).days < config.CANCEL_DEADLINE_DAYS:
        raise ReservationError("이용일 전날까지만 변경할 수 있습니다")
    fac = _facility(conn, row["facility_id"])
    if new_start < fac["open_hour"] or new_start + row["hours"] > fac["close_hour"]:
        raise ReservationError("운영시간 밖입니다")
    busy = _occupied_hours(conn, row["facility_id"], d)
    busy -= set(range(row["start_hour"], row["start_hour"] + row["hours"]))
    if busy & set(range(new_start, new_start + row["hours"])):
        raise ReservationError("이미 예약된 시간이 포함되어 있습니다")
    # UNIQUE(facility_id, reserve_date, start_hour) 에 취소건도 걸려서 같은 시각 취소 기록이 있으면 실패함
    # 예전엔 취소건을 지우고 넣었는데 2024-07 부터 삭제 금지라 오류 안내만 한다
    # conn.execute("DELETE FROM reservation WHERE facility_id = ? AND reserve_date = ? AND start_hour = ? "
    #              "AND status IN ('CANCELED', 'CANCELLED')", (row["facility_id"], row["reserve_date"], new_start))
    try:
        conn.execute("UPDATE reservation SET start_hour = ? WHERE reserve_id = ?", (new_start, reserve_id))
        conn.commit()
    except Exception:
        conn.rollback()
        raise ReservationError("해당 시각에 취소된 예약 기록이 있어 변경할 수 없습니다. 관리자에게 문의하세요")
    return True


def set_status(conn, reserve_id, status):
    # 상태 변경 이력은 DB 트리거가 reservation_log 에 남긴다
    conn.execute("UPDATE reservation SET status = ? WHERE reserve_id = ?", (status, reserve_id))
    conn.commit()


def cancel(conn, reserve_id, today=None, by_admin=False):
    today = today or date.today()
    row = get(conn, reserve_id)
    if row is None:
        raise ReservationError("없는 예약입니다: %s" % reserve_id)
    if row["status"] in CANCEL_STATUSES:
        return False
    if row["status"] not in ACTIVE_STATUSES:
        raise ReservationError("취소할 수 없는 상태입니다: %s" % row["status"])
    d = parse_date(row["reserve_date"])
    if not by_admin and (d - today).days < config.CANCEL_DEADLINE_DAYS:
        raise ReservationError("이용일 전날까지만 취소할 수 있습니다")
    set_status(conn, reserve_id, "CANCELED")
    return True
