# -*- coding: utf-8 -*-
"""관리자 기능 (담당 주무관용 화면에서 호출)

TODO(2025-06): 관리자 작업 이력 테이블 따로 두기 - 지금은 reservation_log 로만 추적됨
TODO: 시설 일괄 휴관(공사 등) 기능. 지금은 STAFF 계정으로 예약을 잡아 막는다
"""
import logging
from datetime import date

from . import member, reservation
from .calendar_util import fmt_date, parse_date
from .validators import check_grade

log = logging.getLogger("reserve.admin")


def search_reservations(conn, facility_id=None, member_id=None, date_from=None, date_to=None,
                        status=None, limit=200):
    sql = ("SELECT r.*, f.name AS facility_name, m.name AS member_name, m.phone "
           "FROM reservation r JOIN facility f ON f.facility_id = r.facility_id "
           "JOIN member m ON m.member_id = r.member_id WHERE 1=1")
    args = []
    if facility_id:
        sql += " AND r.facility_id = ?"
        args.append(facility_id)
    if member_id:
        sql += " AND r.member_id = ?"
        args.append(member_id)
    if date_from:
        sql += " AND r.reserve_date >= ?"
        args.append(date_from)
    if date_to:
        sql += " AND r.reserve_date <= ?"
        args.append(date_to)
    if status == "CANCELED":
        sql += " AND r.status IN ('CANCELED', 'CANCELLED')"
    elif status:
        sql += " AND r.status = ?"
        args.append(status)
    sql += " ORDER BY r.reserve_date DESC, r.start_hour LIMIT ?"
    args.append(limit)
    rows = conn.execute(sql, args).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["phone"] = member.mask_phone(d["phone"])
        out.append(d)
    return out


def approve(conn, reserve_id):
    """STAFF(내부 행사) 신청 승인 - 결제 없이 확정"""
    row = reservation.get(conn, reserve_id)
    if row is None or row["status"] != "REQUESTED":
        raise reservation.ReservationError("승인할 수 없는 예약입니다")
    reservation.set_status(conn, reserve_id, "CONFIRMED")
    log.info("approve %s", reserve_id)


def force_cancel(conn, reserve_id, reason=""):
    ok = reservation.cancel(conn, reserve_id, by_admin=True)
    log.info("force_cancel %s %s", reserve_id, reason)
    return ok


def mark_noshow(conn, reserve_id, today=None):
    """현장 확인 후 노쇼 처리 (다음 날 오전에 시설 담당이 입력)"""
    today = today or date.today()
    row = reservation.get(conn, reserve_id)
    if row is None or row["status"] != "CONFIRMED":
        raise reservation.ReservationError("확정된 예약만 노쇼 처리할 수 있습니다")
    if parse_date(row["reserve_date"]) >= today:
        raise reservation.ReservationError("이용일이 지나지 않았습니다")
    reservation.set_status(conn, reserve_id, "NOSHOW")


def proxy_reserve(conn, facility_id, member_id, reserve_date, start_hour, hours):
    """전화·방문 접수 대리 신청 (사전 신청 기간 제한 없음)"""
    d = parse_date(reserve_date)
    free = set(reservation.free_slots(conn, facility_id, d))
    if not set(range(start_hour, start_hour + hours)) <= free:
        raise reservation.ReservationError("이미 예약된 시간이 포함되어 있습니다")
    cur = conn.execute(
        "INSERT INTO reservation (facility_id, member_id, reserve_date, start_hour, hours, status) "
        "VALUES (?, ?, ?, ?, ?, 'REQUESTED')",
        (facility_id, member_id, fmt_date(d), start_hour, hours),
    )
    conn.commit()
    log.info("proxy_reserve %s by phone/visit", cur.lastrowid)
    return cur.lastrowid


def change_grade(conn, member_id, grade):
    # 감면 증빙 확인 후 VIP 로 변경. 증빙 파일은 문서관리시스템에 (여기 없음)
    check_grade(grade)
    conn.execute("UPDATE member SET grade = ? WHERE member_id = ?", (grade, member_id))
    conn.commit()


def status_history(conn, reserve_id):
    # 2024-04-01 이전 예약은 이력 없음 (트리거 추가 전)
    return conn.execute(
        "SELECT old_status, new_status, changed_at FROM reservation_log "
        "WHERE reserve_id = ? ORDER BY log_id",
        (reserve_id,),
    ).fetchall()
