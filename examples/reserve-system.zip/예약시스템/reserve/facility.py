# -*- coding: utf-8 -*-
# 시설 조회
# 2023-11 최초. 시설 등록/수정은 관리자가 DB 직접 수정 (화면 없음)
from . import config


def category_of(name):
    """시설명으로 분류. FEE_TABLE 키워드 순서대로 먼저 맞는 것"""
    for keyword, _fee in config.FEE_TABLE:
        if keyword in name:
            return keyword
    return None


def fee_per_hour(name):
    for keyword, fee in config.FEE_TABLE:
        if keyword in name:
            return fee
    return config.DEFAULT_FEE


def site_of(name):
    # '구민회관 회의실 101' -> '구민회관'
    return name.split(" ")[0]


def list_facilities(conn, category=None):
    rows = conn.execute(
        "SELECT facility_id, name, capacity, open_hour, close_hour FROM facility ORDER BY facility_id"
    ).fetchall()
    if category:
        rows = [r for r in rows if category_of(r["name"]) == category]
    return rows


def get(conn, facility_id):
    return conn.execute(
        "SELECT facility_id, name, capacity, open_hour, close_hour FROM facility WHERE facility_id = ?",
        (facility_id,),
    ).fetchone()


def open_hours(row):
    return row["close_hour"] - row["open_hour"]


def sites(conn):
    out = []
    for r in list_facilities(conn):
        s = site_of(r["name"])
        if s not in out:
            out.append(s)
    return out
