"""엑셀(CSV) 내보내기 - 관리자 화면 '내려받기' 버튼

엑셀에서 바로 열리게 utf-8-sig 로 쓴다. 개인정보는 마스킹해서 내보냄 (2024-09 점검 지적)
"""
import csv
import io

from . import member, payment
from .calendar_util import parse_date, weekday_ko

STATUS_KO = {
    "REQUESTED": "결제대기",
    "CONFIRMED": "확정",
    "CANCELED": "취소",
    "CANCELLED": "취소",
    "NOSHOW": "노쇼",
}


def _to_csv(header, rows):
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\r\n")
    w.writerow(header)
    w.writerows(rows)
    return ("﻿" + buf.getvalue()).encode("utf-8")


def reservations_csv(conn, date_from, date_to, facility_id=None):
    sql = ("SELECT r.reserve_id, r.reserve_date, r.start_hour, r.hours, r.status, f.name, m.name, m.phone "
           "FROM reservation r JOIN facility f ON f.facility_id = r.facility_id "
           "JOIN member m ON m.member_id = r.member_id "
           "WHERE r.reserve_date BETWEEN ? AND ?")
    args = [date_from, date_to]
    if facility_id:
        sql += " AND r.facility_id = ?"
        args.append(facility_id)
    sql += " ORDER BY r.reserve_date, f.name, r.start_hour"
    out = []
    for rid, d, sh, h, st, fname, mname, phone in conn.execute(sql, args):
        out.append([rid, d, weekday_ko(parse_date(d)), "%02d:00~%02d:00" % (sh, sh + h), fname,
                    member.mask_name(mname), member.mask_phone(phone), STATUS_KO.get(st, st)])
    return _to_csv(["예약번호", "이용일", "요일", "시간", "시설", "신청자", "연락처", "상태"], out)


def settlement_csv(conn, day):
    s = payment.daily_settlement(conn, day)
    rows = [[day, m, v["cnt"], v["total"]] for m, v in s.items()]
    rows.append([day, "합계", sum(v["cnt"] for v in s.values()), sum(v["total"] for v in s.values())])
    return _to_csv(["정산일", "결제수단", "건수", "금액"], rows)


def noshow_members_csv(conn, since):
    rows = conn.execute(
        "SELECT m.member_id, m.name, m.phone, COUNT(*) AS cnt FROM reservation r "
        "JOIN member m ON m.member_id = r.member_id "
        "WHERE r.status = 'NOSHOW' AND r.reserve_date >= ? GROUP BY m.member_id HAVING cnt >= 2 "
        "ORDER BY cnt DESC",
        (since,),
    ).fetchall()
    return _to_csv(["회원번호", "이름", "연락처", "노쇼횟수"],
                   [[r[0], member.mask_name(r[1]), member.mask_phone(r[2]), r[3]] for r in rows])
