"""날짜 공통 함수 (2025-02 정리, stats 에서 사용)"""
import calendar
from datetime import date, datetime, timedelta

WEEKDAY_KO = "월화수목금토일"


def month_range(year, month):
    """그 달의 첫날, 마지막 날"""
    last = calendar.monthrange(year, month)[1]
    return date(year, month, 1), date(year, month, last)


def iter_month_days(year, month):
    first, last = month_range(year, month)
    d = first
    while d <= last:
        yield d
        d += timedelta(days=1)


def iter_weeks(year, month):
    """달력 화면용, 일요일 시작 주 단위"""
    cal = calendar.Calendar(firstweekday=6)
    return cal.monthdatescalendar(year, month)


def parse_date(s):
    """'2026-11-16' 또는 '20261116'"""
    if isinstance(s, date):
        return s
    s = s.strip()
    if len(s) == 8 and s.isdigit():
        return datetime.strptime(s, "%Y%m%d").date()
    return datetime.strptime(s[:10], "%Y-%m-%d").date()


def fmt_date(d):
    return d.strftime("%Y-%m-%d")


def fmt_dt(dt):
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def weekday_ko(d):
    return WEEKDAY_KO[d.weekday()]


def is_weekend(d):
    return d.weekday() >= 5
