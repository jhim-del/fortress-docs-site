"""테스트 공통 - 메모리 DB (스키마는 운영 DB 에서 .schema 떠서 옮김, 2024-04)"""
import sqlite3

SCHEMA = """CREATE TABLE facility (facility_id INTEGER PRIMARY KEY, name TEXT NOT NULL, capacity INTEGER NOT NULL CHECK (capacity > 0), open_hour INTEGER DEFAULT 9, close_hour INTEGER DEFAULT 18);
CREATE TABLE member (member_id INTEGER PRIMARY KEY, name TEXT NOT NULL, phone TEXT, grade TEXT DEFAULT 'NORMAL' CHECK (grade IN ('NORMAL','VIP','STAFF')), created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE reservation (reserve_id INTEGER PRIMARY KEY, facility_id INTEGER NOT NULL REFERENCES facility(facility_id), member_id INTEGER NOT NULL REFERENCES member(member_id), reserve_date TEXT NOT NULL, start_hour INTEGER NOT NULL, hours INTEGER NOT NULL CHECK (hours BETWEEN 1 AND 4), status TEXT NOT NULL DEFAULT 'REQUESTED', UNIQUE (facility_id, reserve_date, start_hour));
CREATE TABLE payment (pay_id INTEGER PRIMARY KEY, reserve_id INTEGER NOT NULL, amount INTEGER NOT NULL CHECK (amount > 0), paid_at TEXT, method TEXT);
CREATE TABLE holiday (holiday_date TEXT PRIMARY KEY, title TEXT);
CREATE TABLE reservation_log (log_id INTEGER PRIMARY KEY, reserve_id INTEGER, old_status TEXT, new_status TEXT, changed_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX ix_reservation_member ON reservation(member_id);
CREATE INDEX ix_payment_reserve ON payment(reserve_id);
CREATE TRIGGER trg_reservation_status AFTER UPDATE OF status ON reservation
BEGIN INSERT INTO reservation_log(reserve_id, old_status, new_status) VALUES (OLD.reserve_id, OLD.status, NEW.status); END;
CREATE VIEW v_daily_usage AS SELECT r.reserve_date, f.name AS facility, SUM(r.hours) AS used_hours FROM reservation r JOIN facility f ON f.facility_id = r.facility_id WHERE r.status = 'CONFIRMED' GROUP BY r.reserve_date, f.name;
"""


def make_db():
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript(SCHEMA)
    conn.executemany("INSERT INTO facility VALUES (?, ?, ?, ?, ?)", [
        (1, "구민회관 회의실 101", 12, 9, 21),
        (2, "북부스포츠센터 테니스장 1코트", 4, 6, 22),
        (3, "구민회관 대강당", 450, 9, 22),
    ])
    conn.executemany("INSERT INTO member VALUES (?, ?, ?, ?, ?)", [
        (1, "한도윤", "010-0000-1111", "NORMAL", "2024-01-05 10:00:00"),
        (2, "서지아", "010-0000-2222", "VIP", "2024-02-11 14:20:00"),
        (3, "문화체육과 행사담당", "02-0000-3101", "STAFF", "2023-12-01 09:00:00"),
    ])
    conn.commit()
    return conn
