import unittest
from datetime import date

from reserve import stats
from reserve.calendar_util import iter_weeks, month_range
from tests import make_db


class TestStats(unittest.TestCase):
    def setUp(self):
        self.conn = make_db()
        rows = [
            (1, 1, "2026-11-03", 10, 2, "CONFIRMED"),
            (1, 2, "2026-11-04", 14, 3, "CONFIRMED"),
            (2, 1, "2026-11-07", 18, 2, "CONFIRMED"),
            (2, 2, "2026-11-08", 18, 2, "CANCELED"),
            (2, 1, "2026-10-31", 18, 2, "CONFIRMED"),
        ]
        self.conn.executemany("INSERT INTO reservation (facility_id, member_id, reserve_date, start_hour, hours, status) "
                              "VALUES (?, ?, ?, ?, ?, ?)", rows)

    def test_monthly_usage(self):
        got = stats.monthly_usage(self.conn, 2026, 11)
        self.assertEqual(got, {"구민회관 회의실 101": 5, "북부스포츠센터 테니스장 1코트": 2})

    def test_cancel_rate(self):
        self.assertEqual(stats.cancel_rate(self.conn, 2026, 11), 0.25)

    def test_month_range(self):
        self.assertEqual(month_range(2024, 2), (date(2024, 2, 1), date(2024, 2, 29)))
        weeks = iter_weeks(2026, 11)
        self.assertEqual(weeks[0][0], date(2026, 11, 1))


if __name__ == "__main__":
    unittest.main()
