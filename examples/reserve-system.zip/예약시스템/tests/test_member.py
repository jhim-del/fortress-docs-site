import unittest

from reserve import member
from reserve.validators import ValidationError
from tests import make_db


class TestMember(unittest.TestCase):
    def test_mask(self):
        self.assertEqual(member.mask_phone("010-0000-1234"), "010-****-1234")
        self.assertEqual(member.mask_phone(None), "")
        self.assertEqual(member.mask_name("한도윤"), "한*윤")

    def test_duplicate_phone(self):
        conn = make_db()
        with self.assertRaises(ValidationError):
            member.register(conn, "한도윤", "010-0000-1111")


if __name__ == "__main__":
    unittest.main()
