import unittest

from reserve.validators import ValidationError, check_hours, check_phone


class TestValidators(unittest.TestCase):
    def test_phone(self):
        self.assertEqual(check_phone("010-0000-1234"), "010-0000-1234")
        self.assertIsNone(check_phone(""))
        with self.assertRaises(ValidationError):
            check_phone("01000001234")

    def test_hours(self):
        self.assertEqual(check_hours(4), 4)
        for bad in (0, 5, "2"):
            with self.assertRaises(ValidationError):
                check_hours(bad)


if __name__ == "__main__":
    unittest.main()
