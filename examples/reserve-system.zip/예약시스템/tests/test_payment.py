import unittest

from reserve import export, facility, payment
from tests import make_db


class TestPayment(unittest.TestCase):
    def setUp(self):
        self.conn = make_db()

    def _reserve(self, member_id, facility_id=1, hours=2):
        cur = self.conn.execute(
            "INSERT INTO reservation (facility_id, member_id, reserve_date, start_hour, hours) "
            "VALUES (?, ?, '2026-11-20', 10, ?)", (facility_id, member_id, hours))
        return cur.lastrowid

    def test_fee_by_name(self):
        self.assertEqual(facility.fee_per_hour("구민회관 회의실 101"), 15000)
        self.assertEqual(facility.fee_per_hour("중앙시민체육관 보조경기장"), 35000)

    def test_vip_discount(self):
        self.assertEqual(payment.calc_amount("구민회관 회의실 101", 2, "VIP"), 15000)

    def test_pay_confirms(self):
        rid = self._reserve(1)
        pay_id = payment.pay(self.conn, rid, "CARD", "2026-11-12 10:00:00")
        self.assertIsNotNone(pay_id)
        self.assertEqual(payment.total_paid(self.conn, rid), 30000)
        status = self.conn.execute("SELECT status FROM reservation WHERE reserve_id = ?", (rid,)).fetchone()[0]
        self.assertEqual(status, "CONFIRMED")

    def test_staff_no_payment(self):
        rid = self._reserve(3, facility_id=3, hours=4)
        self.assertIsNone(payment.pay(self.conn, rid))
        self.assertEqual(payment.total_paid(self.conn, rid), 0)

    def test_settlement_csv(self):
        payment.pay(self.conn, self._reserve(1), "CARD", "2026-11-12 10:00:00")
        text = export.settlement_csv(self.conn, "2026-11-12").decode("utf-8-sig")
        self.assertIn("CARD,1,30000", text)
        self.assertIn("합계,1,30000", text)


if __name__ == "__main__":
    unittest.main()
