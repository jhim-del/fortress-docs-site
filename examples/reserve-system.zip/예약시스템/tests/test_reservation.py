import unittest
from datetime import date

from reserve import holiday
from reserve.reservation import (ReservationError, available_dates, booked_days, cancel,
                                 create_reservation, days_in_month)
from tests import make_db

TODAY = date(2026, 11, 10)


class TestCalendar(unittest.TestCase):
    def setUp(self):
        holiday.clear_cache()

    def test_days_in_november(self):
        self.assertEqual(days_in_month(2026, 11), 30)

    def test_days_in_leap_february(self):
        self.assertEqual(days_in_month(2024, 2), 29)

    def test_available_excludes_booked(self):
        got = available_dates(2026, 11, booked={2, 3})
        self.assertNotIn(date(2026, 11, 2), got)
        self.assertNotIn(date(2026, 11, 3), got)
        self.assertIn(date(2026, 11, 4), got)
        self.assertEqual(len(got), 28)

    def test_available_excludes_holiday(self):
        conn = make_db()
        conn.execute("INSERT INTO holiday VALUES ('2026-10-05', '대체공휴일(개천절)')")
        holiday.load(conn)
        got = available_dates(2026, 10, booked=set())
        self.assertNotIn(date(2026, 10, 3), got)
        self.assertNotIn(date(2026, 10, 5), got)
        self.assertNotIn(date(2026, 10, 9), got)
        self.assertIn(date(2026, 10, 6), got)
        holiday.clear_cache()


class TestReservation(unittest.TestCase):
    def setUp(self):
        holiday.clear_cache()
        self.conn = make_db()

    def test_booked_days(self):
        for start in (9, 13, 17):
            self.conn.execute("INSERT INTO reservation (facility_id, member_id, reserve_date, start_hour, hours, status) "
                              "VALUES (1, 1, '2026-11-20', ?, 4, 'CONFIRMED')", (start,))
        self.assertEqual(booked_days(self.conn, 1, 2026, 11), {20})

    def test_overlap_rejected(self):
        create_reservation(self.conn, 2, 1, "2026-11-20", 18, 2, today=TODAY)
        with self.assertRaises(ReservationError):
            create_reservation(self.conn, 2, 2, "2026-11-20", 19, 2, today=TODAY)

    def test_outside_hours_rejected(self):
        with self.assertRaises(ReservationError):
            create_reservation(self.conn, 1, 1, "2026-11-20", 20, 2, today=TODAY)

    def test_cancel_writes_log(self):
        rid = create_reservation(self.conn, 1, 1, "2026-11-20", 10, 2, today=TODAY)
        self.assertTrue(cancel(self.conn, rid, today=TODAY))
        log = self.conn.execute("SELECT old_status, new_status FROM reservation_log WHERE reserve_id = ?",
                                (rid,)).fetchall()
        self.assertEqual([tuple(r) for r in log], [("REQUESTED", "CANCELED")])

    def test_cancel_same_day_rejected(self):
        rid = create_reservation(self.conn, 1, 1, "2026-11-20", 10, 2, today=TODAY)
        with self.assertRaises(ReservationError):
            cancel(self.conn, rid, today=date(2026, 11, 20))


if __name__ == "__main__":
    unittest.main()
