import unittest
from datetime import date

from reserve import facility, holiday
from tests import make_db


class TestHoliday(unittest.TestCase):
    def setUp(self):
        holiday.clear_cache()

    def tearDown(self):
        holiday.clear_cache()

    def test_fixed(self):
        self.assertTrue(holiday.is_holiday(date(2026, 8, 15)))
        self.assertFalse(holiday.is_holiday(date(2026, 8, 14)))

    def test_from_db(self):
        conn = make_db()
        conn.execute("INSERT INTO holiday VALUES ('2026-09-25', '추석')")
        self.assertFalse(holiday.is_holiday(date(2026, 9, 25)))
        holiday.load(conn)
        self.assertTrue(holiday.is_holiday(date(2026, 9, 25)))
        self.assertEqual(holiday.title_of(date(2026, 9, 25)), "추석")

    def test_category(self):
        self.assertEqual(facility.category_of("북부스포츠센터 테니스장 3코트"), "테니스장")
        self.assertIsNone(facility.category_of("구청 민원실"))


if __name__ == "__main__":
    unittest.main()
