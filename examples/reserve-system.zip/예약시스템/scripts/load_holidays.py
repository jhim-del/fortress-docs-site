"""공휴일 입력 - 매년 1월

사용법: python scripts\load_holidays.py holidays_2027.csv
CSV 형식: 2027-01-01,신정   (한 줄에 하나, 대체공휴일·선거일 포함)
행정안전부 공고 보고 담당자가 CSV 만들어서 돌림
"""
import csv
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from reserve import db  # noqa: E402
from reserve.validators import check_date_str  # noqa: E402


def main(path):
    conn = db.connect()
    n = 0
    with open(path, encoding="utf-8-sig") as f:
        for row in csv.reader(f):
            if not row or row[0].startswith("#"):
                continue
            day = check_date_str(row[0].strip())
            title = row[1].strip() if len(row) > 1 else ""
            conn.execute("INSERT OR REPLACE INTO holiday (holiday_date, title) VALUES (?, ?)", (day, title))
            n += 1
    conn.commit()
    print("입력 %d건" % n)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(1)
    main(sys.argv[1])
