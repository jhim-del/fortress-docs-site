"""매일 02:00 (작업 스케줄러)

1) 미결제 신청 자동 취소
2) 내일 이용자 안내 문자

규정은 신청 후 24시간인데 reservation 에 신청 시각 컬럼이 없어서
이용일 2일 전까지 결제 안 된 건을 취소한다. TODO: 신청 시각 컬럼 추가 (DB 변경 승인 필요)
"""
import logging
import os
import sys
from datetime import date, timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from reserve import config, db, holiday, notification  # noqa: E402
from reserve.calendar_util import fmt_date  # noqa: E402

log = logging.getLogger("reserve.batch")


def expire_unpaid(conn, today):
    limit = fmt_date(today + timedelta(days=2))
    rows = conn.execute(
        "SELECT r.reserve_id FROM reservation r JOIN member m ON m.member_id = r.member_id "
        "WHERE r.status = 'REQUESTED' AND r.reserve_date <= ? AND m.grade <> 'STAFF'",
        (limit,),
    ).fetchall()
    for r in rows:
        conn.execute("UPDATE reservation SET status = 'CANCELED' WHERE reserve_id = ?", (r[0],))
        notification.notify_reservation(conn, r[0], "CANCELED")
    conn.commit()
    return len(rows)


def remind_tomorrow(conn, today):
    tomorrow = fmt_date(today + timedelta(days=1))
    rows = conn.execute(
        "SELECT reserve_id FROM reservation WHERE status = 'CONFIRMED' AND reserve_date = ?",
        (tomorrow,),
    ).fetchall()
    sent = 0
    for r in rows:
        if notification.notify_reservation(conn, r[0], "REMIND"):
            sent += 1
    return sent


def main():
    os.makedirs(config.LOG_DIR, exist_ok=True)
    logging.basicConfig(filename=os.path.join(config.LOG_DIR, "batch.log"), level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s", encoding="utf-8")
    conn = db.connect()
    holiday.load(conn)
    today = date.today()
    n1 = expire_unpaid(conn, today)
    n2 = remind_tomorrow(conn, today)
    log.info("batch %s expire=%d remind=%d", today, n1, n2)


if __name__ == "__main__":
    main()
