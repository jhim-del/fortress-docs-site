#!/bin/sh
# 일일 정산 배치
. /home/hanshop/.profile
LOG=/home/hanshop/logs/settle_`date +%Y%m%d`.log
echo "start `date`" >> $LOG
sqlplus -s hanshop/Hanshop!2013@HANDB <<SQL >> $LOG
EXEC SP_DAILY_SETTLE;
EXIT;
SQL
java -cp /home/hanshop/lib/*:/home/hanshop/classes com.hanshop.settle.SettleBatchMain >> $LOG 2>&1
echo "end `date`" >> $LOG
