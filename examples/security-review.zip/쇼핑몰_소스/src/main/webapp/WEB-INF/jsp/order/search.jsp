<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html><body>
<h2>주문 검색</h2>
<form action="/hanshop/order/search.do">
  주문번호 <input name="keyword" value="<%= request.getParameter("keyword") %>">
  상태 <select name="status"><option value="">전체</option><option>PAID</option><option>SETTLED</option><option>CANCELED</option></select>
  <button>검색</button>
</form>
<table>
<c:forEach var="o" items="${list}">
  <tr><td>${o.ORDER_NO}</td><td>${o.PARTNER_ID}</td><td>${o.PAY_TYPE}</td><td>${o.AMOUNT}</td><td>${o.STATUS}</td>
  <td><a href="/hanshop/order/cancel.do?orderNo=${o.ORDER_NO}">취소</a></td></tr>
</c:forEach>
</table>
</body></html>
