package com.hanshop.common;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {
    public static String format(Date d, String pattern) {
        return new SimpleDateFormat(pattern).format(d);
    }
}
