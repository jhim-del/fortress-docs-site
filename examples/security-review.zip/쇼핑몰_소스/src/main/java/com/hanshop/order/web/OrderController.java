package com.hanshop.order.web;

import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.hanshop.order.service.OrderService;

@Controller
public class OrderController {

    @Autowired
    private OrderService orderService;

    /** 주문 검색 (관리자) */
    @RequestMapping("/order/search.do")
    public String search(HttpServletRequest req, Model model) {
        String keyword = req.getParameter("keyword");
        String status = req.getParameter("status");
        List<Map> list = orderService.searchOrders(keyword, status);
        model.addAttribute("list", list);
        return "order/search";
    }

    /** 주문 생성 */
    @RequestMapping("/order/create.do")
    public String create(HttpServletRequest req, Model model) {
        String partnerId = req.getParameter("partnerId");
        String payType = req.getParameter("payType");      // CARD, BANK, VACCT
        long amount = Long.parseLong(req.getParameter("amount"));
        String orderNo = orderService.createOrder(partnerId, payType, amount);
        model.addAttribute("orderNo", orderNo);
        return "order/complete";
    }

    /** 주문 취소 */
    @RequestMapping("/order/cancel.do")
    public String cancel(HttpServletRequest req, Model model) {
        orderService.cancelOrder(req.getParameter("orderNo"));
        return "redirect:/order/search.do";
    }
}
