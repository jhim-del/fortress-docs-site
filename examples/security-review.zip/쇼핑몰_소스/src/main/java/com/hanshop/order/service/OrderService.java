package com.hanshop.order.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.stereotype.Service;
import com.hanshop.common.DateUtil;

@Service
public class OrderService {

    @Autowired
    private SqlMapClientTemplate sqlMap;

    public List<Map> searchOrders(String keyword, String status) {
        Map p = new HashMap();
        p.put("keyword", keyword);
        p.put("status", status);
        return sqlMap.queryForList("Order.search", p);
    }

    public String createOrder(String partnerId, String payType, long amount) {
        String orderNo = "OD" + DateUtil.format(new Date(), "yyyyMMddHHmmssSSS");
        Map p = new HashMap();
        p.put("orderNo", orderNo);
        p.put("partnerId", partnerId);
        p.put("payType", payType);
        p.put("amount", amount);
        p.put("status", "PAID");
        sqlMap.insert("Order.insert", p);
        return orderNo;
    }

    /**
     * 주문 취소.
     * 이미 정산된 주문(SETTLED)은 원주문을 건드리지 않고 다음 정산 때 차감되도록 조정 테이블에 넣는다.
     * (2014.02 재무팀 요청 - 정산 확정분 수정 금지)
     */
    public void cancelOrder(String orderNo) {
        Map order = (Map) sqlMap.queryForObject("Order.get", orderNo);
        String status = (String) order.get("STATUS");
        if ("SETTLED".equals(status)) {
            Map adj = new HashMap();
            adj.put("orderNo", orderNo);
            adj.put("partnerId", order.get("PARTNER_ID"));
            adj.put("adjAmount", -((Number) order.get("AMOUNT")).longValue());
            adj.put("reason", "CANCEL_AFTER_SETTLE");
            sqlMap.insert("Settle.insertAdjust", adj);
            sqlMap.update("Order.updateStatus", map("orderNo", orderNo, "status", "CANCEL_ADJ"));
        } else {
            sqlMap.update("Order.updateStatus", map("orderNo", orderNo, "status", "CANCELED"));
        }
    }

    private Map map(String k1, Object v1, String k2, Object v2) {
        Map m = new HashMap(); m.put(k1, v1); m.put(k2, v2); return m;
    }
}
