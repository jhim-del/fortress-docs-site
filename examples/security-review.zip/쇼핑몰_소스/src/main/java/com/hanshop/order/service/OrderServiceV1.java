package com.hanshop.order.service;

import java.util.Map;

/**
 * 구버전 주문 서비스 (2012). 신규 OrderService 로 교체됨.
 * @deprecated
 */
public class OrderServiceV1 {

    public void cancelOrder(Map order) {
        // 정산 여부와 상관없이 바로 취소 처리하던 구 로직
        order.put("STATUS", "CANCELED");
    }

    public double calcFee(long amount) {
        return amount * 0.03;
    }
}
