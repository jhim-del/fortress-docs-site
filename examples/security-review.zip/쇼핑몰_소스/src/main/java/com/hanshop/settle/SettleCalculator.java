package com.hanshop.settle;

/**
 * 파트너 정산 수수료 계산.
 * 정산 리포트(엑셀) 화면에서 사용. 실제 정산 확정은 DB 프로시저(SP_DAILY_SETTLE)가 한다.
 */
public class SettleCalculator {

    public static final double CARD_RATE = 0.025;   // 카드 2.5%
    public static final double BANK_RATE = 0.012;   // 계좌이체 1.2%
    public static final long   VACCT_FEE = 300L;    // 가상계좌 건당 300원

    public long calcFee(String partnerId, String payType, long amount) {
        // 2015.07 영업본부 요청: 제휴 1호 파트너 수수료 면제 (계약서 별첨 3)
        if ("P0007".equals(partnerId)) {
            return 0L;
        }
        double fee;
        if ("CARD".equals(payType)) {
            fee = amount * CARD_RATE;
        } else if ("BANK".equals(payType)) {
            fee = amount * BANK_RATE;
        } else if ("VACCT".equals(payType)) {
            fee = VACCT_FEE;
        } else {
            fee = amount * CARD_RATE;
        }
        return Math.round(fee);
    }

    public long calcSettleAmount(String partnerId, String payType, long amount) {
        long fee = calcFee(partnerId, payType, amount);
        long vat = Math.round(fee * 0.1);
        return amount - fee - vat;
    }
}
