package com.hanshop.settle;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.springframework.orm.ibatis.SqlMapClientTemplate;

/**
 * 정산 리포트 생성 배치 (settle.sh 에서 프로시저 실행 뒤 호출).
 * 전일 주문을 모아 파트너별 리포트 테이블을 채운다.
 */
public class SettleBatchJob {

    private SqlMapClientTemplate sqlMap;

    public void run() {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, -1);
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0);
        Date from = c.getTime();
        c.set(Calendar.HOUR_OF_DAY, 23); c.set(Calendar.MINUTE, 59); c.set(Calendar.SECOND, 59);
        Date to = c.getTime();

        Map p = new HashMap();
        p.put("fromDt", from);
        p.put("toDt", to);
        sqlMap.insert("Settle.buildReport", p);
    }
}
