한샵 주문/정산 시스템 (HANSHOP-OMS)
작성: 2013.04 개발1팀

- 빌드: mvn package (JDK 1.6)
- 배포: WAS(JEUS 6) /hanshop
- 정산 배치는 매일 01:00 에 돈다 (batch/settle.sh)
- 문의: 김OO 과장 (퇴사)
