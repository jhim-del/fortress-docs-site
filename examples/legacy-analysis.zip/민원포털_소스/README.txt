전자정부 표준프레임워크 기반 통합 포털 (2016 구축, 2019 고도화)
- 빌드: mvn package / WAS: JEUS 7
- 배치: 통계 집계는 매일 02:00 (batch/batch.properties)
- 담당: 구축사 철수, 문서는 이 파일뿐
