package egov.portal.cmm.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Repository("cmmUseDAO")
public class CmmUseDAO extends EgovAbstractMapper {

    public List<EgovMap> selectCmmCodeDetail(String codeId) throws Exception {
        return selectList("cmmUseDAO.selectCmmCodeDetail", codeId);
    }

    public List<EgovMap> selectRestdeList(Map<String, String> p) throws Exception {
        return selectList("cmmUseDAO.selectRestdeList", p);
    }

    public List<EgovMap> selectDeptList() throws Exception {
        return selectList("cmmUseDAO.selectDeptList");
    }

    public List<EgovMap> selectEmplList(String deptCode) throws Exception {
        return selectList("cmmUseDAO.selectEmplList", deptCode);
    }
}
