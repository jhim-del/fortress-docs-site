package egov.portal.cmm.web;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import egov.portal.bbs.inq.service.BbsInqService;
import egov.portal.bbs.inq.service.BbsNttVO;
import egov.portal.civil.req.service.CivilReqService;
import egov.portal.cmm.LoginVO;

/**
 * @Class Name : MainController.java
 * @Description : 사용자·관리자 메인
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.04.05      kjh          최초생성
 * @ 2019.08.12      ywk          내 민원 현황 박스 추가, 팝업창 제거
 * @author 통합포털 구축 kjh
 * @since 2016.04.05
 */
@Controller
public class MainController {

    @Resource(name = "bbsInqService")
    private BbsInqService bbsInqService;

    // @Resource(name = "popupService")
    // private PopupService popupService;

    @Resource(name = "civilReqService")
    private CivilReqService civilReqService;

    @RequestMapping("/main.do")
    public String main(HttpSession session, ModelMap model) throws Exception {
        BbsNttVO ntt = new BbsNttVO();
        ntt.setBbsId("BBSMSTR_000000000001"); // 공지사항
        ntt.setRecordCountPerPage(5);
        ntt.setFirstIndex(0);
        model.addAttribute("noticeList", bbsInqService.selectNttList(ntt));

        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        if (user != null && "GNR".equals(user.getUserSe())) {
            model.addAttribute("myCivilSttus", civilReqService.selectMyReqSttus(user.getId()));
        }
        return "portal/main";
    }

    @RequestMapping("/mng/main.do")
    public String mngMain(ModelMap model) throws Exception {
        return "mng/main";
    }
}
