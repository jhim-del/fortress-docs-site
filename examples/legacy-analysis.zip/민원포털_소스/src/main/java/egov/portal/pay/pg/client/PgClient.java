package egov.portal.pay.pg.client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import egov.portal.cmm.util.PortalProperties;

/**
 * PG 중계 서버 호출 (내부망 → 중계 서버 → PG사)
 * <p>
 * 서명: 파라미터를 키 이름 순으로 이어 붙인 뒤 signKey 를 더해 SHA-256
 *
 * @author ywk
 * @since 2019.08.19
 */
@Component("pgClient")
public class PgClient {

    private final ObjectMapper om = new ObjectMapper();

    public String sign(Map<String, String> params) throws Exception {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : new TreeMap<String, String>(params).entrySet()) {
            sb.append(e.getKey()).append('=').append(e.getValue()).append('&');
        }
        sb.append("key=").append(PortalProperties.getProperty("pg.signKey"));
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] h = md.digest(sb.toString().getBytes(StandardCharsets.UTF_8));
        StringBuilder hex = new StringBuilder();
        for (byte b : h) {
            hex.append(String.format("%02x", b));
        }
        return hex.toString();
    }

    public boolean verify(Map<String, String> params, String signature) throws Exception {
        return sign(params).equalsIgnoreCase(signature);
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> post(String path, Map<String, String> params) throws Exception {
        params.put("mid", PortalProperties.getProperty("pg.mid"));
        params.put("signature", sign(params));

        StringBuilder body = new StringBuilder();
        for (Map.Entry<String, String> e : params.entrySet()) {
            if (body.length() > 0) {
                body.append('&');
            }
            body.append(e.getKey()).append('=').append(URLEncoder.encode(e.getValue(), "UTF-8"));
        }

        URL url = new URL(PortalProperties.getProperty("pg.relayUrl") + path);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        con.setConnectTimeout(PortalProperties.getInt("pg.connTimeout", 5000));
        con.setReadTimeout(PortalProperties.getInt("pg.readTimeout", 15000));
        con.setDoOutput(true);
        con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
        try (OutputStream os = con.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }

        StringBuilder res = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(
                con.getResponseCode() < 400 ? con.getInputStream() : con.getErrorStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                res.append(line);
            }
        }
        return om.readValue(res.toString(), Map.class);
    }
}
