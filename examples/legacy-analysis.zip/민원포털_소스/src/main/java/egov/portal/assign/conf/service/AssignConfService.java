package egov.portal.assign.conf.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import egov.portal.assign.conf.service.impl.AssignConfMapper;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * 민원 담당자 배정 설정·자동 배정
 * <p>
 * 부서별 담당자 순번(TB_ASGN_CHARGER)에 따라 가장 오래 배정받지 않은 담당자에게 배정한다.
 * 휴가·출장자(TB_EMPLYR_ABSNCE, 인사 연계)는 제외.
 *
 * @author jdh
 * @since 2019.11.04
 */
@Service("assignConfService")
public class AssignConfService extends EgovAbstractServiceImpl {

    private static final Logger LOGGER = LoggerFactory.getLogger(AssignConfService.class);

    @Resource(name = "assignConfMapper")
    private AssignConfMapper assignConfMapper;

    public List<EgovMap> selectChargerList(String deptCd) throws Exception {
        return assignConfMapper.selectDeptChargerList(deptCd);
    }

    public List<EgovMap> selectAsgnSttusByDept() throws Exception {
        return assignConfMapper.selectAsgnSttusByDept();
    }

    public void saveCharger(AssignConfVO vo) throws Exception {
        assignConfMapper.mergeCharger(vo);
    }

    public void changeAsgnYn(AssignConfVO vo) throws Exception {
        assignConfMapper.updateAsgnYn(vo);
    }

    public void changeOrdr(List<AssignConfVO> list) throws Exception {
        for (AssignConfVO vo : list) {
            assignConfMapper.updateAsgnOrdr(vo);
        }
    }

    /**
     * 담당자 자동 배정.
     * 부서코드 D07(감사실) 민원은 자동 배정하지 않고 수동 배정 대기 (2019.11 감사실 요청: 민감 민원 직접 배분)
     * @param param CIVIL_RCPT_NO, DEPT_CD 입력 / PROC_STTUS_CODE, CHARGER_ID 결과
     */
    public void autoAssign(Map<String, Object> param) throws Exception {
        String deptCd = (String) param.get("DEPT_CD");
        if ("D07".equals(deptCd)) {
            param.put("PROC_STTUS_CODE", "WAIT_MANUAL");
            return;
        }

        EgovMap next = assignConfMapper.selectNextCharger(param);
        if (next == null) {
            // 배정 대상자 없음 → 접수 상태로 두고 부서 관리자가 배정
            LOGGER.warn("자동 배정 대상 없음 dept={} rcptNo={}", deptCd, param.get("CIVIL_RCPT_NO"));
            return;
        }
        param.put("CHARGER_ID", next.get("chargerId"));
        param.put("PROC_STTUS_CODE", "ASGN");
        param.put("ASGN_TY", "AUTO");
        assignConfMapper.insertAsgnHist(param);
        assignConfMapper.updateLastAsgnDt(param);
    }
}
