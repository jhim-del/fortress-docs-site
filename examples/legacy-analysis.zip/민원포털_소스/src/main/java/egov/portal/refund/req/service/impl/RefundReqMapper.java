package egov.portal.refund.req.service.impl;

import java.util.List;
import java.util.Map;

import egovframework.rte.psl.dataaccess.mapper.Mapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * 환불 신청 매퍼
 *
 * @author jdh
 * @since 2019.10.01
 */
@Mapper("refundReqMapper")
public interface RefundReqMapper {

    EgovMap selectRefundTarget(Map<String, Object> p) throws Exception;
    int selectReqDupCnt(String stlmId) throws Exception;
    void insertRefundReq(Map<String, Object> p) throws Exception;

}
