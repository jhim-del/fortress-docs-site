package egov.portal.bbs.mstr.service;

import java.io.Serializable;
import egov.portal.cmm.ComDefaultVO;

/**
 * 게시판 마스터 VO
 * @author chw
 * @since 2016.04.25
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2016.04.25  chw       최초 생성
 *   2019.10.28  sbk       비밀글 사용여부 추가
 * </pre>
 */
public class BbsMstrVO extends ComDefaultVO {

    private static final long serialVersionUID = 356139381747544806L;

    /** 게시판ID */
    private String bbsId;
    /** 게시판명 */
    private String bbsNm;
    /** 게시판 유형(NOTICE/QNA/DATA) */
    private String bbsTyCode;
    /** 답글 가능 */
    private String replyPosblAt;
    /** 첨부 가능 */
    private String fileAtchPosblAt;
    /** 첨부 가능 개수 */
    private int atchPosblFileNumber;
    /** 비밀글 가능 */
    private String secretPosblAt;
    /** 비회원 작성 */
    private String nonmbrWritngAt;
    /** 사용여부 */
    private String useAt;

    public String getBbsId() { return bbsId; }
    public void setBbsId(String bbsId) { this.bbsId = bbsId; }
    public String getBbsNm() { return bbsNm; }
    public void setBbsNm(String bbsNm) { this.bbsNm = bbsNm; }
    public String getBbsTyCode() { return bbsTyCode; }
    public void setBbsTyCode(String bbsTyCode) { this.bbsTyCode = bbsTyCode; }
    public String getReplyPosblAt() { return replyPosblAt; }
    public void setReplyPosblAt(String replyPosblAt) { this.replyPosblAt = replyPosblAt; }
    public String getFileAtchPosblAt() { return fileAtchPosblAt; }
    public void setFileAtchPosblAt(String fileAtchPosblAt) { this.fileAtchPosblAt = fileAtchPosblAt; }
    public int getAtchPosblFileNumber() { return atchPosblFileNumber; }
    public void setAtchPosblFileNumber(int atchPosblFileNumber) { this.atchPosblFileNumber = atchPosblFileNumber; }
    public String getSecretPosblAt() { return secretPosblAt; }
    public void setSecretPosblAt(String secretPosblAt) { this.secretPosblAt = secretPosblAt; }
    public String getNonmbrWritngAt() { return nonmbrWritngAt; }
    public void setNonmbrWritngAt(String nonmbrWritngAt) { this.nonmbrWritngAt = nonmbrWritngAt; }
    public String getUseAt() { return useAt; }
    public void setUseAt(String useAt) { this.useAt = useAt; }
}
