package egov.portal.rsv.apply.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egov.portal.cmm.exception.BizException;
import egov.portal.cmm.service.CmmUseService;
import egov.portal.cmm.util.PortalDateUtil;
import egov.portal.noti.link.service.NotiLinkService;
import egov.portal.pay.pg.service.PayService;
import egov.portal.rsv.apply.service.RsvApplyService;
import egov.portal.rsv.apply.service.RsvApplyVO;
import egov.portal.rsv.fac.service.FacService;
import egov.portal.rsv.fac.service.FacVO;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.fdl.idgnr.EgovIdGnrService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * 시설 예약 신청 구현
 * @author lsy
 * @since 2016.05.20
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2016.05.20  lsy       최초 생성
 *   2017.05.08  pms       동시 신청 중복 예약 조치(시설 행 잠금)
 *   2019.08.26  jdh       유료 시설 결제 연동, 취소 위약금
 *   2019.10.01  jdh       입금전용계좌 취소는 환불 신청으로
 * </pre>
 */
@Service("rsvApplyService")
public class RsvApplyServiceImpl extends EgovAbstractServiceImpl implements RsvApplyService {

    @Resource(name = "rsvApplyDAO")
    private RsvApplyDAO rsvApplyDAO;

    @Resource(name = "facService")
    private FacService facService;

    @Resource(name = "cmmUseService")
    private CmmUseService cmmUseService;

    @Resource(name = "rsvIdGnrService")
    private EgovIdGnrService idgen;

    @Resource(name = "payService")
    private PayService payService;

    @Resource(name = "notiLinkService")
    private NotiLinkService notiLinkService;

    @Override
    public List<EgovMap> selectMonthResveSttus(RsvApplyVO vo) throws Exception {
        return rsvApplyDAO.selectMonthResveSttus(vo);
    }

    /**
     * 운영시간을 예약 단위로 잘라 칸마다 예약 가능 여부를 표시한다.
     */
    @Override
    public List<EgovMap> selectDayTimeSlot(RsvApplyVO vo) throws Exception {
        FacVO fac = facService.selectFac(vo.getFcltyId());
        List<EgovMap> booked = rsvApplyDAO.selectDayResveList(vo);
        List<EgovMap> slots = new ArrayList<EgovMap>();

        boolean closed = isClosedDay(fac, vo.getResveDe());
        int unit = fac.getResveUnitMin();
        int t = toMin(fac.getOpnBeginTime());
        int end = toMin(fac.getOpnEndTime());
        while (t + unit <= end) {
            String b = toHHmm(t), e = toHHmm(t + unit);
            EgovMap s = new EgovMap();
            s.put("beginTime", b);
            s.put("endTime", e);
            boolean used = false;
            for (EgovMap r : booked) {
                if (b.compareTo((String) r.get("endTime")) < 0 && e.compareTo((String) r.get("beginTime")) > 0) {
                    used = true;
                    break;
                }
            }
            s.put("posblAt", closed || used ? "N" : "Y");
            slots.add(s);
            t += unit;
        }
        return slots;
    }

    @Override
    public String insertResve(RsvApplyVO vo) throws Exception {
        // 2017.05 동시에 같은 시간 신청 시 둘 다 들어가는 문제 → 시설 행 잠금 후 중복 확인
        FacVO fac = rsvApplyDAO.selectFacForUpdate(vo.getFcltyId());
        if (fac == null || !"Y".equals(fac.getUseAt())) {
            throw new BizException("rsv.fac.notUse");
        }
        if (isClosedDay(fac, vo.getResveDe())) {
            throw new BizException("rsv.closed");
        }
        if (vo.getNmpr() > fac.getAceptncNmpr()) {
            throw new BizException("rsv.nmpr.over", fac.getAceptncNmpr());
        }
        if (rsvApplyDAO.selectDupResveCnt(vo) > 0) {
            throw new BizException("rsv.duplicate");
        }

        int hours = (toMin(vo.getEndTime()) - toMin(vo.getBeginTime())) / 60;
        vo.setChrgeAmt((long) fac.getUseChrge() * Math.max(hours, 1));
        vo.setResveId(idgen.getNextStringId());

        if (vo.getChrgeAmt() > 0) {
            vo.setResveSttusCode("PAY_WAIT");
        } else {
            vo.setResveSttusCode("Y".equals(fac.getAprvNeedAt()) ? "REQ" : "CONF");
        }
        rsvApplyDAO.insertResve(vo);

        if ("CONF".equals(vo.getResveSttusCode())) {
            notiLinkService.sendSms(vo.getMbtlnum(), "[통합 민원 포털] " + fac.getFcltyNm() + " "
                    + PortalDateUtil.formatDate(vo.getResveDe(), ".") + " " + vo.getBeginTime().substring(0, 2) + "시 예약이 확정되었습니다.");
        }
        return vo.getResveId();
    }

    @Override
    public List<EgovMap> selectMyResveList(RsvApplyVO vo) throws Exception {
        return rsvApplyDAO.selectMyResveList(vo);
    }

    /**
     * 취소 위약금 (2019.08 운영위원회 결정)
     * 이용일 2일 전까지 무료, 1일 전 30%, 당일 50%
     */
    @Override
    public long calcPnlty(RsvApplyVO vo) throws Exception {
        RsvApplyVO r = rsvApplyDAO.selectResve(vo);
        if (r.getChrgeAmt() == 0 || !"CONF".equals(r.getResveSttusCode())) {
            return 0;
        }
        long daysBefore = PortalDateUtil.daysBetween(PortalDateUtil.getToday(), r.getResveDe());
        int rate;
        if (daysBefore >= 2) {
            rate = 0;
        } else if (daysBefore == 1) {
            rate = 30;
        } else {
            rate = 50;
        }
        return r.getChrgeAmt() * rate / 100;
    }

    @Override
    public void cancelResve(RsvApplyVO vo) throws Exception {
        RsvApplyVO r = rsvApplyDAO.selectResve(vo);
        if (r == null || !vo.getApplcntId().equals(r.getApplcntId())) {
            throw new BizException("fail.common.auth");
        }
        if ("CANCL".equals(r.getResveSttusCode())) {
            return;
        }
        if (PortalDateUtil.getToday().compareTo(r.getResveDe()) > 0) {
            throw new BizException("rsv.cancel.past");
        }
        long pnlty = calcPnlty(vo);
        vo.setPnltyAmt(pnlty);
        vo.setResveSttusCode("CANCL");

        if (r.getStlmId() != null && r.getChrgeAmt() > pnlty) {
            Map<String, Object> pay = payService.selectStlm(r.getStlmId());
            if ("VBANK".equals(pay.get("stlmTy"))) {
                // 입금전용계좌는 PG 취소 불가 → 사용자가 환불 신청(계좌 입력)
                vo.setResveSttusCode("CANCL_REFUND");
            } else {
                payService.cancel(r.getStlmId(), r.getChrgeAmt() - pnlty, "시설 예약 취소");
            }
        }
        rsvApplyDAO.updateCancel(vo);
    }

    private boolean isClosedDay(FacVO fac, String ymd) throws Exception {
        if (fac.getCloseDeInfo() != null) {
            java.util.Calendar c = java.util.Calendar.getInstance();
            c.setTime(new java.text.SimpleDateFormat("yyyyMMdd").parse(ymd));
            if (("," + fac.getCloseDeInfo() + ",").contains("," + c.get(java.util.Calendar.DAY_OF_WEEK) + ",")) {
                return true;
            }
        }
        Set<String> restde = cmmUseService.selectRestdeSet(ymd, ymd);
        return !restde.isEmpty();
    }

    private static int toMin(String hhmm) {
        return Integer.parseInt(hhmm.substring(0, 2)) * 60 + Integer.parseInt(hhmm.substring(2, 4));
    }

    private static String toHHmm(int min) {
        return String.format("%02d%02d", min / 60, min % 60);
    }
}
