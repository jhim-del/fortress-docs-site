package egov.portal.cmm.file.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egov.portal.cmm.file.service.FileVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : FileManageDAO.java
 * @Description : 첨부파일 DAO
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.03.28      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.03.28
 */
@Repository("fileManageDAO")
public class FileManageDAO extends EgovAbstractMapper {

    /** 첨부 목록 */
    public List<FileVO> selectFileList(FileVO vo) throws Exception {
        return selectList("fileManageDAO.selectFileList", vo);
    }

    /** 첨부 1건 */
    public FileVO selectFile(FileVO vo) throws Exception {
        return (FileVO) selectOne("fileManageDAO.selectFile", vo);
    }

    /** 첨부 묶음 등록 */
    public void insertFileMaster(FileVO vo) throws Exception {
        insert("fileManageDAO.insertFileMaster", vo);
    }

    /** 첨부 상세 등록 */
    public void insertFileDetail(FileVO vo) throws Exception {
        insert("fileManageDAO.insertFileDetail", vo);
    }

    /** 첨부 상세 삭제(사용여부 N) */
    public int deleteFileDetail(FileVO vo) throws Exception {
        return update("fileManageDAO.deleteFileDetail", vo);
    }

    /**
     * 묶음 내 최대 파일연번
     */
    public int selectMaxFileSn(String atchFileId) throws Exception {
        Integer sn = (Integer) selectOne("fileManageDAO.selectMaxFileSn", atchFileId);
        return sn == null ? 0 : sn;
    }
}
