package egov.portal.link.hr.service.impl;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

@Repository("hrSyncDAO")
public class HrSyncDAO extends EgovAbstractMapper {

    public int mergeDept() {
        return update("hrSyncDAO.mergeDept");
    }

    public int updateClosedDept() {
        return update("hrSyncDAO.updateClosedDept");
    }

    public int mergeEmplyr() {
        return update("hrSyncDAO.mergeEmplyr");
    }

    public int updateRetireEmplyr() {
        return update("hrSyncDAO.updateRetireEmplyr");
    }

    public void deleteAbsnce() {
        delete("hrSyncDAO.deleteAbsnce");
    }

    public int insertAbsnce() {
        return insert("hrSyncDAO.insertAbsnce");
    }
}
