package egov.portal.rsv.fac.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egov.portal.rsv.fac.service.FacVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : FacDAO.java
 * @Description : 시설 정보 DAO
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.05.16      pms          최초생성
 * @author 통합포털 구축 pms
 * @since 2016.05.16
 */
@Repository("facDAO")
public class FacDAO extends EgovAbstractMapper {

    /** 시설 상세 */
    public FacVO selectFac(String vo) throws Exception {
        return (FacVO) selectOne("facDAO.selectFac", vo);
    }

    /** 사용 중 시설 */
    public List<EgovMap> selectUseFacList(Object vo) throws Exception {
        return selectList("facDAO.selectUseFacList", vo);
    }

}
