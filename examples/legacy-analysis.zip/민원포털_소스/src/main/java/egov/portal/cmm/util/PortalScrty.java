package egov.portal.cmm.util;

import java.security.MessageDigest;

import org.apache.commons.codec.binary.Base64;

/**
 * @Class Name : PortalScrty.java
 * @Description : 비밀번호 단방향 암호화
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.04.04      kjh          최초생성
 * @ 2017.02.14      pms          SHA-256 + 아이디 솔트 (보안점검 조치, 기존 MD5 계정은 로그인 시 변환)
 * @author 통합포털 구축 kjh
 * @since 2016.04.04
 */
public final class PortalScrty {

    private PortalScrty() {
    }

    public static String encryptPassword(String password, String id) throws Exception {
        if (password == null) {
            return "";
        }
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.reset();
        md.update(id.getBytes("UTF-8"));
        byte[] hashValue = md.digest(password.getBytes("UTF-8"));
        return new String(Base64.encodeBase64(hashValue));
    }

    /** 2017.02 이전 가입자 비밀번호 (MD5) */
    @Deprecated
    public static String encryptMd5(String password) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] h = md.digest(password.getBytes("UTF-8"));
        StringBuilder sb = new StringBuilder();
        for (byte b : h) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}
