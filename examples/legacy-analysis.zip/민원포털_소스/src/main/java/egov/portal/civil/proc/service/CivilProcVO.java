package egov.portal.civil.proc.service;

import java.io.Serializable;
import egov.portal.cmm.ComDefaultVO;

/**
 * @Class Name : CivilProcVO.java
 * @Description : 민원 처리 VO
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.04.11      kjh          최초생성
 * @ 2016.09.02      lsy          이송 항목 추가
 * @author 통합포털 구축 kjh
 * @since 2016.04.11
 */
public class CivilProcVO extends ComDefaultVO {

    private static final long serialVersionUID = 515016405389064319L;

    /** 접수번호 */
    private String civilRcptNo;
    /** 사무코드 */
    private String afairCode;
    /** 사무명 */
    private String afairNm;
    /** 제목 */
    private String civilSj;
    /** 내용 */
    private String civilCn;
    /** 신청인 */
    private String applcntNm;
    /** 신청인 휴대전화 */
    private String applcntMbtlnum;
    /** 접수일 */
    private String rcptDt;
    /** 처리기한 */
    private String procDdlnDt;
    /** 처리상태 */
    private String procSttusCode;
    /** 담당부서 */
    private String chrgDeptCode;
    /** 담당자 */
    private String chargerId;
    /** 처리결과 */
    private String procResultCn;
    /** 처리일 */
    private String procDt;
    /** 이송부서 */
    private String trnsfDeptCode;
    /** 이송사유 */
    private String trnsfResn;
    /** 최종수정자 */
    private String lastUpdusrId;
    /** 검색-상태 */
    private String searchSttus;
    /** 검색-부서 */
    private String searchDeptCode;
    /** 검색-기한초과 */
    private String searchDdlnOverAt;
    /** 조회자 권한 */
    private String authorCode;

    public String getCivilRcptNo() { return civilRcptNo; }
    public void setCivilRcptNo(String civilRcptNo) { this.civilRcptNo = civilRcptNo; }
    public String getAfairCode() { return afairCode; }
    public void setAfairCode(String afairCode) { this.afairCode = afairCode; }
    public String getAfairNm() { return afairNm; }
    public void setAfairNm(String afairNm) { this.afairNm = afairNm; }
    public String getCivilSj() { return civilSj; }
    public void setCivilSj(String civilSj) { this.civilSj = civilSj; }
    public String getCivilCn() { return civilCn; }
    public void setCivilCn(String civilCn) { this.civilCn = civilCn; }
    public String getApplcntNm() { return applcntNm; }
    public void setApplcntNm(String applcntNm) { this.applcntNm = applcntNm; }
    public String getApplcntMbtlnum() { return applcntMbtlnum; }
    public void setApplcntMbtlnum(String applcntMbtlnum) { this.applcntMbtlnum = applcntMbtlnum; }
    public String getRcptDt() { return rcptDt; }
    public void setRcptDt(String rcptDt) { this.rcptDt = rcptDt; }
    public String getProcDdlnDt() { return procDdlnDt; }
    public void setProcDdlnDt(String procDdlnDt) { this.procDdlnDt = procDdlnDt; }
    public String getProcSttusCode() { return procSttusCode; }
    public void setProcSttusCode(String procSttusCode) { this.procSttusCode = procSttusCode; }
    public String getChrgDeptCode() { return chrgDeptCode; }
    public void setChrgDeptCode(String chrgDeptCode) { this.chrgDeptCode = chrgDeptCode; }
    public String getChargerId() { return chargerId; }
    public void setChargerId(String chargerId) { this.chargerId = chargerId; }
    public String getProcResultCn() { return procResultCn; }
    public void setProcResultCn(String procResultCn) { this.procResultCn = procResultCn; }
    public String getProcDt() { return procDt; }
    public void setProcDt(String procDt) { this.procDt = procDt; }
    public String getTrnsfDeptCode() { return trnsfDeptCode; }
    public void setTrnsfDeptCode(String trnsfDeptCode) { this.trnsfDeptCode = trnsfDeptCode; }
    public String getTrnsfResn() { return trnsfResn; }
    public void setTrnsfResn(String trnsfResn) { this.trnsfResn = trnsfResn; }
    public String getLastUpdusrId() { return lastUpdusrId; }
    public void setLastUpdusrId(String lastUpdusrId) { this.lastUpdusrId = lastUpdusrId; }
    public String getSearchSttus() { return searchSttus; }
    public void setSearchSttus(String searchSttus) { this.searchSttus = searchSttus; }
    public String getSearchDeptCode() { return searchDeptCode; }
    public void setSearchDeptCode(String searchDeptCode) { this.searchDeptCode = searchDeptCode; }
    public String getSearchDdlnOverAt() { return searchDdlnOverAt; }
    public void setSearchDdlnOverAt(String searchDdlnOverAt) { this.searchDdlnOverAt = searchDdlnOverAt; }
    public String getAuthorCode() { return authorCode; }
    public void setAuthorCode(String authorCode) { this.authorCode = authorCode; }
}
