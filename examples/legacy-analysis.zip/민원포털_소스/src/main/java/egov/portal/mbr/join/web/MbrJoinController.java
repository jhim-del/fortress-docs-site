package egov.portal.mbr.join.web;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egov.portal.mbr.join.service.MbrJoinService;
import egov.portal.mbr.join.service.MbrVO;

/**
 * @Class Name : MbrJoinController.java
 * @Description : 회원가입
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.04.04      kjh          최초생성
 * @ 2016.05.30      kjh          본인확인 후 가입
 * @author 통합포털 구축 kjh
 * @since 2016.04.04
 */
@Controller
public class MbrJoinController {

    @Resource(name = "mbrJoinService")
    private MbrJoinService mbrJoinService;

    /**
     * 약관 동의
     */
    @RequestMapping("/mbr/join/joinAgree.do")
    public String joinAgree() throws Exception {
        return "portal/mbr/joinAgree";
    }

    /**
     * 가입 정보 입력. 본인확인(mbr/cert) 결과가 세션에 있어야 한다.
     */
    @RequestMapping("/mbr/join/joinForm.do")
    public String joinForm(@RequestParam Map<String, String> agre, HttpSession session, ModelMap model) throws Exception {
        @SuppressWarnings("unchecked")
        Map<String, String> cert = (Map<String, String>) session.getAttribute("certInfo");
        if (cert == null) {
            model.addAttribute("message", "본인확인을 먼저 진행해 주십시오.");
            return "portal/mbr/joinAgree";
        }
        String exist = mbrJoinService.selectMbrIdByCi(cert.get("ci"));
        if (exist != null) {
            model.addAttribute("message", "이미 가입된 회원입니다(" + exist.substring(0, 3) + "****). 아이디 찾기를 이용하십시오.");
            return "portal/mbr/joinAgree";
        }
        MbrVO vo = new MbrVO();
        vo.setMbrNm(cert.get("name"));
        vo.setBrthdy(cert.get("birthDate"));
        vo.setSexdstnCode(cert.get("gender"));
        vo.setMbtlnum(cert.get("mobileNo"));
        vo.setEmailRecptnAt(agre.get("emailAgre"));
        vo.setSmsRecptnAt(agre.get("smsAgre"));
        model.addAttribute("mbrVO", vo);
        return "portal/mbr/joinForm";
    }

    @RequestMapping("/mbr/join/idDupCheck.do")
    public String idDupCheck(@RequestParam("mbrId") String mbrId, ModelMap model) throws Exception {
        model.addAttribute("dupCnt", mbrJoinService.checkIdDup(mbrId));
        return "jsonView";
    }

    @RequestMapping("/mbr/join/join.do")
    public String join(@ModelAttribute("mbrVO") MbrVO mbrVO, HttpSession session) throws Exception {
        @SuppressWarnings("unchecked")
        Map<String, String> cert = (Map<String, String>) session.getAttribute("certInfo");
        // 이름·생년월일·휴대전화는 본인확인 값으로 덮어쓴다(화면 변조 방지)
        mbrVO.setMbrNm(cert.get("name"));
        mbrVO.setBrthdy(cert.get("birthDate"));
        mbrVO.setMbtlnum(cert.get("mobileNo"));
        mbrVO.setCi(cert.get("ci"));
        mbrVO.setDi(cert.get("di"));
        mbrJoinService.insertMbr(mbrVO);
        session.removeAttribute("certInfo");
        return "portal/mbr/joinComplete";
    }
}
