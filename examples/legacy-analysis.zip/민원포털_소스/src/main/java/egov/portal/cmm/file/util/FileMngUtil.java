package egov.portal.cmm.file.util;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import egov.portal.cmm.exception.BizException;
import egov.portal.cmm.file.service.FileVO;
import egov.portal.cmm.util.PortalDateUtil;
import egov.portal.cmm.util.PortalProperties;

/**
 * @Class Name : FileMngUtil.java
 * @Description : 업로드 파일 저장·검증
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.03.28      kjh          최초생성
 * @ 2017.02.14      pms          확장자 화이트리스트 적용(보안점검 조치)
 * @author 통합포털 구축 kjh
 * @since 2016.03.28
 */
@Component("fileMngUtil")
public class FileMngUtil {

    /**
     * 업로드 파일을 저장 경로(yyyy/MM)에 기록하고 FileVO 목록을 만든다.
     * @param files multipartRequest.getFileMap()
     * @param storePathKey globals 키 (기본 Globals.fileStorePath)
     */
    public List<FileVO> parseFileInf(Map<String, MultipartFile> files, String storePathKey) throws Exception {
        String base = PortalProperties.getProperty(storePathKey == null ? "Globals.fileStorePath" : storePathKey);
        String sub = PortalDateUtil.getToday("yyyy/MM");
        File dir = new File(base, sub);
        if (!dir.exists() && !dir.mkdirs()) {
            throw new IllegalStateException("업로드 경로 생성 실패: " + dir);
        }

        String allow = PortalProperties.getProperty("Globals.fileUpload.Extensions").toLowerCase();
        long maxSize = Long.parseLong(PortalProperties.getProperty("Globals.posblAtchFileSize"));

        List<FileVO> result = new ArrayList<FileVO>();
        Iterator<Map.Entry<String, MultipartFile>> it = files.entrySet().iterator();
        while (it.hasNext()) {
            MultipartFile mf = it.next().getValue();
            String orgName = mf.getOriginalFilename();
            if (orgName == null || "".equals(orgName)) {
                continue;
            }
            // IE 는 전체 경로가 넘어온다
            orgName = orgName.substring(orgName.lastIndexOf('\\') + 1);
            int dot = orgName.lastIndexOf('.');
            String ext = dot < 0 ? "" : orgName.substring(dot + 1).toLowerCase();
            if (ext.length() == 0 || !allow.contains("." + ext)) {
                throw new BizException("fail.file.ext", ext);
            }
            if (mf.getSize() > maxSize) {
                throw new BizException("fail.file.size", maxSize / 1024 / 1024);
            }

            String streName = UUID.randomUUID().toString().replaceAll("-", "");
            mf.transferTo(new File(dir, streName));

            FileVO f = new FileVO();
            f.setFileExtsn(ext);
            f.setFileStreCours(dir.getAbsolutePath());
            f.setFileMg(mf.getSize());
            f.setOrignlFileNm(orgName);
            f.setStreFileNm(streName);
            f.setFileCn("");
            result.add(f);
        }
        return result;
    }
}
