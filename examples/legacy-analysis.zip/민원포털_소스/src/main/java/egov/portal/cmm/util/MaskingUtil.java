package egov.portal.cmm.util;

/**
 * 개인정보 마스킹 (2019 개인정보 영향평가 조치)
 *
 * @author jdh
 * @since 2019.10.14
 */
public final class MaskingUtil {

    private MaskingUtil() {
    }

    public static String phone(String num) {
        String n = PortalStringUtil.removeHyphen(num);
        if (n == null || n.length() < 10) {
            return num;
        }
        return n.substring(0, 3) + "-****-" + n.substring(n.length() - 4);
    }

    public static String account(String acnt) {
        if (acnt == null || acnt.length() < 6) {
            return acnt;
        }
        return acnt.substring(0, 3) + "******" + acnt.substring(acnt.length() - 3);
    }
}
