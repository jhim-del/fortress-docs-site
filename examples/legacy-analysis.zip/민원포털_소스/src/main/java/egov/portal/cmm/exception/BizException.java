package egov.portal.cmm.exception;

/**
 * 업무 규칙 위반 예외 - 메시지 키를 담아 화면에 alert 로 보여준다.
 * @author ywk
 * @since 2019.07.10
 */
public class BizException extends RuntimeException {

    private static final long serialVersionUID = -2349128734198273412L;

    private final String messageKey;
    private final Object[] args;

    public BizException(String messageKey, Object... args) {
        super(messageKey);
        this.messageKey = messageKey;
        this.args = args;
    }

    public String getMessageKey() {
        return messageKey;
    }

    public Object[] getArgs() {
        return args;
    }
}
