package egov.portal.refund.aprv.service.impl;

import java.util.List;
import java.util.Map;

import egov.portal.refund.aprv.service.RefundAprvVO;

import egovframework.rte.psl.dataaccess.mapper.Mapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * 환불 승인 매퍼
 *
 * @author jdh
 * @since 2019.10.01
 */
@Mapper("refundAprvMapper")
public interface RefundAprvMapper {

    List<EgovMap> selectAprvList(RefundAprvVO vo) throws Exception;
    int selectAprvListCnt(RefundAprvVO vo) throws Exception;
    RefundAprvVO selectRefundDetail(Long refundSeq) throws Exception;
    int updateAprv(RefundAprvVO vo) throws Exception;
    int updateRjct(RefundAprvVO vo) throws Exception;
    int updateDone(Map<String, Object> p) throws Exception;
    List<EgovMap> selectAprvTransferList() throws Exception;

}
