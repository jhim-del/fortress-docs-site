package egov.portal.rsv.fac.service;

import java.io.Serializable;
import egov.portal.cmm.ComDefaultVO;

/**
 * @Class Name : FacVO.java
 * @Description : 시설 정보 VO
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.05.16      pms          최초생성
 * @author 통합포털 구축 pms
 * @since 2016.05.16
 */
public class FacVO extends ComDefaultVO {

    private static final long serialVersionUID = 669241877146519339L;

    /** 시설ID */
    private String fcltyId;
    /** 시설명 */
    private String fcltyNm;
    /** 시설구분(회의실/강당/체육) */
    private String fcltySeCode;
    /** 위치 */
    private String lc;
    /** 수용인원 */
    private int aceptncNmpr;
    /** 시간당 이용료 */
    private int useChrge;
    /** 운영 시작(HHmm) */
    private String opnBeginTime;
    /** 운영 종료(HHmm) */
    private String opnEndTime;
    /** 예약 단위(분) */
    private int resveUnitMin;
    /** 휴관 요일(1=일~7=토, 콤마) */
    private String closeDeInfo;
    /** 시설 설명 */
    private String fcltyDc;
    /** 사진 */
    private String atchFileId;
    /** 관리자 승인 필요 */
    private String aprvNeedAt;
    /** 사용여부 */
    private String useAt;

    public String getFcltyId() { return fcltyId; }
    public void setFcltyId(String fcltyId) { this.fcltyId = fcltyId; }
    public String getFcltyNm() { return fcltyNm; }
    public void setFcltyNm(String fcltyNm) { this.fcltyNm = fcltyNm; }
    public String getFcltySeCode() { return fcltySeCode; }
    public void setFcltySeCode(String fcltySeCode) { this.fcltySeCode = fcltySeCode; }
    public String getLc() { return lc; }
    public void setLc(String lc) { this.lc = lc; }
    public int getAceptncNmpr() { return aceptncNmpr; }
    public void setAceptncNmpr(int aceptncNmpr) { this.aceptncNmpr = aceptncNmpr; }
    public int getUseChrge() { return useChrge; }
    public void setUseChrge(int useChrge) { this.useChrge = useChrge; }
    public String getOpnBeginTime() { return opnBeginTime; }
    public void setOpnBeginTime(String opnBeginTime) { this.opnBeginTime = opnBeginTime; }
    public String getOpnEndTime() { return opnEndTime; }
    public void setOpnEndTime(String opnEndTime) { this.opnEndTime = opnEndTime; }
    public int getResveUnitMin() { return resveUnitMin; }
    public void setResveUnitMin(int resveUnitMin) { this.resveUnitMin = resveUnitMin; }
    public String getCloseDeInfo() { return closeDeInfo; }
    public void setCloseDeInfo(String closeDeInfo) { this.closeDeInfo = closeDeInfo; }
    public String getFcltyDc() { return fcltyDc; }
    public void setFcltyDc(String fcltyDc) { this.fcltyDc = fcltyDc; }
    public String getAtchFileId() { return atchFileId; }
    public void setAtchFileId(String atchFileId) { this.atchFileId = atchFileId; }
    public String getAprvNeedAt() { return aprvNeedAt; }
    public void setAprvNeedAt(String aprvNeedAt) { this.aprvNeedAt = aprvNeedAt; }
    public String getUseAt() { return useAt; }
    public void setUseAt(String useAt) { this.useAt = useAt; }
}
