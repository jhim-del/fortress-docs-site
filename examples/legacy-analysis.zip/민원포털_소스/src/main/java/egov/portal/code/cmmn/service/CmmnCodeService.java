package egov.portal.code.cmmn.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : CmmnCodeService.java
 * @Description : 공통코드 관리
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.03.25      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.03.25
 */
public interface CmmnCodeService {

    /** 코드ID 목록 */
    List<EgovMap> selectCodeIdList(CmmnCodeVO vo) throws Exception;

    /** 상세코드 목록 */
    List<EgovMap> selectCodeDetailList(String codeId) throws Exception;

    /** 코드ID 저장 */
    void saveCodeId(CmmnCodeVO vo) throws Exception;

    /** 상세코드 저장 */
    void saveCodeDetail(CmmnCodeVO vo) throws Exception;
}
