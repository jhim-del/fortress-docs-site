package egov.portal.stat.inq.service.impl;

import java.util.List;
import java.util.Map;

import egovframework.rte.psl.dataaccess.mapper.Mapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * 통계 조회 매퍼
 *
 * @author jdh
 * @since 2019.11.11
 */
@Mapper("statInqMapper")
public interface StatInqMapper {

    List<EgovMap> selectCivilStatByDept(Map<String, Object> p) throws Exception;
    List<EgovMap> selectCivilStatByAfair(Map<String, Object> p) throws Exception;
    List<EgovMap> selectCivilStatMonthly(Map<String, Object> p) throws Exception;
    EgovMap selectLastBatchLog() throws Exception;

}
