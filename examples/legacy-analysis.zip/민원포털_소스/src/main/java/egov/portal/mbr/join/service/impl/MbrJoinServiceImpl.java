package egov.portal.mbr.join.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egov.portal.cmm.exception.BizException;
import egov.portal.cmm.util.PortalScrty;
import egov.portal.mbr.join.service.MbrJoinService;
import egov.portal.mbr.join.service.MbrVO;
import egov.portal.noti.link.service.NotiLinkService;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * @Class Name : MbrJoinServiceImpl.java
 * @Description : 회원가입 구현
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.04.04      kjh          최초생성
 * @ 2016.05.30      kjh          본인확인 CI 중복가입 차단
 * @ 2019.09.30      jdh          가입 환영 메일 알림 연계
 * @author 통합포털 구축 kjh
 * @since 2016.04.04
 */
@Service("mbrJoinService")
public class MbrJoinServiceImpl extends EgovAbstractServiceImpl implements MbrJoinService {

    /** 비밀번호: 영문·숫자·특수문자 조합 9자 이상 (2017 보안점검) */
    private static final String PW_RULE = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[^A-Za-z\\d]).{9,20}$";

    @Resource(name = "mbrJoinDAO")
    private MbrJoinDAO mbrJoinDAO;

    @Resource(name = "notiLinkService")
    private NotiLinkService notiLinkService;

    @Override
    public int checkIdDup(String mbrId) throws Exception {
        return mbrJoinDAO.selectIdDupCnt(mbrId);
    }

    @Override
    public String selectMbrIdByCi(String ci) throws Exception {
        return mbrJoinDAO.selectMbrIdByCi(ci);
    }

    @Override
    public void insertMbr(MbrVO vo) throws Exception {
        if (!vo.getMbrId().matches("^[a-z][a-z0-9]{5,19}$")) {
            throw new BizException("mbr.id.rule");
        }
        if (!vo.getPassword().matches(PW_RULE) || vo.getPassword().contains(vo.getMbrId())) {
            throw new BizException("mbr.pw.rule");
        }
        if (!vo.getPassword().equals(vo.getPasswordCnfirm())) {
            throw new BizException("mbr.pw.cnfirm");
        }
        if (mbrJoinDAO.selectIdDupCnt(vo.getMbrId()) > 0) {
            throw new BizException("mbr.id.duplicate");
        }
        if (vo.getCi() != null && mbrJoinDAO.selectMbrIdByCi(vo.getCi()) != null) {
            throw new BizException("mbr.ci.duplicate");
        }

        vo.setPassword(PortalScrty.encryptPassword(vo.getPassword(), vo.getMbrId()));
        vo.setMbrGrdCode("GRD_N");
        vo.setMbrSttus("P");
        mbrJoinDAO.insertMbr(vo);
        mbrJoinDAO.insertMbrAgreHist(vo);

        if ("Y".equals(vo.getEmailRecptnAt())) {
            java.util.Map<String, String> vars = new java.util.HashMap<String, String>();
            vars.put("이름", vo.getMbrNm());
            notiLinkService.sendMail(vo.getEmailAdres(), "MAIL_JOIN", vars);
        }
    }
}
