package egov.portal.rsv.apply.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * 시설 예약 신청
 * @author lsy
 * @since 2016.05.20
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2016.05.20  lsy       최초 생성
 * </pre>
 */
public interface RsvApplyService {

    /** 달력: 일자별 예약 현황 */
    List<EgovMap> selectMonthResveSttus(RsvApplyVO vo) throws Exception;

    /** 일자별 시간 칸 */
    List<EgovMap> selectDayTimeSlot(RsvApplyVO vo) throws Exception;

    /** 예약 신청 (중복 확인 포함) */
    String insertResve(RsvApplyVO vo) throws Exception;

    /** 나의 예약 */
    List<EgovMap> selectMyResveList(RsvApplyVO vo) throws Exception;

    /** 취소 위약금 계산 */
    long calcPnlty(RsvApplyVO vo) throws Exception;

    /** 예약 취소 */
    void cancelResve(RsvApplyVO vo) throws Exception;
}
