package egov.portal.civil.proc.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egov.portal.civil.cmm.CivilDdlnCalculator;
import egov.portal.civil.proc.service.CivilProcService;
import egov.portal.civil.proc.service.CivilProcVO;
import egov.portal.cmm.exception.BizException;
import egov.portal.cmm.util.PortalDateUtil;
import egov.portal.noti.link.service.NotiLinkService;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : CivilProcServiceImpl.java
 * @Description : 민원 처리 서비스 구현
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.04.11      kjh          최초생성
 * @ 2016.09.02      lsy          이송 추가
 * @ 2017.03.20      pms          이송 시 처리기한 재산정
 * @ 2019.09.17      jdh          문자 발송을 알림 연계(NotiLinkService)로 변경
 * @author 통합포털 구축 kjh
 * @since 2016.04.11
 */
@Service("civilProcService")
public class CivilProcServiceImpl extends EgovAbstractServiceImpl implements CivilProcService {

    @Resource(name = "civilProcDAO")
    private CivilProcDAO civilProcDAO;

    @Resource(name = "civilDdlnCalculator")
    private CivilDdlnCalculator ddlnCalculator;

    @Resource(name = "notiLinkService")
    private NotiLinkService notiLinkService;

    // @Resource(name = "smsDAO")
    // private SmsDAO smsDAO;

    @Override
    public List<EgovMap> selectProcList(CivilProcVO vo) throws Exception {
        return civilProcDAO.selectProcList(vo);
    }

    @Override
    public int selectProcListCnt(CivilProcVO vo) throws Exception {
        return civilProcDAO.selectProcListCnt(vo);
    }

    @Override
    public CivilProcVO selectProcDetail(CivilProcVO vo) throws Exception {
        return civilProcDAO.selectProcDetail(vo);
    }

    @Override
    public List<EgovMap> selectProcHistList(String civilRcptNo) throws Exception {
        return civilProcDAO.selectProcHistList(civilRcptNo);
    }

    @Override
    public List<EgovMap> selectTrnsfHistList(String civilRcptNo) throws Exception {
        return civilProcDAO.selectTrnsfHistList(civilRcptNo);
    }

    @Override
    public void startProc(CivilProcVO vo) throws Exception {
        CivilProcVO cur = civilProcDAO.selectProcDetail(vo);
        if (!"ASGN".equals(cur.getProcSttusCode()) && !"TRNSF".equals(cur.getProcSttusCode())) {
            return;
        }
        vo.setProcSttusCode("PROC");
        civilProcDAO.updateProcSttus(vo);
        insertHist(vo.getCivilRcptNo(), "PROC", "담당자 처리 시작", vo.getLastUpdusrId());
    }

    @Override
    public void updateProcResult(CivilProcVO vo) throws Exception {
        CivilProcVO cur = civilProcDAO.selectProcDetail(vo);
        if ("CMPL".equals(cur.getProcSttusCode())) {
            throw new BizException("civil.proc.already");
        }
        vo.setProcSttusCode("CMPL");
        vo.setProcDt(PortalDateUtil.getToday());
        civilProcDAO.updateProcResult(vo);
        insertHist(vo.getCivilRcptNo(), "CMPL", "처리 완료", vo.getLastUpdusrId());

        // smsDAO.insertSms(cur.getApplcntMbtlnum(), "[민원포털] 민원 처리가 완료되었습니다.");
        notiLinkService.sendSms(cur.getApplcntMbtlnum(), "[통합 민원 포털] 민원 " + vo.getCivilRcptNo() + " 처리가 완료되었습니다.");
    }

    /**
     * 부서 이송.
     * 이송받은 부서 기준으로 처리기한을 다시 계산한다(이송일 다음 근무일부터).
     */
    @Override
    public void trnsfCivil(CivilProcVO vo) throws Exception {
        CivilProcVO cur = civilProcDAO.selectProcDetail(vo);
        if ("CMPL".equals(cur.getProcSttusCode())) {
            throw new BizException("civil.proc.already");
        }

        Map<String, Object> hist = new HashMap<String, Object>();
        hist.put("civilRcptNo", vo.getCivilRcptNo());
        hist.put("beforeDeptCode", cur.getChrgDeptCode());
        hist.put("afterDeptCode", vo.getTrnsfDeptCode());
        hist.put("trnsfResn", vo.getTrnsfResn());
        hist.put("trnsfId", vo.getLastUpdusrId());
        civilProcDAO.insertTrnsfHist(hist);

        // 2017.03 pms: 기존에는 처리기한 유지 → 민원조정위원회 결정으로 재산정
        // vo.setProcDdlnDt(cur.getProcDdlnDt());
        EgovMap afair = civilProcDAO.selectAfairProcPd(cur.getAfairCode());
        int procPd = Integer.parseInt(String.valueOf(afair.get("procPd")));
        vo.setProcDdlnDt(ddlnCalculator.calc(PortalDateUtil.getToday(), procPd, (String) afair.get("procPdSe")));
        vo.setProcSttusCode("TRNSF");
        civilProcDAO.updateTrnsf(vo);
        insertHist(vo.getCivilRcptNo(), "TRNSF", "이송: " + vo.getTrnsfResn(), vo.getLastUpdusrId());
    }

    /** 수동 배정 대기(WAIT_MANUAL) 건을 관리자가 직접 배정 */
    @Override
    public void asgnManual(CivilProcVO vo) throws Exception {
        vo.setProcSttusCode("ASGN");
        civilProcDAO.updateManualAsgn(vo);
        insertHist(vo.getCivilRcptNo(), "ASGN", "수동 배정: " + vo.getChargerId(), vo.getLastUpdusrId());
    }

    private void insertHist(String civilRcptNo, String sttus, String cn, String userId) throws Exception {
        Map<String, Object> h = new HashMap<String, Object>();
        h.put("civilRcptNo", civilRcptNo);
        h.put("procSttusCode", sttus);
        h.put("procCn", cn);
        h.put("processrId", userId);
        civilProcDAO.insertProcHist(h);
    }
}
