package egov.portal.pay.pg.service.impl;

import java.util.List;
import java.util.Map;

import egov.portal.pay.pg.service.PayVO;

import egovframework.rte.psl.dataaccess.mapper.Mapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * 결제 매퍼
 *
 * @author ywk
 * @since 2019.08.19
 */
@Mapper("payMapper")
public interface PayMapper {

    void insertStlm(PayVO vo) throws Exception;
    PayVO selectStlmByOrderNo(String orderNo) throws Exception;
    EgovMap selectStlm(String stlmId) throws Exception;
    int updateApprove(PayVO vo) throws Exception;
    int updateCancel(Map<String, Object> p) throws Exception;
    void insertPgLog(Map<String, Object> p) throws Exception;
    EgovMap selectBizInfo(PayVO vo) throws Exception;

}
