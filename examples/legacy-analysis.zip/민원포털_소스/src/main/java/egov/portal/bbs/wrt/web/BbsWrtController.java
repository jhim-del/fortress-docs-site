package egov.portal.bbs.wrt.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import egov.portal.bbs.inq.service.BbsInqService;
import egov.portal.bbs.inq.service.BbsNttVO;
import egov.portal.bbs.mstr.service.BbsMstrService;
import egov.portal.bbs.mstr.service.BbsMstrVO;
import egov.portal.bbs.wrt.service.BbsWrtService;
import egov.portal.cmm.LoginVO;
import egov.portal.cmm.file.service.FileVO;
import egov.portal.cmm.file.util.FileMngUtil;

/**
 * 게시물 등록·답글 (사용자)
 * @author lsy
 * @since 2016.04.28
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2016.04.28  lsy       최초 생성
 *   2019.10.28  sbk       비밀글
 * </pre>
 */
@Controller
public class BbsWrtController {

    @Resource(name = "bbsWrtService")
    private BbsWrtService bbsWrtService;

    @Resource(name = "bbsInqService")
    private BbsInqService bbsInqService;

    @Resource(name = "bbsMstrService")
    private BbsMstrService bbsMstrService;

    @Resource(name = "fileMngUtil")
    private FileMngUtil fileUtil;

    @RequestMapping("/bbs/wrt/nttForm.do")
    public String nttForm(@ModelAttribute("searchVO") BbsNttVO searchVO, HttpSession session, ModelMap model) throws Exception {
        BbsMstrVO mstr = bbsMstrService.selectBbsMstr(searchVO.getBbsId());
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        if (user == null && !"Y".equals(mstr.getNonmbrWritngAt())) {
            return "redirect:/sec/login/loginForm.do";
        }
        model.addAttribute("bbsMstr", mstr);
        model.addAttribute("bbsNttVO", searchVO.getNttId() == null ? new BbsNttVO() : bbsInqService.selectNtt(searchVO, false));
        return "portal/bbs/nttForm";
    }

    @RequestMapping("/bbs/wrt/nttSave.do")
    public String nttSave(@ModelAttribute("bbsNttVO") BbsNttVO vo, MultipartHttpServletRequest mreq, HttpSession session) throws Exception {
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        List<FileVO> files = fileUtil.parseFileInf(mreq.getFileMap(), null);
        if (user != null) {
            vo.setNtcrId(user.getId());
            vo.setNtcrNm(user.getName());
            vo.setFrstRegisterId(user.getId());
            vo.setLastUpdusrId(user.getId());
        }
        if (vo.getNttId() == null || vo.getNttId().length() == 0) {
            bbsWrtService.insertNtt(vo, files);
        } else {
            bbsWrtService.updateNtt(vo, files);
        }
        return "redirect:/bbs/inq/nttList.do?bbsId=" + vo.getBbsId();
    }

    @RequestMapping("/bbs/wrt/replyForm.do")
    public String replyForm(@ModelAttribute("searchVO") BbsNttVO searchVO, ModelMap model) throws Exception {
        model.addAttribute("parent", bbsInqService.selectNtt(searchVO, false));
        return "portal/bbs/nttReplyForm";
    }

    @RequestMapping("/bbs/wrt/replySave.do")
    public String replySave(@ModelAttribute("bbsNttVO") BbsNttVO vo, MultipartHttpServletRequest mreq, HttpSession session) throws Exception {
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        vo.setNtcrId(user.getId());
        vo.setNtcrNm(user.getName());
        vo.setFrstRegisterId(user.getId());
        bbsWrtService.insertReply(vo, fileUtil.parseFileInf(mreq.getFileMap(), null));
        return "redirect:/bbs/inq/nttList.do?bbsId=" + vo.getBbsId();
    }

    @RequestMapping("/bbs/wrt/nttDelete.do")
    public String nttDelete(@ModelAttribute("bbsNttVO") BbsNttVO vo, HttpSession session) throws Exception {
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        vo.setLastUpdusrId(user.getId());
        bbsWrtService.deleteNtt(vo);
        return "redirect:/bbs/inq/nttList.do?bbsId=" + vo.getBbsId();
    }

}
