package egov.portal.civil.req.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import egov.portal.civil.req.service.CivilReqService;
import egov.portal.civil.req.service.CivilReqVO;
import egov.portal.cmm.LoginVO;
import egov.portal.cmm.file.service.FileMngService;
import egov.portal.cmm.file.service.FileVO;
import egov.portal.cmm.file.util.FileMngUtil;
import egov.portal.cmm.util.PagingHelper;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/**
 * 민원 신청·나의 민원 (사용자)
 *
 * @author ywk
 * @since 2019.07.15
 */
@Controller
@RequestMapping("/civil/req")
public class CivilReqController {

    @Resource(name = "civilReqService")
    private CivilReqService civilReqService;

    @Resource(name = "fileMngUtil")
    private FileMngUtil fileMngUtil;

    @Resource(name = "fileMngService")
    private FileMngService fileMngService;

    @GetMapping("/reqAgree.do")
    public String reqAgree(Model model) throws Exception {
        model.addAttribute("afairList", civilReqService.selectAfairList());
        return "portal/civil/reqAgree";
    }

    @PostMapping("/reqForm.do")
    public String reqForm(@RequestParam("afairCode") String afairCode, @RequestParam(value = "agreAt", required = false) String agreAt,
                          HttpSession session, Model model) throws Exception {
        if (!"Y".equals(agreAt)) {
            return "redirect:/civil/req/reqAgree.do";
        }
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        CivilReqVO vo = new CivilReqVO();
        vo.setAfairCode(afairCode);
        if (user != null) {
            vo.setApplcntNm(user.getName());
            vo.setApplcntMbtlnum(user.getMbtlnum());
            vo.setApplcntEmail(user.getEmail());
        }
        model.addAttribute("afair", civilReqService.selectAfairInfo(afairCode));
        model.addAttribute("civilReqVO", vo);
        return "portal/civil/reqForm";
    }

    @PostMapping("/submit.do")
    public String submit(@ModelAttribute("civilReqVO") CivilReqVO vo, MultipartHttpServletRequest mreq,
                         HttpSession session, RedirectAttributes ra) throws Exception {
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        vo.setApplcntId(user == null ? "GUEST" : user.getId());

        List<FileVO> files = fileMngUtil.parseFileInf(mreq.getFileMap(), null);
        String rcptNo = civilReqService.submit(vo, files);

        ra.addFlashAttribute("rcptNo", rcptNo);
        return "redirect:/civil/req/reqComplete.do";
    }

    @GetMapping("/reqComplete.do")
    public String reqComplete() {
        return "portal/civil/reqComplete";
    }

    @RequestMapping("/myReqList.do")
    public String myReqList(@ModelAttribute("searchVO") CivilReqVO searchVO, HttpSession session, Model model) throws Exception {
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        searchVO.setApplcntId(user.getId());

        PaginationInfo paginationInfo = PagingHelper.of(searchVO, 10);
        int totCnt = civilReqService.selectMyReqListCnt(searchVO);
        paginationInfo.setTotalRecordCount(totCnt);

        model.addAttribute("resultList", civilReqService.selectMyReqList(searchVO));
        model.addAttribute("totCnt", totCnt);
        model.addAttribute("paginationInfo", paginationInfo);
        return "portal/civil/myReqList";
    }

    @GetMapping("/myReqView.do")
    public String myReqView(@RequestParam("civilRcptNo") String civilRcptNo, HttpSession session, Model model) throws Exception {
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        CivilReqVO vo = new CivilReqVO();
        vo.setCivilRcptNo(civilRcptNo);
        vo.setApplcntId(user.getId());
        CivilReqVO result = civilReqService.selectMyReqDetail(vo);
        if (result == null) {
            return "redirect:/civil/req/myReqList.do";
        }
        model.addAttribute("result", result);
        if (result.getAtchFileId() != null) {
            model.addAttribute("fileList", fileMngService.selectFileList(result.getAtchFileId()));
        }
        return "portal/civil/myReqView";
    }

    @PostMapping("/myReqWithdraw.do")
    public String withdraw(@RequestParam("civilRcptNo") String civilRcptNo, HttpSession session) throws Exception {
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        CivilReqVO vo = new CivilReqVO();
        vo.setCivilRcptNo(civilRcptNo);
        vo.setApplcntId(user.getId());
        civilReqService.withdraw(vo);
        return "redirect:/civil/req/myReqView.do?civilRcptNo=" + civilRcptNo;
    }
}
