package egov.portal.link.hr.batch;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import egov.portal.link.hr.service.impl.HrSyncDAO;

/**
 * @Class Name : HrSyncJob.java
 * @Description : 인사 시스템 부서·직원·부재 동기화 (DB 링크 HRLINK, 매일 01:30)
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.07.11      pms          최초생성
 * @ 2019.11.18      jdh          부재(휴가·출장) 동기화 추가 - 자동 배정 제외용
 * @author 통합포털 구축 pms
 * @since 2016.07.11
 */
@Component("hrSyncJob")
public class HrSyncJob {

    private static final Logger LOGGER = LoggerFactory.getLogger(HrSyncJob.class);

    @Resource(name = "hrSyncDAO")
    private HrSyncDAO hrSyncDAO;

    public void sync() {
        try {
            int dept = hrSyncDAO.mergeDept();
            int closed = hrSyncDAO.updateClosedDept();
            int emp = hrSyncDAO.mergeEmplyr();
            int retire = hrSyncDAO.updateRetireEmplyr();
            hrSyncDAO.deleteAbsnce();
            int absnce = hrSyncDAO.insertAbsnce();
            LOGGER.info("인사 연계: 부서 {} (폐지 {}), 직원 {} (퇴직 {}), 부재 {}", dept, closed, emp, retire, absnce);
        } catch (Exception e) {
            // DB 링크 장애 시 전일 데이터 유지
            LOGGER.error("인사 연계 실패", e);
        }
    }
}
