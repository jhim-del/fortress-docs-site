package egov.portal.rsv.fac.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egov.portal.rsv.fac.service.FacService;
import egov.portal.rsv.fac.service.FacVO;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Service("facService")
public class FacServiceImpl extends EgovAbstractServiceImpl implements FacService {

    @Resource(name = "facDAO")
    private FacDAO facDAO;

    @Override
    public FacVO selectFac(String fcltyId) throws Exception {
        return facDAO.selectFac(fcltyId);
    }

    @Override
    public List<EgovMap> selectUseFacList() throws Exception {
        return facDAO.selectUseFacList(null);
    }
}
