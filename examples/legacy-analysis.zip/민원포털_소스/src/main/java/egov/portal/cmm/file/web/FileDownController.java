package egov.portal.cmm.file.web;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.URLEncoder;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egov.portal.cmm.file.service.FileMngService;
import egov.portal.cmm.file.service.FileVO;

/**
 * @Class Name : FileDownController.java
 * @Description : 첨부파일 내려받기
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.03.29      kjh          최초생성
 * @ 2016.12.02      pms          브라우저별 파일명 인코딩
 * @author 통합포털 구축 kjh
 * @since 2016.03.29
 */
@Controller
public class FileDownController {

    @Resource(name = "fileMngService")
    private FileMngService fileService;

    private String getBrowser(HttpServletRequest request) {
        String header = request.getHeader("User-Agent");
        if (header.indexOf("MSIE") > -1 || header.indexOf("Trident") > -1) {
            return "MSIE";
        } else if (header.indexOf("Chrome") > -1) {
            return "Chrome";
        } else if (header.indexOf("Opera") > -1) {
            return "Opera";
        }
        return "Firefox";
    }

    @RequestMapping("/cmm/fms/FileDown.do")
    public void cvplFileDownload(@RequestParam("atchFileId") String atchFileId, @RequestParam("fileSn") String fileSn,
                                 HttpServletRequest request, HttpServletResponse response) throws Exception {
        FileVO param = new FileVO();
        param.setAtchFileId(atchFileId);
        param.setFileSn(fileSn);
        FileVO fvo = fileService.selectFile(param);
        if (fvo == null) {
            response.sendError(404);
            return;
        }

        File uFile = new File(fvo.getFileStreCours(), fvo.getStreFileNm());
        String browser = getBrowser(request);
        String encodedFilename;
        if ("MSIE".equals(browser)) {
            encodedFilename = URLEncoder.encode(fvo.getOrignlFileNm(), "UTF-8").replaceAll("\\+", "%20");
        } else {
            encodedFilename = "\"" + new String(fvo.getOrignlFileNm().getBytes("UTF-8"), "8859_1") + "\"";
        }

        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=" + encodedFilename);
        response.setContentLength((int) uFile.length());

        try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(uFile));
             BufferedOutputStream out = new BufferedOutputStream(response.getOutputStream())) {
            FileCopyUtils.copy(in, out);
            out.flush();
        }
    }
}
