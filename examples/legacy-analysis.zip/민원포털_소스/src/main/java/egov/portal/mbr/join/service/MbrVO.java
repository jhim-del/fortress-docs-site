package egov.portal.mbr.join.service;

import java.io.Serializable;

/**
 * @Class Name : MbrVO.java
 * @Description : 회원 VO
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.04.04      kjh          최초생성
 * @ 2019.09.02      ywk          회원등급(MBR_GRD_CODE) 추가
 * @author 통합포털 구축 kjh
 * @since 2016.04.04
 */
public class MbrVO implements Serializable {

    private static final long serialVersionUID = 897912842061586928L;

    /** 회원ID */
    private String mbrId;
    /** 이름 */
    private String mbrNm;
    /** 비밀번호 */
    private String password;
    /** 비밀번호 확인 */
    private String passwordCnfirm;
    /** 휴대전화 */
    private String mbtlnum;
    /** 이메일 */
    private String emailAdres;
    /** 우편번호 */
    private String zip;
    /** 주소 */
    private String adres;
    /** 상세주소 */
    private String detailAdres;
    /** 생년월일 */
    private String brthdy;
    /** 성별 */
    private String sexdstnCode;
    /** 연계정보(CI) */
    private String ci;
    /** 중복가입확인정보(DI) */
    private String di;
    /** 회원등급(GRD_N/GRD_V) */
    private String mbrGrdCode;
    /** 메일 수신 */
    private String emailRecptnAt;
    /** 문자 수신 */
    private String smsRecptnAt;
    /** 상태(P정상/D휴면/S탈퇴) */
    private String mbrSttus;
    /** 가입일 */
    private String sbscrbDe;
    /** 최종 로그인 */
    private String lastLoginPnttm;
    /** 탈퇴 사유 */
    private String secsnResn;

    public String getMbrId() { return mbrId; }
    public void setMbrId(String mbrId) { this.mbrId = mbrId; }
    public String getMbrNm() { return mbrNm; }
    public void setMbrNm(String mbrNm) { this.mbrNm = mbrNm; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getPasswordCnfirm() { return passwordCnfirm; }
    public void setPasswordCnfirm(String passwordCnfirm) { this.passwordCnfirm = passwordCnfirm; }
    public String getMbtlnum() { return mbtlnum; }
    public void setMbtlnum(String mbtlnum) { this.mbtlnum = mbtlnum; }
    public String getEmailAdres() { return emailAdres; }
    public void setEmailAdres(String emailAdres) { this.emailAdres = emailAdres; }
    public String getZip() { return zip; }
    public void setZip(String zip) { this.zip = zip; }
    public String getAdres() { return adres; }
    public void setAdres(String adres) { this.adres = adres; }
    public String getDetailAdres() { return detailAdres; }
    public void setDetailAdres(String detailAdres) { this.detailAdres = detailAdres; }
    public String getBrthdy() { return brthdy; }
    public void setBrthdy(String brthdy) { this.brthdy = brthdy; }
    public String getSexdstnCode() { return sexdstnCode; }
    public void setSexdstnCode(String sexdstnCode) { this.sexdstnCode = sexdstnCode; }
    public String getCi() { return ci; }
    public void setCi(String ci) { this.ci = ci; }
    public String getDi() { return di; }
    public void setDi(String di) { this.di = di; }
    public String getMbrGrdCode() { return mbrGrdCode; }
    public void setMbrGrdCode(String mbrGrdCode) { this.mbrGrdCode = mbrGrdCode; }
    public String getEmailRecptnAt() { return emailRecptnAt; }
    public void setEmailRecptnAt(String emailRecptnAt) { this.emailRecptnAt = emailRecptnAt; }
    public String getSmsRecptnAt() { return smsRecptnAt; }
    public void setSmsRecptnAt(String smsRecptnAt) { this.smsRecptnAt = smsRecptnAt; }
    public String getMbrSttus() { return mbrSttus; }
    public void setMbrSttus(String mbrSttus) { this.mbrSttus = mbrSttus; }
    public String getSbscrbDe() { return sbscrbDe; }
    public void setSbscrbDe(String sbscrbDe) { this.sbscrbDe = sbscrbDe; }
    public String getLastLoginPnttm() { return lastLoginPnttm; }
    public void setLastLoginPnttm(String lastLoginPnttm) { this.lastLoginPnttm = lastLoginPnttm; }
    public String getSecsnResn() { return secsnResn; }
    public void setSecsnResn(String secsnResn) { this.secsnResn = secsnResn; }
}
