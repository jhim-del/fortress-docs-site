package egov.portal.cmm.file.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egov.portal.cmm.file.service.FileMngService;
import egov.portal.cmm.file.service.FileVO;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.fdl.idgnr.EgovIdGnrService;

/**
 * @Class Name : FileMngServiceImpl.java
 * @Description : 첨부파일 관리 구현
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.03.28      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.03.28
 */
@Service("fileMngService")
public class FileMngServiceImpl extends EgovAbstractServiceImpl implements FileMngService {

    @Resource(name = "fileManageDAO")
    private FileManageDAO fileManageDAO;

    @Resource(name = "egovFileIdGnrService")
    private EgovIdGnrService idgenService;

    @Override
    public List<FileVO> selectFileList(String atchFileId) throws Exception {
        FileVO vo = new FileVO();
        vo.setAtchFileId(atchFileId);
        return fileManageDAO.selectFileList(vo);
    }

    @Override
    public FileVO selectFile(FileVO vo) throws Exception {
        return fileManageDAO.selectFile(vo);
    }

    @Override
    public String insertFiles(List<FileVO> files) throws Exception {
        if (files == null || files.isEmpty()) {
            return "";
        }
        String atchFileId = idgenService.getNextStringId();
        FileVO master = new FileVO();
        master.setAtchFileId(atchFileId);
        fileManageDAO.insertFileMaster(master);
        addFiles(atchFileId, files);
        return atchFileId;
    }

    @Override
    public void addFiles(String atchFileId, List<FileVO> files) throws Exception {
        int sn = fileManageDAO.selectMaxFileSn(atchFileId);
        for (FileVO f : files) {
            f.setAtchFileId(atchFileId);
            f.setFileSn(String.valueOf(++sn));
            fileManageDAO.insertFileDetail(f);
        }
    }

    @Override
    public void deleteFile(FileVO vo) throws Exception {
        fileManageDAO.deleteFileDetail(vo);
    }
}
