package egov.portal.bbs.inq.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egov.portal.bbs.inq.service.BbsInqService;
import egov.portal.bbs.inq.service.BbsNttVO;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : BbsInqServiceImpl.java
 * @Description : 게시물 조회 구현
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.04.26      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.04.26
 */
@Service("bbsInqService")
public class BbsInqServiceImpl extends EgovAbstractServiceImpl implements BbsInqService {

    @Resource(name = "bbsInqDAO")
    private BbsInqDAO bbsInqDAO;

    @Override
    public List<EgovMap> selectNttList(BbsNttVO vo) throws Exception {
        return bbsInqDAO.selectNttList(vo);
    }

    @Override
    public int selectNttListCnt(BbsNttVO vo) throws Exception {
        return bbsInqDAO.selectNttListCnt(vo);
    }

    @Override
    public List<EgovMap> selectNoticeNttList(String bbsId) throws Exception {
        return bbsInqDAO.selectNoticeNttList(bbsId);
    }

    @Override
    public BbsNttVO selectNtt(BbsNttVO vo, boolean countUp) throws Exception {
        if (countUp) {
            bbsInqDAO.updateRdcnt(vo);
        }
        return bbsInqDAO.selectNtt(vo);
    }

}
