package egov.portal.mbr.join.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : MbrJoinService.java
 * @Description : 회원가입
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.04.04      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.04.04
 */
public interface MbrJoinService {

    /** 아이디 중복 */
    int checkIdDup(String mbrId) throws Exception;

    /** CI 로 기존 가입 확인 */
    String selectMbrIdByCi(String ci) throws Exception;

    /** 회원 등록 */
    void insertMbr(MbrVO vo) throws Exception;
}
