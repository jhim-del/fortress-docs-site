package egov.portal.bbs.wrt.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egov.portal.bbs.inq.service.BbsNttVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * 게시물 등록 DAO
 * @author lsy
 * @since 2016.04.28
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2016.04.28  lsy       최초 생성
 * </pre>
 */
@Repository("bbsWrtDAO")
public class BbsWrtDAO extends EgovAbstractMapper {

    /** 다음 게시물ID */
    public String selectNextNttId(BbsNttVO vo) throws Exception {
        return (String) selectOne("bbsWrtDAO.selectNextNttId", vo);
    }

    /** 부모글 */
    public BbsNttVO selectParent(BbsNttVO vo) throws Exception {
        return (BbsNttVO) selectOne("bbsWrtDAO.selectParent", vo);
    }

    /** 답글 자리 확보 */
    public int updateNttNoShift(BbsNttVO vo) throws Exception {
        return update("bbsWrtDAO.updateNttNoShift", vo);
    }

    /** 등록 */
    public void insertNtt(BbsNttVO vo) throws Exception {
        insert("bbsWrtDAO.insertNtt", vo);
    }

    /** 수정 */
    public int updateNtt(BbsNttVO vo) throws Exception {
        return update("bbsWrtDAO.updateNtt", vo);
    }

    /** 삭제 */
    public int deleteNtt(BbsNttVO vo) throws Exception {
        return update("bbsWrtDAO.deleteNtt", vo);
    }

}
