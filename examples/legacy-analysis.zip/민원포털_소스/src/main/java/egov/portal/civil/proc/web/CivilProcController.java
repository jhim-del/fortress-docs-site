package egov.portal.civil.proc.web;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egov.portal.assign.conf.service.AssignConfService;
import egov.portal.civil.proc.service.CivilProcService;
import egov.portal.civil.proc.service.CivilProcVO;
import egov.portal.cmm.LoginVO;
import egov.portal.cmm.service.CmmUseService;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/**
 * @Class Name : CivilProcController.java
 * @Description : 민원 처리 (담당자·관리자)
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.04.11      kjh          최초생성
 * @ 2016.09.02      lsy          이송 팝업
 * @ 2019.11.25      jdh          수동 배정 담당자 목록을 배정 설정에서 조회
 * @author 통합포털 구축 kjh
 * @since 2016.04.11
 */
@Controller
public class CivilProcController {

    /** CivilProcService */
    @Resource(name = "civilProcService")
    private CivilProcService civilProcService;

    /** EgovPropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

    @Resource(name = "cmmUseService")
    private CmmUseService cmmUseService;

    @Resource(name = "assignConfService")
    private AssignConfService assignConfService;

    /**
     * 민원 처리 목록을 조회한다.
     * @param searchVO
     * @param model
     * @return "mng/civil/procList"
     * @exception Exception
     */
    @RequestMapping(value = "/mng/civil/proc/procList.do")
    public String selectProcList(@ModelAttribute("searchVO") CivilProcVO searchVO, HttpSession session, ModelMap model) throws Exception {
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        searchVO.setAuthorCode(user.getAuthorCode());
        searchVO.setChrgDeptCode(user.getDeptCode());

        searchVO.setPageUnit(propertiesService.getInt("mngPageUnit"));
        searchVO.setPageSize(propertiesService.getInt("pageSize"));

        PaginationInfo paginationInfo = new PaginationInfo();
        paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
        paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
        paginationInfo.setPageSize(searchVO.getPageSize());

        searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
        searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
        searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

        model.addAttribute("resultList", civilProcService.selectProcList(searchVO));
        int totCnt = civilProcService.selectProcListCnt(searchVO);
        paginationInfo.setTotalRecordCount(totCnt);
        model.addAttribute("paginationInfo", paginationInfo);
        model.addAttribute("totCnt", totCnt);
        model.addAttribute("sttusList", cmmUseService.selectCmmCodeDetail("CVL002"));
        model.addAttribute("deptList", cmmUseService.selectDeptList());
        return "mng/civil/procList";
    }

    /**
     * 민원 상세 (처리 화면). 배정된 담당자가 처음 열면 처리중으로 바꾼다.
     */
    @RequestMapping(value = "/mng/civil/proc/procView.do")
    public String selectProcView(@ModelAttribute("searchVO") CivilProcVO searchVO, HttpSession session, ModelMap model) throws Exception {
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        CivilProcVO result = civilProcService.selectProcDetail(searchVO);
        if (user.getId().equals(result.getChargerId())) {
            searchVO.setLastUpdusrId(user.getId());
            civilProcService.startProc(searchVO);
        }
        model.addAttribute("result", result);
        model.addAttribute("histList", civilProcService.selectProcHistList(searchVO.getCivilRcptNo()));
        model.addAttribute("trnsfList", civilProcService.selectTrnsfHistList(searchVO.getCivilRcptNo()));
        if ("WAIT_MANUAL".equals(result.getProcSttusCode()) || "TRNSF".equals(result.getProcSttusCode())) {
            model.addAttribute("chargerList", assignConfService.selectChargerList(result.getChrgDeptCode()));
        }
        return "mng/civil/procView";
    }

    @RequestMapping(value = "/mng/civil/proc/procRegist.do")
    public String procRegist(@ModelAttribute("searchVO") CivilProcVO vo, HttpSession session) throws Exception {
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        vo.setLastUpdusrId(user.getId());
        civilProcService.updateProcResult(vo);
        return "redirect:/mng/civil/proc/procView.do?civilRcptNo=" + vo.getCivilRcptNo();
    }

    @RequestMapping(value = "/mng/civil/proc/asgnManual.do")
    public String asgnManual(@ModelAttribute("searchVO") CivilProcVO vo, HttpSession session) throws Exception {
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        vo.setLastUpdusrId(user.getId());
        civilProcService.asgnManual(vo);
        return "redirect:/mng/civil/proc/procView.do?civilRcptNo=" + vo.getCivilRcptNo();
    }

    /** 이송 팝업 */
    @RequestMapping(value = "/mng/civil/proc/trnsfPop.do")
    public String trnsfPop(@RequestParam("civilRcptNo") String civilRcptNo, ModelMap model) throws Exception {
        model.addAttribute("civilRcptNo", civilRcptNo);
        model.addAttribute("deptList", cmmUseService.selectDeptList());
        return "mng/civil/trnsfPop";
    }

    @RequestMapping(value = "/mng/civil/proc/trnsf.do")
    public String trnsf(@ModelAttribute("searchVO") CivilProcVO vo, HttpSession session, ModelMap model) throws Exception {
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        vo.setLastUpdusrId(user.getId());
        civilProcService.trnsfCivil(vo);
        model.addAttribute("closeMsg", "이송되었습니다.");
        return "mng/cmm/popClose";
    }

}
