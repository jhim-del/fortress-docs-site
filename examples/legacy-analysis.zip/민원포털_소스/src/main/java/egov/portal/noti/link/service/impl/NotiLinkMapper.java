package egov.portal.noti.link.service.impl;

import java.util.List;
import java.util.Map;

import egovframework.rte.psl.dataaccess.mapper.Mapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * 알림 큐(TB_NOTI_LINK) 매퍼
 *
 * @author jdh
 * @since 2019.09.10
 */
@Mapper("notiLinkMapper")
public interface NotiLinkMapper {

    void insertQueue(Map<String, Object> q) throws Exception;
    List<EgovMap> selectSendTargets(Map<String, Object> p) throws Exception;
    int updateSendResult(Map<String, Object> p) throws Exception;
    EgovMap selectTmpl(String tmplId) throws Exception;
    int deleteOldQueue(int keepDays) throws Exception;

}
