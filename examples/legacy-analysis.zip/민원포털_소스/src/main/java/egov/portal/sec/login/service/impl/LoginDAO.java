package egov.portal.sec.login.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : LoginDAO.java
 * @Description : 로그인 DAO
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.04.01      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.04.01
 */
@Repository("loginDAO")
public class LoginDAO extends EgovAbstractMapper {

    public EgovMap selectMbrForLogin(String id) {
        return selectOne("loginDAO.selectMbrForLogin", id);
    }

    public EgovMap selectEmplyrForLogin(String id) {
        return selectOne("loginDAO.selectEmplyrForLogin", id);
    }

    public void updateLoginFail(String id, int maxFail) {
        Map<String, Object> p = new HashMap<String, Object>();
        p.put("id", id);
        p.put("maxFail", maxFail);
        update("loginDAO.updateLoginFail", p);
    }

    public void updateLoginSuccess(String id) {
        update("loginDAO.updateLoginSuccess", id);
    }

    public void updateMbrPassword(String id, String password) {
        Map<String, Object> p = new HashMap<String, Object>();
        p.put("id", id);
        p.put("password", password);
        update("loginDAO.updateMbrPassword", p);
    }

    public void updateEmplyrLoginFail(String id) {
        update("loginDAO.updateEmplyrLoginFail", id);
    }

    public void updateEmplyrLoginSuccess(String id) {
        update("loginDAO.updateEmplyrLoginSuccess", id);
    }
}
