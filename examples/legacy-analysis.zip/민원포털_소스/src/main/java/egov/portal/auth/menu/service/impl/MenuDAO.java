package egov.portal.auth.menu.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egov.portal.auth.menu.service.MenuVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : MenuDAO.java
 * @Description : 메뉴 DAO
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.03.30      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.03.30
 */
@Repository("menuDAO")
public class MenuDAO extends EgovAbstractMapper {

    /** 권한별 메뉴 */
    public List<MenuVO> selectAuthorMenuList(String vo) throws Exception {
        return selectList("menuDAO.selectAuthorMenuList", vo);
    }

    /** 메뉴 트리 */
    public List<EgovMap> selectMenuTree(Object vo) throws Exception {
        return selectList("menuDAO.selectMenuTree", vo);
    }

    /** 메뉴 1건 */
    public MenuVO selectMenu(int vo) throws Exception {
        return (MenuVO) selectOne("menuDAO.selectMenu", vo);
    }

    /** 메뉴 등록 */
    public void insertMenu(MenuVO vo) throws Exception {
        insert("menuDAO.insertMenu", vo);
    }

    /** 메뉴 수정 */
    public int updateMenu(MenuVO vo) throws Exception {
        return update("menuDAO.updateMenu", vo);
    }

}
