package egov.portal.refund.aprv.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egov.portal.cmm.exception.BizException;
import egov.portal.noti.link.service.NotiLinkService;
import egov.portal.refund.aprv.service.impl.RefundAprvMapper;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * 환불 승인·반려 (관리자)
 * <p>
 * 2020.06.22 hjy 감사 지적 사항: VIP 회원 환불 수수료 예외 규칙 추가
 *
 * @author jdh
 * @since 2019.10.01
 */
@Service("refundAprvService")
public class RefundAprvService extends EgovAbstractServiceImpl {

    @Resource(name = "refundAprvMapper")
    private RefundAprvMapper refundAprvMapper;

    @Resource(name = "propertiesService")
    private EgovPropertyService propertiesService;

    @Resource(name = "notiLinkService")
    private NotiLinkService notiLinkService;

    public List<EgovMap> selectAprvList(RefundAprvVO vo) throws Exception {
        return refundAprvMapper.selectAprvList(vo);
    }

    public int selectAprvListCnt(RefundAprvVO vo) throws Exception {
        return refundAprvMapper.selectAprvListCnt(vo);
    }

    public RefundAprvVO selectRefundDetail(Long refundSeq) throws Exception {
        RefundAprvVO vo = refundAprvMapper.selectRefundDetail(refundSeq);
        if (vo != null && "REQ".equals(vo.getReqSttus())) {
            int rate = propertiesService.getInt("refund.feeRate");
            vo.setFeeRate(rate);
            vo.setFeeAmt(calcFee(vo.getReqAmt(), rate));
            vo.setRefundAmt(vo.getReqAmt() - vo.getFeeAmt());
        }
        return vo;
    }

    /** 승인: 수수료 차감 후 환불액 확정 (실제 이체는 회계 담당 수기, 완료 처리는 updateDone) */
    public void approve(RefundAprvVO vo) throws Exception {
        RefundAprvVO cur = refundAprvMapper.selectRefundDetail(vo.getRefundSeq());
        if (!"REQ".equals(cur.getReqSttus())) {
            throw new BizException("refund.already");
        }
        int rate = propertiesService.getInt("refund.feeRate");
        cur.setFeeRate(rate);
        cur.setFeeAmt(calcFee(cur.getReqAmt(), rate));
        cur.setRefundAmt(cur.getReqAmt() - cur.getFeeAmt());
        cur.setAprvId(vo.getAprvId());
        cur.setReqSttus("APRV");
        refundAprvMapper.updateAprv(cur);
    }

    public void reject(RefundAprvVO vo) throws Exception {
        if (vo.getRjctRsn() == null || vo.getRjctRsn().trim().length() < 2) {
            throw new BizException("refund.rjct.rsn");
        }
        vo.setReqSttus("RJCT");
        refundAprvMapper.updateRjct(vo);
        RefundAprvVO cur = refundAprvMapper.selectRefundDetail(vo.getRefundSeq());
        if (cur != null && "Y".equals(cur.getSmsRecptnAt())) {
            notiLinkService.sendSms(cur.getMbtlnum(), "[통합 민원 포털] 환불 신청이 반려되었습니다. 사유: " + vo.getRjctRsn());
        }
    }

    public List<EgovMap> selectAprvTransferList() throws Exception {
        return refundAprvMapper.selectAprvTransferList();
    }

    /** 10원 미만 절사 */
    private long calcFee(long amt, int rate) {
        return amt * rate / 100 / 10 * 10;
    }

    /**
     * 환불 수수료율. 2020.06 감사 지적 후 VIP(GRD_V) 예외 추가.
     * VIP는 결제 후 7일 이내 0%, 7일 초과 5%. 일반은 10%.
     */
    public int refundFeeRate(String grade, int daysAfterPay) {
        if ("GRD_V".equals(grade)) {
            return daysAfterPay <= 7 ? 0 : 5;
        }
        return 10;
    }
}
