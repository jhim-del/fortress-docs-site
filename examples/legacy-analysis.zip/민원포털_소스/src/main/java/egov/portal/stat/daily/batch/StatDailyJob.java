package egov.portal.stat.daily.batch;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import egov.portal.cmm.util.PortalDateUtil;
import egov.portal.stat.daily.service.impl.StatDailyDAO;

/**
 * @Class Name : StatDailyJob.java
 * @Description : 일 통계 집계 배치 (context-scheduling.xml stat.daily.cron)
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.07.04      pms          최초생성
 * @ 2016.12.19      pms          재집계(기간 지정) 추가
 * @ 2019.11.11      jdh          예약 통계에 위약금 합계 추가
 * @author 통합포털 구축 pms
 * @since 2016.07.04
 */
@Component("statDailyJob")
public class StatDailyJob {

    private static final Logger LOGGER = LoggerFactory.getLogger(StatDailyJob.class);

    @Resource(name = "statDailyDAO")
    private StatDailyDAO statDailyDAO;

    /** 매일 새벽: 전일분 집계 */
    public void execute() {
        String statDe = PortalDateUtil.addDay(PortalDateUtil.getToday(), -1);
        aggregate(statDe);
    }

    private void aggregate(String statDe) {
        long start = System.currentTimeMillis();
        Map<String, Object> p = new HashMap<String, Object>();
        p.put("statDe", statDe);
        String result = "S";
        String msg = null;
        try {
            statDailyDAO.deleteCivilStat(p);
            int c = statDailyDAO.insertCivilStat(p);
            statDailyDAO.deleteRsvStat(p);
            int r = statDailyDAO.insertRsvStat(p);
            msg = "민원 " + c + "행, 예약 " + r + "행";
            LOGGER.info("일 통계 {} 집계 완료 ({}) {}ms", statDe, msg, System.currentTimeMillis() - start);
        } catch (Exception e) {
            result = "F";
            msg = e.getMessage();
            LOGGER.error("일 통계 {} 집계 실패", statDe, e);
        }
        p.put("batchResult", result);
        p.put("batchMsg", msg);
        try {
            statDailyDAO.insertBatchLog(p);
        } catch (Exception e) {
            LOGGER.error("배치 로그 저장 실패", e);
        }
    }
}
