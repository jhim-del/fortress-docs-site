package egov.portal.civil.cmm;

import java.util.Set;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import egov.portal.cmm.service.CmmUseService;
import egov.portal.cmm.util.PortalDateUtil;

/**
 * 민원 처리기한 계산
 * @author lsy
 * @since 2016.06.10
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2016.06.10  lsy       최초 생성
 *   2016.08.29  lsy       역일(C) 구분 추가
 *   2019.08.05  ywk       신청 개편에서 재사용, 시간(H) 구분 추가
 * </pre>
 */
@Component("civilDdlnCalculator")
public class CivilDdlnCalculator {

    @Resource(name = "cmmUseService")
    private CmmUseService cmmUseService;

    /**
     * 처리기한(yyyyMMdd)
     * @param rcptDt  접수일 yyyyMMdd
     * @param procPd  처리기간
     * @param procPdSe 처리기간 구분 D:근무일 C:역일 H:시간(당일)
     */
    public String calc(String rcptDt, int procPd, String procPdSe) throws Exception {
        if ("H".equals(procPdSe)) {
            // 즉시·시간 단위 민원은 접수 당일
            return rcptDt;
        }
        if ("C".equals(procPdSe)) {
            return PortalDateUtil.addDay(rcptDt, procPd);
        }
        // TODO 처리기간 5일 이하는 시간 단위(1일=8시간)로 환산해야 함 - 2016 구축 범위에서 제외, 근무일로 처리
        // 공휴일 조회 범위: 처리기간 x 2 + 14일이면 연휴 포함 충분
        String until = PortalDateUtil.addDay(rcptDt, procPd * 2 + 14);
        Set<String> restde = cmmUseService.selectRestdeSet(rcptDt, until);
        return PortalDateUtil.addWorkDay(rcptDt, procPd, restde);
    }
}
