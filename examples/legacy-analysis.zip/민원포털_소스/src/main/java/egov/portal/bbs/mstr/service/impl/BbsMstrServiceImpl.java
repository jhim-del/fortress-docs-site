package egov.portal.bbs.mstr.service.impl;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egov.portal.bbs.mstr.service.BbsMstrService;
import egov.portal.bbs.mstr.service.BbsMstrVO;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/** 게시판 설정은 거의 바뀌지 않아 메모리에 둔다 (변경 시 WAS 재기동) */
@Service("bbsMstrService")
public class BbsMstrServiceImpl extends EgovAbstractServiceImpl implements BbsMstrService {

    private final Map<String, BbsMstrVO> cache = new ConcurrentHashMap<String, BbsMstrVO>();

    @Resource(name = "bbsMstrDAO")
    private BbsMstrDAO bbsMstrDAO;

    public BbsMstrVO selectBbsMstr(String bbsId) throws Exception {
        BbsMstrVO vo = cache.get(bbsId);
        if (vo == null) {
            vo = bbsMstrDAO.selectBbsMstr(bbsId);
            if (vo != null) {
                cache.put(bbsId, vo);
            }
        }
        return vo;
    }
}
