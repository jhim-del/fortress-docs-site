package egov.portal.sec.login.service;

import java.util.List;

import egov.portal.cmm.LoginVO;

import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : LoginService.java
 * @Description : 로그인
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.04.01      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.04.01
 */
public interface LoginService {

    /** 일반회원 로그인 */
    LoginVO actionLogin(LoginVO vo) throws Exception;

    /** 업무사용자 로그인 */
    LoginVO actionMngLogin(LoginVO vo) throws Exception;
}
