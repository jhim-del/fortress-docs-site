package egov.portal.noti.link.batch;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

import egov.portal.noti.link.client.SmsAgentClient;
import egov.portal.noti.link.service.impl.NotiLinkMapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * 알림 큐 발송·재시도 배치 (context-scheduling.xml, noti.retry.cron = 10분)
 * <p>
 * 대기(W)와 실패(F, 재시도 횟수 미만) 건을 발송한다.
 *
 * @author jdh
 * @since 2019.09.10
 */
@Component("notiRetryJob")
public class NotiRetryJob {

    private static final Logger LOGGER = LoggerFactory.getLogger(NotiRetryJob.class);

    @Resource(name = "notiLinkMapper")
    private NotiLinkMapper notiLinkMapper;

    @Resource(name = "smsAgentClient")
    private SmsAgentClient smsAgentClient;

    @Resource(name = "mailSender")
    private JavaMailSender mailSender;

    @Value("${noti.retry.maxCnt:3}")
    private int maxCnt;

    public void retry() {
        Map<String, Object> p = new HashMap<String, Object>();
        p.put("maxCnt", maxCnt);
        p.put("limit", 500);
        List<EgovMap> targets;
        try {
            targets = notiLinkMapper.selectSendTargets(p);
        } catch (Exception e) {
            LOGGER.error("알림 대상 조회 실패", e);
            return;
        }

        int ok = 0, fail = 0;
        for (EgovMap t : targets) {
            Map<String, Object> r = new HashMap<String, Object>();
            r.put("linkSeq", t.get("linkSeq"));
            try {
                String ty = (String) t.get("sendTy");
                if ("MAIL".equals(ty)) {
                    SimpleMailMessage m = new SimpleMailMessage();
                    m.setFrom("noreply@portal.local");
                    m.setTo((String) t.get("rcver"));
                    m.setSubject((String) t.get("title"));
                    m.setText((String) t.get("msgCn"));
                    mailSender.send(m);
                } else if ("LMS".equals(ty)) {
                    smsAgentClient.sendLms((String) t.get("rcver"), "통합 민원 포털", (String) t.get("msgCn"));
                } else {
                    smsAgentClient.send((String) t.get("rcver"), (String) t.get("msgCn"));
                }
                r.put("sendSttus", "S");
                ok++;
            } catch (Exception e) {
                r.put("sendSttus", "F");
                r.put("errMsg", e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage());
                fail++;
            }
            try {
                notiLinkMapper.updateSendResult(r);
            } catch (Exception e) {
                LOGGER.error("발송 결과 갱신 실패 seq={}", t.get("linkSeq"), e);
            }
        }
        if (!targets.isEmpty()) {
            LOGGER.info("알림 발송 대상 {} / 성공 {} / 실패 {}", targets.size(), ok, fail);
        }
    }
}
