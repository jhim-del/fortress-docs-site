package egov.portal.civil.proc.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import egov.portal.civil.proc.service.CivilProcVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : CivilProcDAO.java
 * @Description : 민원 처리 DAO
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.04.11      kjh          최초생성
 * @ 2016.09.02      lsy          이송
 * @author 통합포털 구축 kjh
 * @since 2016.04.11
 */
@Repository("civilProcDAO")
public class CivilProcDAO extends EgovAbstractMapper {

    /** 처리 대상 목록 */
    public List<EgovMap> selectProcList(CivilProcVO vo) throws Exception {
        return selectList("civilProcDAO.selectProcList", vo);
    }

    /** 처리 대상 건수 */
    public int selectProcListCnt(CivilProcVO vo) throws Exception {
        return (Integer) selectOne("civilProcDAO.selectProcListCnt", vo);
    }

    /** 상세 */
    public CivilProcVO selectProcDetail(CivilProcVO vo) throws Exception {
        return (CivilProcVO) selectOne("civilProcDAO.selectProcDetail", vo);
    }

    /** 처리 이력 */
    public List<EgovMap> selectProcHistList(String vo) throws Exception {
        return selectList("civilProcDAO.selectProcHistList", vo);
    }

    /** 이송 이력 */
    public List<EgovMap> selectTrnsfHistList(String vo) throws Exception {
        return selectList("civilProcDAO.selectTrnsfHistList", vo);
    }

    /** 사무별 처리기간 */
    public EgovMap selectAfairProcPd(String vo) throws Exception {
        return (EgovMap) selectOne("civilProcDAO.selectAfairProcPd", vo);
    }

    /** 상태 변경 */
    public int updateProcSttus(CivilProcVO vo) throws Exception {
        return update("civilProcDAO.updateProcSttus", vo);
    }

    /** 처리 결과 */
    public int updateProcResult(CivilProcVO vo) throws Exception {
        return update("civilProcDAO.updateProcResult", vo);
    }

    /** 이송 이력 등록 */
    public void insertTrnsfHist(Map<String, Object> vo) throws Exception {
        insert("civilProcDAO.insertTrnsfHist", vo);
    }

    /** 이송 반영 */
    public int updateTrnsf(CivilProcVO vo) throws Exception {
        return update("civilProcDAO.updateTrnsf", vo);
    }

    /** 수동 배정 */
    public int updateManualAsgn(CivilProcVO vo) throws Exception {
        return update("civilProcDAO.updateManualAsgn", vo);
    }

    /** 처리 이력 등록 */
    public void insertProcHist(Map<String, Object> vo) throws Exception {
        insert("civilProcDAO.insertProcHist", vo);
    }

}
