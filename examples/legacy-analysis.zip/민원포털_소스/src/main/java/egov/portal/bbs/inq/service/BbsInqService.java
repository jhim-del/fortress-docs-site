package egov.portal.bbs.inq.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : BbsInqService.java
 * @Description : 게시물 조회
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.04.26      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.04.26
 */
public interface BbsInqService {

    /** 게시물 목록 */
    List<EgovMap> selectNttList(BbsNttVO vo) throws Exception;

    /** 게시물 건수 */
    int selectNttListCnt(BbsNttVO vo) throws Exception;

    /** 상단 공지 */
    List<EgovMap> selectNoticeNttList(String bbsId) throws Exception;

    /** 게시물 상세 */
    BbsNttVO selectNtt(BbsNttVO vo, boolean countUp) throws Exception;
}
