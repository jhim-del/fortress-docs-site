package egov.portal.rsv.apply.service;

import java.io.Serializable;
import egov.portal.cmm.ComDefaultVO;

/**
 * 시설 예약 VO
 * @author lsy
 * @since 2016.05.20
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2016.05.20  lsy       최초 생성
 *   2019.08.26  jdh       결제·위약금 항목 추가
 * </pre>
 */
public class RsvApplyVO extends ComDefaultVO {

    private static final long serialVersionUID = 274647652575204050L;

    /** 예약ID */
    private String resveId;
    /** 시설ID */
    private String fcltyId;
    /** 시설명 */
    private String fcltyNm;
    /** 예약일 */
    private String resveDe;
    /** 시작(HHmm) */
    private String beginTime;
    /** 종료(HHmm) */
    private String endTime;
    /** 신청자ID */
    private String applcntId;
    /** 신청자명 */
    private String applcntNm;
    /** 연락처 */
    private String mbtlnum;
    /** 이용목적 */
    private String usePurps;
    /** 이용인원 */
    private int nmpr;
    /** 예약상태(REQ/PAY_WAIT/CONF/CANCL/NOSHOW) */
    private String resveSttusCode;
    /** 이용료 */
    private long chrgeAmt;
    /** 결제ID */
    private String stlmId;
    /** 취소 위약금 */
    private long pnltyAmt;
    /** 취소일시 */
    private String canclDt;
    /** 취소사유 */
    private String canclResn;
    /** 달력 연월 */
    private String searchYm;

    public String getResveId() { return resveId; }
    public void setResveId(String resveId) { this.resveId = resveId; }
    public String getFcltyId() { return fcltyId; }
    public void setFcltyId(String fcltyId) { this.fcltyId = fcltyId; }
    public String getFcltyNm() { return fcltyNm; }
    public void setFcltyNm(String fcltyNm) { this.fcltyNm = fcltyNm; }
    public String getResveDe() { return resveDe; }
    public void setResveDe(String resveDe) { this.resveDe = resveDe; }
    public String getBeginTime() { return beginTime; }
    public void setBeginTime(String beginTime) { this.beginTime = beginTime; }
    public String getEndTime() { return endTime; }
    public void setEndTime(String endTime) { this.endTime = endTime; }
    public String getApplcntId() { return applcntId; }
    public void setApplcntId(String applcntId) { this.applcntId = applcntId; }
    public String getApplcntNm() { return applcntNm; }
    public void setApplcntNm(String applcntNm) { this.applcntNm = applcntNm; }
    public String getMbtlnum() { return mbtlnum; }
    public void setMbtlnum(String mbtlnum) { this.mbtlnum = mbtlnum; }
    public String getUsePurps() { return usePurps; }
    public void setUsePurps(String usePurps) { this.usePurps = usePurps; }
    public int getNmpr() { return nmpr; }
    public void setNmpr(int nmpr) { this.nmpr = nmpr; }
    public String getResveSttusCode() { return resveSttusCode; }
    public void setResveSttusCode(String resveSttusCode) { this.resveSttusCode = resveSttusCode; }
    public long getChrgeAmt() { return chrgeAmt; }
    public void setChrgeAmt(long chrgeAmt) { this.chrgeAmt = chrgeAmt; }
    public String getStlmId() { return stlmId; }
    public void setStlmId(String stlmId) { this.stlmId = stlmId; }
    public long getPnltyAmt() { return pnltyAmt; }
    public void setPnltyAmt(long pnltyAmt) { this.pnltyAmt = pnltyAmt; }
    public String getCanclDt() { return canclDt; }
    public void setCanclDt(String canclDt) { this.canclDt = canclDt; }
    public String getCanclResn() { return canclResn; }
    public void setCanclResn(String canclResn) { this.canclResn = canclResn; }
    public String getSearchYm() { return searchYm; }
    public void setSearchYm(String searchYm) { this.searchYm = searchYm; }
}
