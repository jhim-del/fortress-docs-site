package egov.portal.appr.doc.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import egov.portal.appr.doc.service.ApprDocVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : ApprDocDAO.java
 * @Description : 결재 문서 DAO
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.06.20      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.06.20
 */
@Repository("apprDocDAO")
public class ApprDocDAO extends EgovAbstractMapper {

    /** 결재함 */
    public List<EgovMap> selectDocList(ApprDocVO vo) throws Exception {
        return selectList("apprDocDAO.selectDocList", vo);
    }

    /** 결재함 건수 */
    public int selectDocListCnt(ApprDocVO vo) throws Exception {
        return (Integer) selectOne("apprDocDAO.selectDocListCnt", vo);
    }

    /** 문서 */
    public ApprDocVO selectDoc(String vo) throws Exception {
        return (ApprDocVO) selectOne("apprDocDAO.selectDoc", vo);
    }

    /** 결재선 */
    public List<EgovMap> selectSanctnLineList(String vo) throws Exception {
        return selectList("apprDocDAO.selectSanctnLineList", vo);
    }

    /** 현재 결재자 */
    public EgovMap selectCurLine(ApprDocVO vo) throws Exception {
        return (EgovMap) selectOne("apprDocDAO.selectCurLine", vo);
    }

    /** 문서 등록 */
    public void insertDoc(ApprDocVO vo) throws Exception {
        insert("apprDocDAO.insertDoc", vo);
    }

    /** 결재선 등록 */
    public void insertSanctnLine(Map<String, Object> vo) throws Exception {
        insert("apprDocDAO.insertSanctnLine", vo);
    }

    /** 결재 처리 */
    public int updateSanctnLine(Map<String, Object> vo) throws Exception {
        return update("apprDocDAO.updateSanctnLine", vo);
    }

    /** 다음 결재순번 */
    public int selectNextOrdr(Map<String, Object> vo) throws Exception {
        return (Integer) selectOne("apprDocDAO.selectNextOrdr", vo);
    }

    /** 문서 상태 */
    public int updateDocSttus(ApprDocVO vo) throws Exception {
        return update("apprDocDAO.updateDocSttus", vo);
    }

}
