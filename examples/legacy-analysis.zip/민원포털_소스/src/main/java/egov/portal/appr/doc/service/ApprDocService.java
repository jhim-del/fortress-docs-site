package egov.portal.appr.doc.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : ApprDocService.java
 * @Description : 결재 문서
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.06.20      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.06.20
 */
public interface ApprDocService {

    /** 결재함 목록 */
    List<EgovMap> selectDocList(ApprDocVO vo) throws Exception;

    /** 결재함 건수 */
    int selectDocListCnt(ApprDocVO vo) throws Exception;

    /** 문서 상세 */
    ApprDocVO selectDoc(String docId) throws Exception;

    /** 결재선 */
    List<EgovMap> selectSanctnLineList(String docId) throws Exception;

    /** 상신 */
    String insertDraft(ApprDocVO vo) throws Exception;

    /** 결재(승인) */
    void approve(ApprDocVO vo) throws Exception;

    /** 반려 */
    void reject(ApprDocVO vo) throws Exception;
}
