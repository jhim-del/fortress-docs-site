package egov.portal.stat.inq.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egov.portal.stat.inq.service.impl.StatInqMapper;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * 통계 조회 (집계 테이블 기준, 원본 테이블 직접 조회 금지 - 2019 성능 개선)
 *
 * @author jdh
 * @since 2019.11.11
 */
@Service("statInqService")
public class StatInqService extends EgovAbstractServiceImpl {

    @Resource(name = "statInqMapper")
    private StatInqMapper statInqMapper;

    public List<EgovMap> selectCivilStat(Map<String, Object> p) throws Exception {
        String by = (String) p.get("groupBy");
        if ("afair".equals(by)) {
            return statInqMapper.selectCivilStatByAfair(p);
        }
        if ("month".equals(by)) {
            return statInqMapper.selectCivilStatMonthly(p);
        }
        return statInqMapper.selectCivilStatByDept(p);
    }

    /** 화면 상단 "마지막 집계" 표시 */
    public EgovMap selectLastBatchLog() throws Exception {
        return statInqMapper.selectLastBatchLog();
    }
}
