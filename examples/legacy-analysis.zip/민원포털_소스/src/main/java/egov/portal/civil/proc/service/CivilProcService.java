package egov.portal.civil.proc.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : CivilProcService.java
 * @Description : 민원 처리 서비스
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.04.11      kjh          최초생성
 * @ 2016.09.02      lsy          이송
 * @author 통합포털 구축 kjh
 * @since 2016.04.11
 */
public interface CivilProcService {

    /** 처리 대상 목록 */
    List<EgovMap> selectProcList(CivilProcVO vo) throws Exception;

    /** 처리 대상 건수 */
    int selectProcListCnt(CivilProcVO vo) throws Exception;

    /** 민원 상세 */
    CivilProcVO selectProcDetail(CivilProcVO vo) throws Exception;

    /** 처리 이력 */
    List<EgovMap> selectProcHistList(String civilRcptNo) throws Exception;

    /** 이송 이력 */
    List<EgovMap> selectTrnsfHistList(String civilRcptNo) throws Exception;

    /** 처리 시작(담당자 확인) */
    void startProc(CivilProcVO vo) throws Exception;

    /** 처리 결과 등록(완료) */
    void updateProcResult(CivilProcVO vo) throws Exception;

    /** 부서 이송 */
    void trnsfCivil(CivilProcVO vo) throws Exception;

    /** 수동 배정 */
    void asgnManual(CivilProcVO vo) throws Exception;
}
