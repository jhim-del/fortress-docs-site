package egov.portal.pay.pg.web;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import egov.portal.cmm.LoginVO;
import egov.portal.cmm.util.PortalProperties;
import egov.portal.pay.pg.client.PgClient;
import egov.portal.pay.pg.service.PayService;
import egov.portal.pay.pg.service.PayVO;

/**
 * PG 결제창 연동
 *
 * @author ywk
 * @since 2019.08.19
 */
@Controller
@RequestMapping("/pay/pg")
public class PgLinkController {

    private static final Logger LOGGER = LoggerFactory.getLogger(PgLinkController.class);

    @Resource(name = "payService")
    private PayService payService;

    @Resource(name = "pgClient")
    private PgClient pgClient;

    /** 결제창 호출 페이지 (자동 submit) */
    @GetMapping("/payReq.do")
    public String payReq(@RequestParam("bizSe") String bizSe, @RequestParam("bizKey") String bizKey,
                         HttpSession session, HttpServletRequest req, Model model) throws Exception {
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        PayVO vo = payService.ready(bizSe, bizKey, user.getId());

        Map<String, String> p = new HashMap<String, String>();
        p.put("mid", PortalProperties.getProperty("pg.mid"));
        p.put("orderNo", vo.getOrderNo());
        p.put("amount", String.valueOf(vo.getStlmAmt()));
        p.put("goodsName", vo.getGoodsNm());
        p.put("buyerName", user.getName());
        p.put("returnUrl", req.getScheme() + "://" + req.getServerName() + ":" + req.getServerPort()
                + req.getContextPath() + "/pay/pg/payReturn.do");
        p.put("signature", pgClient.sign(p));

        model.addAttribute("pgParams", p);
        model.addAttribute("pgFormUrl", PortalProperties.getProperty("pg.relayUrl") + "/payForm");
        return "portal/pay/payReq";
    }

    /** 결제창 종료 후 브라우저 복귀 */
    @PostMapping("/payReturn.do")
    public String payReturn(@RequestParam Map<String, String> res, Model model) throws Exception {
        PayVO vo = payService.approve(new HashMap<String, String>(res));
        model.addAttribute("result", vo);
        return "portal/pay/payResult";
    }

    /** PG 서버 → 우리 서버 결과 통지 (입금전용계좌 입금 포함). 응답 본문 OK 필수 */
    @PostMapping("/payNoti.do")
    @ResponseBody
    public String payNoti(@RequestParam Map<String, String> res) {
        try {
            payService.approve(new HashMap<String, String>(res));
            return "OK";
        } catch (Exception e) {
            LOGGER.error("PG 노티 처리 실패 {}", res, e);
            return "FAIL";
        }
    }
}
