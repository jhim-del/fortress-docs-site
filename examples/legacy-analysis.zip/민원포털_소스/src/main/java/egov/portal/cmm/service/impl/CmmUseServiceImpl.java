package egov.portal.cmm.service.impl;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egov.portal.cmm.service.CmmUseService;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : CmmUseServiceImpl.java
 * @Description : 공통코드·휴일 조회 구현
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.03.25      kjh          최초생성
 * @ 2016.06.10      lsy          공휴일 조회 추가
 * @author 통합포털 구축 kjh
 * @since 2016.03.25
 */
@Service("cmmUseService")
public class CmmUseServiceImpl extends EgovAbstractServiceImpl implements CmmUseService {

    @Resource(name = "cmmUseDAO")
    private CmmUseDAO cmmUseDAO;

    @Override
    public List<EgovMap> selectCmmCodeDetail(String codeId) throws Exception {
        return cmmUseDAO.selectCmmCodeDetail(codeId);
    }

    @Override
    public Set<String> selectRestdeSet(String bgnde, String endde) throws Exception {
        Map<String, String> p = new HashMap<String, String>();
        p.put("bgnde", bgnde);
        p.put("endde", endde);
        Set<String> set = new HashSet<String>();
        for (EgovMap m : cmmUseDAO.selectRestdeList(p)) {
            set.add((String) m.get("restde"));
        }
        return set;
    }

    @Override
    public List<EgovMap> selectDeptList() throws Exception {
        return cmmUseDAO.selectDeptList();
    }

    // 2018.11 hjy: 신 결재 전환 때 개인 결재선 기능 제거, 결재자 선택용 직원 조회만 이관
    @Override
    public List<EgovMap> selectEmplList(String deptCode) throws Exception {
        return cmmUseDAO.selectEmplList(deptCode);
    }
}
