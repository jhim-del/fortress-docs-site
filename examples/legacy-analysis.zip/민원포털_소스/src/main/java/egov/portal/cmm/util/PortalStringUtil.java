package egov.portal.cmm.util;

import java.util.regex.Pattern;

/**
 * @Class Name : PortalStringUtil.java
 * @Description : 문자열 유틸
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.03.22      kjh          최초생성
 * @ 2016.11.08      pms          전화번호 포맷 추가
 * @author 통합포털 구축 kjh
 * @since 2016.03.22
 */
public final class PortalStringUtil {

    private static final Pattern PHONE = Pattern.compile("^(01[016789])(\\d{3,4})(\\d{4})$");

    private PortalStringUtil() {
    }

    public static boolean isEmpty(String str) {
        return str == null || str.trim().length() == 0;
    }

    public static boolean isNotEmpty(String str) {
        return !isEmpty(str);
    }

    public static String nvl(Object obj, String dflt) {
        return obj == null ? dflt : obj.toString();
    }

    public static String lpad(String str, int len, char pad) {
        StringBuilder sb = new StringBuilder();
        for (int i = str.length(); i < len; i++) {
            sb.append(pad);
        }
        return sb.append(str).toString();
    }

    public static String removeHyphen(String str) {
        return str == null ? null : str.replaceAll("-", "");
    }

    /** 01012345678 -> 010-1234-5678 */
    public static String formatPhone(String num) {
        String n = removeHyphen(num);
        if (n == null || !PHONE.matcher(n).matches()) {
            return num;
        }
        return n.replaceFirst(PHONE.pattern(), "$1-$2-$3");
    }

    /** 게시물 내용 화면 출력용 (태그 무력화) */
    public static String escapeHtml(String str) {
        if (str == null) {
            return "";
        }
        return str.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;")
                  .replaceAll("\"", "&quot;").replaceAll("'", "&#39;");
    }

    public static String cutString(String str, int len) {
        if (str == null || str.length() <= len) {
            return str;
        }
        return str.substring(0, len) + "..";
    }
}
