package egov.portal.bbs.inq.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egov.portal.bbs.inq.service.BbsNttVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : BbsInqDAO.java
 * @Description : 게시물 조회 DAO
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.04.26      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.04.26
 */
@Repository("bbsInqDAO")
public class BbsInqDAO extends EgovAbstractMapper {

    /** 목록 */
    public List<EgovMap> selectNttList(BbsNttVO vo) throws Exception {
        return selectList("bbsInqDAO.selectNttList", vo);
    }

    /** 건수 */
    public int selectNttListCnt(BbsNttVO vo) throws Exception {
        return (Integer) selectOne("bbsInqDAO.selectNttListCnt", vo);
    }

    /** 상단 공지 */
    public List<EgovMap> selectNoticeNttList(String vo) throws Exception {
        return selectList("bbsInqDAO.selectNoticeNttList", vo);
    }

    /** 상세 */
    public BbsNttVO selectNtt(BbsNttVO vo) throws Exception {
        return (BbsNttVO) selectOne("bbsInqDAO.selectNtt", vo);
    }

    /** 조회수 증가 */
    public int updateRdcnt(BbsNttVO vo) throws Exception {
        return update("bbsInqDAO.updateRdcnt", vo);
    }

}
