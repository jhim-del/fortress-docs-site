package egov.portal.bbs.inq.service;

import java.io.Serializable;
import egov.portal.cmm.ComDefaultVO;

/**
 * @Class Name : BbsNttVO.java
 * @Description : 게시물 VO
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.04.26      kjh          최초생성
 * @ 2019.10.28      sbk          비밀글 항목
 * @author 통합포털 구축 kjh
 * @since 2016.04.26
 */
public class BbsNttVO extends ComDefaultVO {

    private static final long serialVersionUID = 692296069461284539L;

    /** 게시물ID */
    private String nttId;
    /** 게시판ID */
    private String bbsId;
    /** 게시물 번호 */
    private long nttNo;
    /** 제목 */
    private String nttSj;
    /** 내용 */
    private String nttCn;
    /** 답글여부 */
    private String answerAt;
    /** 부모글 번호 */
    private long parntscttNo;
    /** 답글 깊이 */
    private int answerLc;
    /** 정렬순서 */
    private long sortOrdr;
    /** 조회수 */
    private int rdcnt;
    /** 사용여부 */
    private String useAt;
    /** 게시 시작일 */
    private String ntceBgnde;
    /** 게시 종료일 */
    private String ntceEndde;
    /** 작성자ID */
    private String ntcrId;
    /** 작성자명 */
    private String ntcrNm;
    /** 비밀번호 */
    private String password;
    /** 첨부파일 */
    private String atchFileId;
    /** 공지 여부 */
    private String noticeAt;
    /** 비밀글 여부 */
    private String secretAt;
    /** 등록일 */
    private String frstRegistPnttm;
    /** 등록자 */
    private String frstRegisterId;
    /** 수정자 */
    private String lastUpdusrId;
    /** 게시판명 */
    private String bbsNm;
    /** 답글 가능 */
    private String replyPosblAt;
    /** 첨부 가능 */
    private String fileAtchPosblAt;

    public String getNttId() { return nttId; }
    public void setNttId(String nttId) { this.nttId = nttId; }
    public String getBbsId() { return bbsId; }
    public void setBbsId(String bbsId) { this.bbsId = bbsId; }
    public long getNttNo() { return nttNo; }
    public void setNttNo(long nttNo) { this.nttNo = nttNo; }
    public String getNttSj() { return nttSj; }
    public void setNttSj(String nttSj) { this.nttSj = nttSj; }
    public String getNttCn() { return nttCn; }
    public void setNttCn(String nttCn) { this.nttCn = nttCn; }
    public String getAnswerAt() { return answerAt; }
    public void setAnswerAt(String answerAt) { this.answerAt = answerAt; }
    public long getParntscttNo() { return parntscttNo; }
    public void setParntscttNo(long parntscttNo) { this.parntscttNo = parntscttNo; }
    public int getAnswerLc() { return answerLc; }
    public void setAnswerLc(int answerLc) { this.answerLc = answerLc; }
    public long getSortOrdr() { return sortOrdr; }
    public void setSortOrdr(long sortOrdr) { this.sortOrdr = sortOrdr; }
    public int getRdcnt() { return rdcnt; }
    public void setRdcnt(int rdcnt) { this.rdcnt = rdcnt; }
    public String getUseAt() { return useAt; }
    public void setUseAt(String useAt) { this.useAt = useAt; }
    public String getNtceBgnde() { return ntceBgnde; }
    public void setNtceBgnde(String ntceBgnde) { this.ntceBgnde = ntceBgnde; }
    public String getNtceEndde() { return ntceEndde; }
    public void setNtceEndde(String ntceEndde) { this.ntceEndde = ntceEndde; }
    public String getNtcrId() { return ntcrId; }
    public void setNtcrId(String ntcrId) { this.ntcrId = ntcrId; }
    public String getNtcrNm() { return ntcrNm; }
    public void setNtcrNm(String ntcrNm) { this.ntcrNm = ntcrNm; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getAtchFileId() { return atchFileId; }
    public void setAtchFileId(String atchFileId) { this.atchFileId = atchFileId; }
    public String getNoticeAt() { return noticeAt; }
    public void setNoticeAt(String noticeAt) { this.noticeAt = noticeAt; }
    public String getSecretAt() { return secretAt; }
    public void setSecretAt(String secretAt) { this.secretAt = secretAt; }
    public String getFrstRegistPnttm() { return frstRegistPnttm; }
    public void setFrstRegistPnttm(String frstRegistPnttm) { this.frstRegistPnttm = frstRegistPnttm; }
    public String getFrstRegisterId() { return frstRegisterId; }
    public void setFrstRegisterId(String frstRegisterId) { this.frstRegisterId = frstRegisterId; }
    public String getLastUpdusrId() { return lastUpdusrId; }
    public void setLastUpdusrId(String lastUpdusrId) { this.lastUpdusrId = lastUpdusrId; }
    public String getBbsNm() { return bbsNm; }
    public void setBbsNm(String bbsNm) { this.bbsNm = bbsNm; }
    public String getReplyPosblAt() { return replyPosblAt; }
    public void setReplyPosblAt(String replyPosblAt) { this.replyPosblAt = replyPosblAt; }
    public String getFileAtchPosblAt() { return fileAtchPosblAt; }
    public void setFileAtchPosblAt(String fileAtchPosblAt) { this.fileAtchPosblAt = fileAtchPosblAt; }
}
