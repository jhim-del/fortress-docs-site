package egov.portal.cmm.util;

import egov.portal.cmm.ComDefaultVO;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/**
 * 2019 고도화 화면 공통 페이징 (컨트롤러마다 반복하던 PaginationInfo 세팅을 모음)
 *
 * @author ywk
 * @since 2019.07.08
 */
public final class PagingHelper {

    private PagingHelper() {
    }

    public static PaginationInfo of(ComDefaultVO vo, int pageUnit) {
        PaginationInfo p = new PaginationInfo();
        p.setCurrentPageNo(vo.getPageIndex());
        p.setRecordCountPerPage(pageUnit);
        p.setPageSize(10);
        vo.setPageUnit(pageUnit);
        vo.setFirstIndex(p.getFirstRecordIndex());
        vo.setLastIndex(p.getLastRecordIndex());
        vo.setRecordCountPerPage(p.getRecordCountPerPage());
        return p;
    }
}
