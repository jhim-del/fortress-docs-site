package egov.portal.pay.pg.service;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import egov.portal.cmm.exception.BizException;
import egov.portal.cmm.util.PortalDateUtil;
import egov.portal.pay.pg.client.PgClient;
import egov.portal.pay.pg.service.impl.PayMapper;
import egov.portal.rsv.apply.service.impl.RsvApplyDAO;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * 결제 준비·승인·취소
 * <p>
 * 2019.10.07 ywk 부분취소(예약 위약금 차감) 추가
 *
 * @author ywk
 * @since 2019.08.19
 */
@Service("payService")
public class PayService extends EgovAbstractServiceImpl {

    private static final Logger LOGGER = LoggerFactory.getLogger(PayService.class);

    @Resource(name = "payMapper")
    private PayMapper payMapper;

    @Resource(name = "pgClient")
    private PgClient pgClient;

    @Resource(name = "rsvApplyDAO")
    private RsvApplyDAO rsvApplyDAO;

    /** 결제 준비: 업무 금액을 서버에서 다시 조회해 주문 생성 (화면 금액은 믿지 않음) */
    public PayVO ready(String bizSe, String bizKey, String mbrId) throws Exception {
        PayVO vo = new PayVO();
        vo.setBizSe(bizSe);
        vo.setBizKey(bizKey);
        EgovMap biz = payMapper.selectBizInfo(vo);
        if (biz == null) {
            throw new BizException("pay.biz.notFound");
        }
        vo.setStlmId("STL" + PortalDateUtil.getToday("yyMMddHHmmssSSS"));
        vo.setOrderNo(bizSe + "-" + bizKey);
        vo.setGoodsNm((String) biz.get("goodsNm"));
        vo.setStlmAmt(((Number) biz.get("amt")).longValue());
        vo.setMbrId(mbrId);
        vo.setStlmSttus("READY");
        payMapper.insertStlm(vo);
        return vo;
    }

    /**
     * 결제 결과 반영 (PG 리턴 URL / 노티 URL 공통).
     * 노티가 먼저 오는 경우가 있어 이미 PAID 면 무시한다.
     */
    public PayVO approve(Map<String, String> res) throws Exception {
        String sig = res.remove("signature");
        if (!pgClient.verify(res, sig)) {
            LOGGER.warn("PG 서명 불일치 orderNo={}", res.get("orderNo"));
            throw new BizException("pay.sign.invalid");
        }
        PayVO vo = payMapper.selectStlmByOrderNo(res.get("orderNo"));
        if (vo == null) {
            throw new BizException("pay.order.notFound");
        }
        if ("PAID".equals(vo.getStlmSttus())) {
            return vo;
        }
        if (Long.parseLong(res.get("amount")) != vo.getStlmAmt()) {
            LOGGER.error("결제 금액 불일치 orderNo={} 요청={} 응답={}", vo.getOrderNo(), vo.getStlmAmt(), res.get("amount"));
            throw new BizException("pay.amount.mismatch");
        }

        vo.setPgTid(res.get("tid"));
        vo.setStlmTy(res.get("payMethod"));
        vo.setApprNo(res.get("authNo"));
        vo.setApprDt(res.get("authDate"));
        vo.setVbankNo(res.get("vbankNum"));
        vo.setVbankDdln(res.get("vbankExpDate"));
        vo.setStlmSttus("0000".equals(res.get("resultCode")) ? "PAID" : "FAIL");
        payMapper.updateApprove(vo);
        log(vo.getStlmId(), "APPROVE", res.toString());

        if ("RSV".equals(vo.getBizSe())) {
            Map<String, Object> p = new HashMap<String, Object>();
            p.put("resveId", vo.getBizKey());
            p.put("stlmId", vo.getStlmId());
            p.put("payOk", "PAID".equals(vo.getStlmSttus()) ? "Y" : "N");
            rsvApplyDAO.updatePayResult(p);
        }
        return vo;
    }

    public EgovMap selectStlm(String stlmId) throws Exception {
        return payMapper.selectStlm(stlmId);
    }

    /** 취소 (부분취소 포함). TODO 중계 서버 타임아웃 시 망취소 처리 - PG사 회신 대기(2019.10) */
    public void cancel(String stlmId, long amt, String reason) throws Exception {
        EgovMap s = payMapper.selectStlm(stlmId);
        long paid = ((Number) s.get("stlmAmt")).longValue();
        long canceled = ((Number) s.get("cnclAmt")).longValue();
        if (amt <= 0 || amt > paid - canceled) {
            throw new BizException("pay.cancel.amount");
        }
        Map<String, String> req = new HashMap<String, String>();
        req.put("tid", (String) s.get("pgTid"));
        req.put("cancelAmt", String.valueOf(amt));
        req.put("partialCancel", amt < paid - canceled ? "1" : "0");
        req.put("reason", reason);
        Map<String, Object> res = pgClient.post("/cancel", req);
        log(stlmId, "CANCEL", String.valueOf(res));
        if (!"2001".equals(res.get("resultCode"))) {
            throw new BizException("pay.cancel.fail", res.get("resultMsg"));
        }

        Map<String, Object> p = new HashMap<String, Object>();
        p.put("stlmId", stlmId);
        p.put("cnclAmt", amt);
        p.put("stlmSttus", canceled + amt == paid ? "CNCL" : "PCNCL");
        payMapper.updateCancel(p);
    }

    private void log(String stlmId, String ty, String body) {
        try {
            Map<String, Object> l = new HashMap<String, Object>();
            l.put("stlmId", stlmId);
            l.put("logTy", ty);
            l.put("logCn", body.length() > 3900 ? body.substring(0, 3900) : body);
            payMapper.insertPgLog(l);
        } catch (Exception e) {
            LOGGER.error("PG 로그 저장 실패", e);
        }
    }
}
