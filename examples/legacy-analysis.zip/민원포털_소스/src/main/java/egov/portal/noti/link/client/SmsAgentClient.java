package egov.portal.noti.link.client;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import egov.portal.cmm.util.PortalProperties;

/**
 * 문자 발송 에이전트 테이블 적재 (별도 DB, 에이전트가 폴링해서 통신사로 전송)
 *
 * @author jdh
 * @since 2019.09.10
 */
@Component("smsAgentClient")
public class SmsAgentClient {

    @Resource(name = "smsAgtJdbcTemplate")
    private JdbcTemplate jdbcTemplate;

    private static final String INSERT_SMS =
        "INSERT INTO SMS_AGT_SEND (MSG_ID, DEST_PHONE, SEND_PHONE, MSG_BODY, MSG_TYPE, REQ_DATE, STATUS) "
      + "VALUES (SMS_AGT_SEQ.NEXTVAL, ?, ?, ?, ?, SYSDATE, '0')";

    private static final String INSERT_LMS =
        "INSERT INTO SMS_AGT_SEND (MSG_ID, DEST_PHONE, SEND_PHONE, SUBJECT, MSG_BODY, MSG_TYPE, REQ_DATE, STATUS) "
      + "VALUES (SMS_AGT_SEQ.NEXTVAL, ?, ?, ?, ?, ?, SYSDATE, '0')";

    public void send(String to, String msg) {
        String from = PortalProperties.getProperty("sms.callbackNo");
        jdbcTemplate.update(INSERT_SMS, to, from, msg, "S");
    }

    public void sendLms(String to, String subject, String msg) {
        String from = PortalProperties.getProperty("sms.callbackNo");
        jdbcTemplate.update(INSERT_LMS, to, from, subject, msg, "L");
    }
}
