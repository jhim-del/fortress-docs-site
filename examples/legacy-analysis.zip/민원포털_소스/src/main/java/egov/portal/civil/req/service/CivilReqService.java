package egov.portal.civil.req.service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import egov.portal.assign.conf.service.AssignConfService;
import egov.portal.civil.cmm.CivilDdlnCalculator;
import egov.portal.civil.req.service.impl.CivilReqMapper;
import egov.portal.cmm.exception.BizException;
import egov.portal.cmm.file.service.FileMngService;
import egov.portal.cmm.file.service.FileVO;
import egov.portal.cmm.util.PortalDateUtil;
import egov.portal.cmm.util.PortalStringUtil;
import egov.portal.noti.link.service.NotiLinkService;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * 민원 신청 서비스 (2019 고도화: 온라인 신청 개편)
 * <p>
 * 2019.11.25 jdh 접수 시 담당자 자동 배정 연동(AssignConfService)
 * 2020.03.09 hjy 접수 문자 문구 변경(처리기한 표시)
 *
 * @author ywk
 * @since 2019.07.15
 */
@Service("civilReqService")
public class CivilReqService extends EgovAbstractServiceImpl {

    private static final Logger LOGGER = LoggerFactory.getLogger(CivilReqService.class);

    @Resource(name = "civilReqMapper")
    private CivilReqMapper civilReqMapper;

    @Resource(name = "civilDdlnCalculator")
    private CivilDdlnCalculator ddlnCalculator;

    @Resource(name = "fileMngService")
    private FileMngService fileMngService;

    @Resource(name = "assignConfService")
    private AssignConfService assignConfService;

    @Resource(name = "notiLinkService")
    private NotiLinkService notiLinkService;

    public List<EgovMap> selectAfairList() throws Exception {
        return civilReqMapper.selectAfairList();
    }

    public EgovMap selectAfairInfo(String afairCode) throws Exception {
        return civilReqMapper.selectAfairInfo(afairCode);
    }

    /**
     * 접수번호 채번: yyyy-0000001 (연도별 일련번호)
     * 2016 시스템은 시퀀스(SEQ_CIVIL_RCPT)라 연도가 바뀌어도 번호가 이어졌음 → 2019 개편 시 연도별 테이블로 변경
     */
    public String createRcptNo(String rcptYear) throws Exception {
        Integer last = civilReqMapper.selectRcptSeqForUpdate(rcptYear);
        if (last == null) {
            civilReqMapper.insertRcptSeq(rcptYear);
            last = 0;
        }
        int next = last + 1;
        Map<String, Object> p = new HashMap<String, Object>();
        p.put("rcptYear", rcptYear);
        p.put("lastSn", next);
        civilReqMapper.updateRcptSeq(p);
        return rcptYear + "-" + PortalStringUtil.lpad(String.valueOf(next), 7, '0');
    }

    /**
     * 민원 접수
     * 1) 접수번호 채번, 처리기한 계산 후 TB_CIVIL_RCPT 저장 (PROC_STTUS_CODE = RCPT)
     * 2) 담당자 자동 배정 (부서별 순번)
     * 3) 신청인에게 접수 문자
     */
    public String submit(CivilReqVO vo, List<FileVO> files) throws Exception {
        EgovMap afair = civilReqMapper.selectAfairInfo(vo.getAfairCode());
        if (afair == null || !"Y".equals(afair.get("useAt"))) {
            throw new BizException("civil.afair.closed");
        }

        if (files != null && !files.isEmpty()) {
            vo.setAtchFileId(fileMngService.insertFiles(files));
        }

        String today = PortalDateUtil.getToday();
        vo.setCivilRcptNo(createRcptNo(today.substring(0, 4)));
        vo.setRcptDt(today);
        vo.setRcptMthdCode("ONL");
        vo.setChrgDeptCode((String) afair.get("chrgDeptCode"));
        int procPd = ((BigDecimal) afair.get("procPd")).intValue();
        vo.setProcDdlnDt(ddlnCalculator.calc(today, procPd, (String) afair.get("procPdSe")));
        vo.setProcSttusCode("RCPT");
        civilReqMapper.insertCivilRcpt(vo);

        Map<String, Object> hist = new HashMap<String, Object>();
        hist.put("civilRcptNo", vo.getCivilRcptNo());
        hist.put("procSttusCode", "RCPT");
        hist.put("procCn", "온라인 접수");
        hist.put("processrId", vo.getApplcntId());
        civilReqMapper.insertProcHist(hist);

        // 2019.11 jdh: 담당자 자동 배정
        Map<String, Object> asgn = new HashMap<String, Object>();
        asgn.put("CIVIL_RCPT_NO", vo.getCivilRcptNo());
        asgn.put("DEPT_CD", vo.getChrgDeptCode());
        asgn.put("PROC_STTUS_CODE", "RCPT");
        assignConfService.autoAssign(asgn);
        if (!"RCPT".equals(asgn.get("PROC_STTUS_CODE"))) {
            vo.setProcSttusCode((String) asgn.get("PROC_STTUS_CODE"));
            vo.setChargerId((String) asgn.get("CHARGER_ID"));
            civilReqMapper.updateAsgnResult(vo);
        }

        // String msg = "[통합 민원 포털] 민원이 접수되었습니다(" + vo.getCivilRcptNo() + ")";
        String msg = "[통합 민원 포털] 민원 접수 " + vo.getCivilRcptNo() + ", 처리기한 "
                + PortalDateUtil.formatDate(vo.getProcDdlnDt(), ".");
        notiLinkService.sendSms(vo.getApplcntMbtlnum(), msg);

        LOGGER.info("민원 접수 {} 사무={} 부서={} 상태={}", vo.getCivilRcptNo(), vo.getAfairCode(), vo.getChrgDeptCode(), vo.getProcSttusCode());
        return vo.getCivilRcptNo();
    }

    public List<EgovMap> selectMyReqList(CivilReqVO vo) throws Exception {
        return civilReqMapper.selectMyReqList(vo);
    }

    public int selectMyReqListCnt(CivilReqVO vo) throws Exception {
        return civilReqMapper.selectMyReqListCnt(vo);
    }

    public CivilReqVO selectMyReqDetail(CivilReqVO vo) throws Exception {
        return civilReqMapper.selectMyReqDetail(vo);
    }

    public EgovMap selectMyReqSttus(String applcntId) throws Exception {
        return civilReqMapper.selectMyReqSttus(applcntId);
    }

    /** 민원 취하: 담당자 배정 전(RCPT, WAIT_MANUAL)까지만 */
    public void withdraw(CivilReqVO vo) throws Exception {
        int cnt = civilReqMapper.updateWithdraw(vo);
        if (cnt == 0) {
            throw new BizException("civil.withdraw.notAllowed");
        }
    }
}
