package egov.portal.auth.menu.service;

import java.io.Serializable;

/**
 * @Class Name : MenuVO.java
 * @Description : 메뉴 VO
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.03.30      kjh          최초생성
 * @ 2019.07.22      ywk          표시여부 추가
 * @author 통합포털 구축 kjh
 * @since 2016.03.30
 */
public class MenuVO implements Serializable {

    private static final long serialVersionUID = 498790530352997302L;

    /** 메뉴번호 */
    private int menuNo;
    /** 상위메뉴번호 */
    private int upperMenuNo;
    /** 메뉴명 */
    private String menuNm;
    /** 메뉴순서 */
    private int menuOrdr;
    /** URL */
    private String menuUrl;
    /** 설명 */
    private String menuDc;
    /** 좌측 표시여부 */
    private String displayAt;
    /** 사용여부 */
    private String useAt;

    public int getMenuNo() { return menuNo; }
    public void setMenuNo(int menuNo) { this.menuNo = menuNo; }
    public int getUpperMenuNo() { return upperMenuNo; }
    public void setUpperMenuNo(int upperMenuNo) { this.upperMenuNo = upperMenuNo; }
    public String getMenuNm() { return menuNm; }
    public void setMenuNm(String menuNm) { this.menuNm = menuNm; }
    public int getMenuOrdr() { return menuOrdr; }
    public void setMenuOrdr(int menuOrdr) { this.menuOrdr = menuOrdr; }
    public String getMenuUrl() { return menuUrl; }
    public void setMenuUrl(String menuUrl) { this.menuUrl = menuUrl; }
    public String getMenuDc() { return menuDc; }
    public void setMenuDc(String menuDc) { this.menuDc = menuDc; }
    public String getDisplayAt() { return displayAt; }
    public void setDisplayAt(String displayAt) { this.displayAt = displayAt; }
    public String getUseAt() { return useAt; }
    public void setUseAt(String useAt) { this.useAt = useAt; }
}
