package egov.portal.pay.pg.service;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 결제 VO
 *
 * @author ywk
 * @since 2019.08.19
 */
@Getter
@Setter
@ToString
public class PayVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 결제ID */
    private String stlmId;
    /** 주문번호 */
    private String orderNo;
    /** 업무구분(RSV/CIVIL) */
    private String bizSe;
    /** 업무키 */
    private String bizKey;
    /** 상품명 */
    private String goodsNm;
    /** 결제금액 */
    private long stlmAmt;
    /** 취소누계 */
    private long cnclAmt;
    /** 결제수단(CARD/TRANS/VBANK) */
    private String stlmTy;
    /** PG 거래번호 */
    private String pgTid;
    /** 승인번호 */
    private String apprNo;
    /** 승인일시 */
    private String apprDt;
    /** 입금전용계좌번호 */
    private String vbankNo;
    /** 입금기한 */
    private String vbankDdln;
    /** 상태(READY/PAID/CNCL/PCNCL/FAIL) */
    private String stlmSttus;
    /** 회원ID */
    private String mbrId;
}
