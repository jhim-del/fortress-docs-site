package egov.portal.code.cmmn.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egov.portal.code.cmmn.service.CmmnCodeVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : CmmnCodeDAO.java
 * @Description : 공통코드 DAO
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.03.25      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.03.25
 */
@Repository("cmmnCodeDAO")
public class CmmnCodeDAO extends EgovAbstractMapper {

    /** 코드ID 목록 */
    public List<EgovMap> selectCodeIdList(CmmnCodeVO vo) throws Exception {
        return selectList("cmmnCodeDAO.selectCodeIdList", vo);
    }

    /** 상세 목록 */
    public List<EgovMap> selectCodeDetailList(String vo) throws Exception {
        return selectList("cmmnCodeDAO.selectCodeDetailList", vo);
    }

    /** 코드ID 수정 */
    public int updateCodeId(CmmnCodeVO vo) throws Exception {
        return update("cmmnCodeDAO.updateCodeId", vo);
    }

    /** 코드ID 등록 */
    public void insertCodeId(CmmnCodeVO vo) throws Exception {
        insert("cmmnCodeDAO.insertCodeId", vo);
    }

    /** 상세 수정 */
    public int updateCodeDetail(CmmnCodeVO vo) throws Exception {
        return update("cmmnCodeDAO.updateCodeDetail", vo);
    }

    /** 상세 등록 */
    public void insertCodeDetail(CmmnCodeVO vo) throws Exception {
        insert("cmmnCodeDAO.insertCodeDetail", vo);
    }

}
