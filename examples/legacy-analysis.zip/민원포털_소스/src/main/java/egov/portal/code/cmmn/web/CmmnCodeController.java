package egov.portal.code.cmmn.web;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egov.portal.cmm.LoginVO;
import egov.portal.code.cmmn.service.CmmnCodeService;
import egov.portal.code.cmmn.service.CmmnCodeVO;

/**
 * @Class Name : CmmnCodeController.java
 * @Description : 공통코드 관리 (관리자, 좌: 코드ID / 우: 상세코드)
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.03.25      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.03.25
 */
@Controller
public class CmmnCodeController {

    @Resource(name = "cmmnCodeService")
    private CmmnCodeService cmmnCodeService;

    @RequestMapping("/mng/code/cmmn/codeList.do")
    public String codeList(@ModelAttribute("searchVO") CmmnCodeVO searchVO,
                           @RequestParam(value = "selCodeId", required = false) String selCodeId, ModelMap model) throws Exception {
        model.addAttribute("codeIdList", cmmnCodeService.selectCodeIdList(searchVO));
        if (selCodeId != null) {
            model.addAttribute("selCodeId", selCodeId);
            model.addAttribute("detailList", cmmnCodeService.selectCodeDetailList(selCodeId));
        }
        return "mng/code/codeList";
    }

    @RequestMapping("/mng/code/cmmn/saveCodeId.do")
    public String saveCodeId(@ModelAttribute("cmmnCodeVO") CmmnCodeVO vo, HttpSession session) throws Exception {
        vo.setFrstRegisterId(((LoginVO) session.getAttribute("loginVO")).getId());
        cmmnCodeService.saveCodeId(vo);
        return "redirect:/mng/code/cmmn/codeList.do?selCodeId=" + vo.getCodeId();
    }

    @RequestMapping("/mng/code/cmmn/saveCodeDetail.do")
    public String saveCodeDetail(@ModelAttribute("cmmnCodeVO") CmmnCodeVO vo, HttpSession session) throws Exception {
        vo.setFrstRegisterId(((LoginVO) session.getAttribute("loginVO")).getId());
        cmmnCodeService.saveCodeDetail(vo);
        return "redirect:/mng/code/cmmn/codeList.do?selCodeId=" + vo.getCodeId();
    }
}
