package egov.portal.cmm.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import egovframework.rte.fdl.cmmn.exception.handler.ExceptionHandler;

/**
 * 서비스 예외 공통 로그 (context-aspect.xml)
 * @author kjh
 * @since 2016.03.24
 */
public class PortalExceptionHandler implements ExceptionHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(PortalExceptionHandler.class);

    @Override
    public void occur(Exception ex, String packageName) {
        LOGGER.error("[{}] {}", packageName, ex.getMessage(), ex);
        // TODO 운영 장애 문자 알림 연계 (2016 구축 범위 제외)
    }
}
