package egov.portal.rsv.apply.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egov.portal.cmm.LoginVO;
import egov.portal.cmm.util.PortalDateUtil;
import egov.portal.rsv.apply.service.RsvApplyService;
import egov.portal.rsv.apply.service.RsvApplyVO;
import egov.portal.rsv.fac.service.FacService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * 시설 예약 (사용자)
 * @author lsy
 * @since 2016.05.20
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2016.05.20  lsy       최초 생성
 *   2019.08.26  jdh       유료 시설 결제 화면 이동
 * </pre>
 */
@Controller
public class RsvApplyController {

    @Resource(name = "rsvApplyService")
    private RsvApplyService rsvApplyService;

    @Resource(name = "facService")
    private FacService facService;

    /** 예약 달력 */
    @RequestMapping("/rsv/apply/calendar.do")
    public String calendar(@ModelAttribute("searchVO") RsvApplyVO searchVO, ModelMap model) throws Exception {
        List<EgovMap> facList = facService.selectUseFacList();
        if (searchVO.getFcltyId() == null && !facList.isEmpty()) {
            searchVO.setFcltyId((String) facList.get(0).get("fcltyId"));
        }
        if (searchVO.getSearchYm() == null) {
            searchVO.setSearchYm(PortalDateUtil.getToday("yyyyMM"));
        }
        model.addAttribute("facList", facList);
        model.addAttribute("fac", facService.selectFac(searchVO.getFcltyId()));
        model.addAttribute("dayList", rsvApplyService.selectMonthResveSttus(searchVO));
        return "portal/rsv/calendar";
    }

    /** 일자 선택 시 시간 칸 (ajax) */
    @RequestMapping("/rsv/apply/timeSlot.do")
    public String timeSlot(@ModelAttribute("searchVO") RsvApplyVO searchVO, ModelMap model) throws Exception {
        model.addAttribute("slotList", rsvApplyService.selectDayTimeSlot(searchVO));
        return "jsonView";
    }

    @RequestMapping("/rsv/apply/applyForm.do")
    public String applyForm(@ModelAttribute("rsvApplyVO") RsvApplyVO vo, HttpSession session, ModelMap model) throws Exception {
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        vo.setApplcntNm(user.getName());
        vo.setMbtlnum(user.getMbtlnum());
        model.addAttribute("fac", facService.selectFac(vo.getFcltyId()));
        return "portal/rsv/applyForm";
    }

    @RequestMapping("/rsv/apply/apply.do")
    public String apply(@ModelAttribute("rsvApplyVO") RsvApplyVO vo, HttpSession session) throws Exception {
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        vo.setApplcntId(user.getId());
        String resveId = rsvApplyService.insertResve(vo);
        if ("PAY_WAIT".equals(vo.getResveSttusCode())) {
            return "redirect:/pay/pg/payReq.do?bizSe=RSV&bizKey=" + resveId;
        }
        return "redirect:/rsv/apply/myRsvList.do";
    }

    @RequestMapping("/rsv/apply/myRsvList.do")
    public String myRsvList(HttpSession session, ModelMap model) throws Exception {
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        RsvApplyVO vo = new RsvApplyVO();
        vo.setApplcntId(user.getId());
        model.addAttribute("resultList", rsvApplyService.selectMyResveList(vo));
        return "portal/rsv/myRsvList";
    }

    /** 취소 전 위약금 확인 (ajax) */
    @RequestMapping("/rsv/apply/pnlty.do")
    public String pnlty(@RequestParam("resveId") String resveId, ModelMap model) throws Exception {
        RsvApplyVO vo = new RsvApplyVO();
        vo.setResveId(resveId);
        model.addAttribute("pnltyAmt", rsvApplyService.calcPnlty(vo));
        return "jsonView";
    }

    @RequestMapping("/rsv/apply/cancel.do")
    public String cancel(@ModelAttribute("rsvApplyVO") RsvApplyVO vo, HttpSession session) throws Exception {
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        vo.setApplcntId(user.getId());
        rsvApplyService.cancelResve(vo);
        if ("CANCL_REFUND".equals(vo.getResveSttusCode())) {
            return "redirect:/refund/req/reqForm.do?bizSe=RSV&bizKey=" + vo.getResveId();
        }
        return "redirect:/rsv/apply/myRsvList.do";
    }
}
