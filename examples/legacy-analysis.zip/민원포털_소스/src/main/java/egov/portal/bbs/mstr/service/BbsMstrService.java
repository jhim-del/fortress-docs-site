package egov.portal.bbs.mstr.service;

/**
 * 게시판 설정 조회. 게시판 생성·변경은 운영 요청 시 DB 반영 (2016 구축 범위: 공지, 묻고답하기, 자료실 3개)
 * @author chw
 * @since 2016.04.25
 */
public interface BbsMstrService {

    BbsMstrVO selectBbsMstr(String bbsId) throws Exception;
}
