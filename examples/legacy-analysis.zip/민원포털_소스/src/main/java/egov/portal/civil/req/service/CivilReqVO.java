package egov.portal.civil.req.service;

import java.io.Serializable;
import egov.portal.cmm.ComDefaultVO;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 민원 신청 VO
 *
 * @author ywk
 * @since 2019.07.15
 */
@Getter
@Setter
@ToString
public class CivilReqVO extends ComDefaultVO {

    private static final long serialVersionUID = 1L;

    /** 민원 접수번호(yyyy-0000000) */
    private String civilRcptNo;
    /** 민원 사무 코드 */
    private String afairCode;
    /** 민원 사무명 */
    private String afairNm;
    /** 신청인 아이디 */
    private String applcntId;
    /** 신청인 성명 */
    private String applcntNm;
    /** 신청인 휴대전화 */
    private String applcntMbtlnum;
    /** 신청인 이메일 */
    private String applcntEmail;
    /** 우편번호 */
    private String zip;
    /** 주소 */
    private String adres;
    /** 상세주소 */
    private String detailAdres;
    /** 민원 제목 */
    private String civilSj;
    /** 민원 내용 */
    private String civilCn;
    /** 접수방법(ONL/VST/FAX/MAIL) */
    private String rcptMthdCode;
    /** 접수일 */
    private String rcptDt;
    /** 처리기한 */
    private String procDdlnDt;
    /** 처리상태 */
    private String procSttusCode;
    /** 처리상태명 */
    private String procSttusNm;
    /** 담당부서 */
    private String chrgDeptCode;
    /** 담당자 */
    private String chargerId;
    /** 처리결과 */
    private String procResultCn;
    /** 첨부파일 */
    private String atchFileId;
    /** 공개여부 */
    private String othbcAt;
    /** 검색-상태 */
    private String schSttus;
    /** 검색-접수연도 */
    private String schYear;
}
