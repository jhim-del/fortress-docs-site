package egov.portal.mbr.dormant.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 휴면 전환 DAO (pms 2016.08) */
@Repository("mbrDormantDAO")
public class MbrDormantDAO extends EgovAbstractMapper {

    public List<EgovMap> selectNoticeTargetList(Map<String, Object> p) {
        return selectList("mbrDormantDAO.selectNoticeTargetList", p);
    }

    public void insertNoticeHist(String mbrId) {
        insert("mbrDormantDAO.insertNoticeHist", mbrId);
    }

    public int insertDrmncyMbr(Map<String, Object> p) {
        return insert("mbrDormantDAO.insertDrmncyMbr", p);
    }

    public int updateMbrDormant(Map<String, Object> p) {
        return update("mbrDormantDAO.updateMbrDormant", p);
    }
}
