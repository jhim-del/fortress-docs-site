package egov.portal.bbs.wrt.service;

import java.util.List;

import egov.portal.bbs.inq.service.BbsNttVO;
import egov.portal.cmm.file.service.FileVO;

import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * 게시물 등록·수정·답글
 * @author lsy
 * @since 2016.04.28
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2016.04.28  lsy       최초 생성
 * </pre>
 */
public interface BbsWrtService {

    /** 등록 */
    void insertNtt(BbsNttVO vo, List<FileVO> files) throws Exception;

    /** 답글 등록 */
    void insertReply(BbsNttVO vo, List<FileVO> files) throws Exception;

    /** 수정 */
    void updateNtt(BbsNttVO vo, List<FileVO> files) throws Exception;

    /** 삭제(USE_AT=N) */
    void deleteNtt(BbsNttVO vo) throws Exception;
}
