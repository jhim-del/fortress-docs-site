package egov.portal.cmm.view;

import java.net.URLEncoder;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsxView;

/**
 * 엑셀 다운로드 공통 뷰
 * <p>
 * model: excelFileName, excelHeader(String[]), excelKeys(String[]), excelList(List<Map>)
 *
 * @author jdh
 * @since 2019.09.03
 */
public class ExcelDownView extends AbstractXlsxView {

    @Override
    @SuppressWarnings("unchecked")
    protected void buildExcelDocument(Map<String, Object> model, Workbook wb, HttpServletRequest req, HttpServletResponse res) throws Exception {
        String fileName = (String) model.get("excelFileName");
        String[] header = (String[]) model.get("excelHeader");
        String[] keys = (String[]) model.get("excelKeys");
        List<Map<String, Object>> list = (List<Map<String, Object>>) model.get("excelList");

        res.setHeader("Content-Disposition", "attachment; filename=\"" + URLEncoder.encode(fileName, "UTF-8").replaceAll("\\+", "%20") + ".xlsx\"");

        Sheet sheet = wb.createSheet(fileName);
        CellStyle hs = wb.createCellStyle();
        Font bold = wb.createFont();
        bold.setBold(true);
        hs.setFont(bold);

        Row hr = sheet.createRow(0);
        for (int i = 0; i < header.length; i++) {
            Cell c = hr.createCell(i);
            c.setCellValue(header[i]);
            c.setCellStyle(hs);
        }
        int r = 1;
        for (Map<String, Object> m : list) {
            Row row = sheet.createRow(r++);
            for (int i = 0; i < keys.length; i++) {
                Object v = m.get(keys[i]);
                if (v instanceof Number) {
                    row.createCell(i).setCellValue(((Number) v).doubleValue());
                } else {
                    row.createCell(i).setCellValue(v == null ? "" : v.toString());
                }
            }
        }
        for (int i = 0; i < header.length; i++) {
            sheet.autoSizeColumn(i);
        }
    }
}
