package egov.portal.cmm.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import egov.portal.cmm.LoginVO;

/**
 * 로그인 여부 확인 인터셉터
 * @author lsy
 * @since 2016.04.01
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2016.04.01  lsy       최초 생성
 *   2016.10.17  chw       관리자 URL 사용자구분 체크
 * </pre>
 */
public class AuthenticInterceptor extends HandlerInterceptorAdapter {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        LoginVO loginVO = (LoginVO) request.getSession().getAttribute("loginVO");
        String uri = request.getRequestURI();

        if (loginVO == null) {
            if ("XMLHttpRequest".equals(request.getHeader("X-Requested-With"))) {
                response.sendError(401);
                return false;
            }
            String ctx = request.getContextPath();
            String target = uri.startsWith(ctx + "/mng/") ? "/sec/login/mngLoginForm.do" : "/sec/login/loginForm.do";
            response.sendRedirect(ctx + target + "?returnUrl=" + java.net.URLEncoder.encode(uri, "UTF-8"));
            return false;
        }

        if (uri.contains("/mng/") && !"USR".equals(loginVO.getUserSe())) {
            ModelAndView mav = new ModelAndView("cmm/error/accessDenied");
            throw new org.springframework.web.servlet.ModelAndViewDefiningException(mav);
        }
        return true;
    }
}
