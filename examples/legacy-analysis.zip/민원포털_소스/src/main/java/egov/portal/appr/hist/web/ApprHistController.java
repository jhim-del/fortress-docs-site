package egov.portal.appr.hist.web;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egov.portal.appr.hist.service.ApprHistService;
import egov.portal.cmm.util.PortalDateUtil;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/**
 * 결재 이력 조회 (감사 대응)
 * @author lsy
 * @since 2016.06.22
 */
@Controller
public class ApprHistController {

    @Resource(name = "apprHistService")
    private ApprHistService apprHistService;

    @RequestMapping("/mng/appr/hist/histList.do")
    public String histList(@RequestParam Map<String, Object> p, ModelMap model) throws Exception {
        if (p.get("bgnde") == null) {
            p.put("endde", PortalDateUtil.getToday());
            p.put("bgnde", PortalDateUtil.addDay(PortalDateUtil.getToday(), -7));
        }
        PaginationInfo pi = new PaginationInfo();
        pi.setCurrentPageNo(p.get("pageIndex") == null ? 1 : Integer.parseInt(p.get("pageIndex").toString()));
        pi.setRecordCountPerPage(20);
        pi.setPageSize(10);
        p.put("firstIndex", pi.getFirstRecordIndex());
        p.put("recordCountPerPage", 20);
        pi.setTotalRecordCount(apprHistService.selectHistListCnt(p));

        model.addAttribute("resultList", apprHistService.selectHistList(p));
        model.addAttribute("paginationInfo", pi);
        model.addAttribute("searchMap", p);
        return "mng/appr/histList";
    }
}
