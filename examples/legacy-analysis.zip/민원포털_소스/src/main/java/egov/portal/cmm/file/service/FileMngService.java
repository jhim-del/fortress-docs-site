package egov.portal.cmm.file.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : FileMngService.java
 * @Description : 첨부파일 관리
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.03.28      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.03.28
 */
public interface FileMngService {

    /** 첨부 목록 */
    List<FileVO> selectFileList(String atchFileId) throws Exception;

    /** 첨부 1건 */
    FileVO selectFile(FileVO vo) throws Exception;

    /** 첨부 등록 후 ATCH_FILE_ID 반환 */
    String insertFiles(List<FileVO> files) throws Exception;

    /** 기존 묶음에 추가 */
    void addFiles(String atchFileId, List<FileVO> files) throws Exception;

    /** 첨부 1건 삭제(USE_AT=N) */
    void deleteFile(FileVO vo) throws Exception;
}
