package egov.portal.cmm.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.Set;

/**
 * 날짜 처리 유틸
 * @author lsy
 * @since 2016.03.22
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2016.03.22  lsy       최초 생성
 *   2016.06.10  lsy       영업일 계산 추가
 *   2019.08.20  jdh       LocalDate 메서드 추가
 * </pre>
 */
public class PortalDateUtil {

    public static final String YMD = "yyyyMMdd";
    public static final String YMDHMS = "yyyyMMddHHmmss";

    public static String getToday() {
        return getToday(YMD);
    }

    public static String getToday(String pattern) {
        return new SimpleDateFormat(pattern).format(new Date());
    }

    /**
     * yyyyMMdd 에 일수를 더한다 (역일 기준)
     */
    public static String addDay(String ymd, int days) {
        try {
            SimpleDateFormat fmt = new SimpleDateFormat(YMD);
            Calendar cal = Calendar.getInstance();
            cal.setTime(fmt.parse(ymd));
            cal.add(Calendar.DATE, days);
            return fmt.format(cal.getTime());
        } catch (ParseException e) {
            throw new IllegalArgumentException("날짜 형식 오류: " + ymd);
        }
    }

    /**
     * 토·일·공휴일을 빼고 영업일 기준으로 일수를 더한다.
     * 접수일 당일은 세지 않는다(민원 처리에 관한 법률 시행령 기간 계산 기준).
     * @param restdeSet 공휴일 yyyyMMdd 집합 (COMTNRESTDE)
     */
    public static String addWorkDay(String ymd, int days, Set<String> restdeSet) {
        String cur = ymd;
        int added = 0;
        while (added < days) {
            cur = addDay(cur, 1);
            if (isWeekend(cur) || restdeSet.contains(cur)) {
                continue;
            }
            added++;
        }
        return cur;
    }

    public static boolean isWeekend(String ymd) {
        try {
            Calendar cal = Calendar.getInstance();
            cal.setTime(new SimpleDateFormat(YMD).parse(ymd));
            int dow = cal.get(Calendar.DAY_OF_WEEK);
            return dow == Calendar.SATURDAY || dow == Calendar.SUNDAY;
        } catch (ParseException e) {
            return false;
        }
    }

    // 2019.08 jdh: 예약·환불 일수 계산용
    public static long daysBetween(String fromYmd, String toYmd) {
        DateTimeFormatter f = DateTimeFormatter.ofPattern(YMD);
        return ChronoUnit.DAYS.between(LocalDate.parse(fromYmd, f), LocalDate.parse(toYmd, f));
    }

    public static String formatDate(String ymd, String delim) {
        if (ymd == null || ymd.length() < 8) {
            return ymd;
        }
        return ymd.substring(0, 4) + delim + ymd.substring(4, 6) + delim + ymd.substring(6, 8);
    }
}
