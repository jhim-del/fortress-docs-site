package egov.portal.appr.doc.web;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egov.portal.appr.doc.service.ApprDocService;
import egov.portal.appr.doc.service.ApprDocVO;
import egov.portal.cmm.service.CmmUseService;
import egov.portal.cmm.LoginVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/**
 * @Class Name : ApprDocController.java
 * @Description : 결재함·상신·결재
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.06.20      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.06.20
 */
@Controller
public class ApprDocController {

    @Resource(name = "apprDocService")
    private ApprDocService apprDocService;

    @Resource(name = "cmmUseService")
    private CmmUseService cmmUseService;

    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

    /**
     * 결재함 (TODO 결재할 문서 / DRAFT 기안함 / DONE 결재한 문서 / REFR 참조)
     */
    @RequestMapping("/mng/appr/doc/docList.do")
    public String docList(@ModelAttribute("searchVO") ApprDocVO searchVO, HttpSession session, ModelMap model) throws Exception {
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        searchVO.setLoginId(user.getId());
        if (searchVO.getSearchBox() == null) {
            searchVO.setSearchBox("TODO");
        }
        searchVO.setPageUnit(propertiesService.getInt("mngPageUnit"));
        searchVO.setPageSize(propertiesService.getInt("pageSize"));

        PaginationInfo paginationInfo = new PaginationInfo();
        paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
        paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
        paginationInfo.setPageSize(searchVO.getPageSize());
        searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
        searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
        searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

        paginationInfo.setTotalRecordCount(apprDocService.selectDocListCnt(searchVO));
        model.addAttribute("resultList", apprDocService.selectDocList(searchVO));
        model.addAttribute("paginationInfo", paginationInfo);
        return "mng/appr/docList";
    }

    @RequestMapping("/mng/appr/doc/docView.do")
    public String docView(@RequestParam("docId") String docId, HttpSession session, ModelMap model) throws Exception {
        model.addAttribute("result", apprDocService.selectDoc(docId));
        model.addAttribute("lineList", apprDocService.selectSanctnLineList(docId));
        return "mng/appr/docView";
    }

    @RequestMapping("/mng/appr/doc/draftForm.do")
    public String draftForm(HttpSession session, ModelMap model) throws Exception {
        model.addAttribute("apprDocVO", new ApprDocVO());
        return "mng/appr/draftForm";
    }

    @RequestMapping("/mng/appr/doc/draft.do")
    public String draft(@ModelAttribute("apprDocVO") ApprDocVO vo, HttpSession session) throws Exception {
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        vo.setDrafterId(user.getId());
        vo.setDraftDeptCode(user.getDeptCode());
        String docId = apprDocService.insertDraft(vo);
        return "redirect:/mng/appr/doc/docView.do?docId=" + docId;
    }

    @RequestMapping("/mng/appr/doc/sanctn.do")
    public String sanctn(@ModelAttribute("apprDocVO") ApprDocVO vo, @RequestParam("act") String act, HttpSession session) throws Exception {
        vo.setLoginId(((LoginVO) session.getAttribute("loginVO")).getId());
        if ("OK".equals(act)) {
            apprDocService.approve(vo);
        } else if ("RJCT".equals(act)) {
            apprDocService.reject(vo);
        }
        return "redirect:/mng/appr/doc/docView.do?docId=" + vo.getDocId();
    }

    @RequestMapping("/mng/appr/doc/lineSelectPop.do")
    public String lineSelectPop(@RequestParam(value = "deptCode", required = false) String deptCode, ModelMap model) throws Exception {
        model.addAttribute("emplList", cmmUseService.selectEmplList(deptCode));
        return "mng/appr/lineSelectPop";
    }
}
