package egov.portal.noti.link.service;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egov.portal.cmm.util.PortalStringUtil;
import egov.portal.noti.link.service.impl.NotiLinkMapper;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * 문자·메일 발송 연계
 * <p>
 * 업무 화면은 이 서비스만 호출하고, 실제 발송은 NotiRetryJob 이 처리한다.
 * 2020.03.16 hjy 즉시 발송 제거(문자 에이전트 DB 잠금 장애, 장애보고 2020-031)
 *
 * @author jdh
 * @since 2019.09.10
 */
@Service("notiLinkService")
public class NotiLinkService extends EgovAbstractServiceImpl {

    @Resource(name = "notiLinkMapper")
    private NotiLinkMapper notiLinkMapper;

    // @Resource(name = "smsAgentClient")
    // private SmsAgentClient smsAgentClient;

    /**
     * 문자 발송 요청.
     * 바로 보내지 않고 TB_NOTI_LINK 큐에 적재한다(SEND_STTUS=W). 발송·재시도는 10분 주기 배치(noti.retry.cron).
     */
    public void sendSms(String mbtlnum, String msg) throws Exception {
        String to = PortalStringUtil.removeHyphen(mbtlnum);
        if (PortalStringUtil.isEmpty(to)) {
            return;
        }
        Map<String, Object> q = new HashMap<String, Object>();
        q.put("sendTy", msg.getBytes("EUC-KR").length > 90 ? "LMS" : "SMS");
        q.put("rcver", to);
        q.put("msgCn", msg);
        q.put("sendSttus", "W");
        q.put("tryCnt", 0);
        notiLinkMapper.insertQueue(q);

        // 2020.03 즉시 발송 제거
        // try {
        //     smsAgentClient.send(to, msg);
        //     q.put("sendSttus", "S");
        // } catch (Exception e) {
        //     q.put("sendSttus", "F");
        // }
    }

    /**
     * 메일 발송 요청 (문구 템플릿 사용)
     * @param vars 템플릿 치환값 (#{이름} 형태)
     */
    public void sendMail(String email, String tmplId, Map<String, String> vars) throws Exception {
        EgovMap tmpl = notiLinkMapper.selectTmpl(tmplId);
        if (tmpl == null || PortalStringUtil.isEmpty(email)) {
            return;
        }
        String title = (String) tmpl.get("tmplSj");
        String body = (String) tmpl.get("tmplCn");
        for (Map.Entry<String, String> e : vars.entrySet()) {
            body = body.replace("#{" + e.getKey() + "}", e.getValue());
            title = title.replace("#{" + e.getKey() + "}", e.getValue());
        }
        Map<String, Object> q = new HashMap<String, Object>();
        q.put("sendTy", "MAIL");
        q.put("rcver", email);
        q.put("title", title);
        q.put("msgCn", body);
        q.put("sendSttus", "W");
        q.put("tryCnt", 0);
        notiLinkMapper.insertQueue(q);
    }
}
