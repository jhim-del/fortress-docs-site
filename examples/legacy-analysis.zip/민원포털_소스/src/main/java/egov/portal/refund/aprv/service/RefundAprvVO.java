package egov.portal.refund.aprv.service;

import java.io.Serializable;
import egov.portal.cmm.ComDefaultVO;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 환불 승인 VO
 *
 * @author jdh
 * @since 2019.10.01
 */
@Getter
@Setter
@ToString
public class RefundAprvVO extends ComDefaultVO {

    private static final long serialVersionUID = 1L;

    /** 환불 순번 */
    private Long refundSeq;
    /** 결제ID */
    private String stlmId;
    /** 회원ID */
    private String mbrId;
    /** 회원명 */
    private String mbrNm;
    /** 회원등급 */
    private String mbrGrdCode;
    /** 휴대전화 */
    private String mbtlnum;
    /** 문자 수신 동의 */
    private String smsRecptnAt;
    /** 신청금액 */
    private long reqAmt;
    /** 수수료율 */
    private Integer feeRate;
    /** 수수료 */
    private long feeAmt;
    /** 환불액 */
    private long refundAmt;
    /** 은행 */
    private String bankCd;
    /** 계좌 */
    private String acntNo;
    /** 예금주 */
    private String dpstrNm;
    /** 상태(REQ/APRV/RJCT/DONE) */
    private String reqSttus;
    /** 결제일 */
    private String stlmDe;
    /** 승인자 */
    private String aprvId;
    /** 반려사유 */
    private String rjctRsn;
    /** 신청일 */
    private String regDt;
    /** 검색-상태 */
    private String schSttus;
    /** 검색-회원명 */
    private String schMbrNm;
}
