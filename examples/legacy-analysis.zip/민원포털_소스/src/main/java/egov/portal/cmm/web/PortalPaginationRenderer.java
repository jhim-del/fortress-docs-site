package egov.portal.cmm.web;

import egovframework.rte.ptl.mvc.tags.ui.pagination.AbstractPaginationRenderer;

/**
 * 페이지 번호 렌더러 (퍼블리싱 가이드 2016.05 반영)
 * @author pms
 * @since 2016.05.12
 */
public class PortalPaginationRenderer extends AbstractPaginationRenderer {

    public PortalPaginationRenderer() {
        firstPageLabel = "<a href=\"#\" class=\"first\" onclick=\"{0}({1}); return false;\">처음</a>";
        previousPageLabel = "<a href=\"#\" class=\"prev\" onclick=\"{0}({1}); return false;\">이전</a>";
        currentPageLabel = "<strong title=\"현재 페이지\">{0}</strong>";
        otherPageLabel = "<a href=\"#\" onclick=\"{0}({1}); return false;\">{2}</a>";
        nextPageLabel = "<a href=\"#\" class=\"next\" onclick=\"{0}({1}); return false;\">다음</a>";
        lastPageLabel = "<a href=\"#\" class=\"last\" onclick=\"{0}({1}); return false;\">끝</a>";
    }
}
