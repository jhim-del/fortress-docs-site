package egov.portal.code.cmmn.service;

import java.io.Serializable;
import egov.portal.cmm.ComDefaultVO;

/**
 * @Class Name : CmmnCodeVO.java
 * @Description : 공통코드 VO
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.03.25      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.03.25
 */
public class CmmnCodeVO extends ComDefaultVO {

    private static final long serialVersionUID = 377008369145223330L;

    /** 코드ID */
    private String codeId;
    /** 코드ID명 */
    private String codeIdNm;
    /** 코드ID설명 */
    private String codeIdDc;
    /** 분류코드 */
    private String clCode;
    /** 상세코드 */
    private String code;
    /** 상세코드명 */
    private String codeNm;
    /** 상세코드설명 */
    private String codeDc;
    /** 정렬순서 */
    private int sortOrdr;
    /** 사용여부 */
    private String useAt;
    /** 등록자 */
    private String frstRegisterId;

    public String getCodeId() { return codeId; }
    public void setCodeId(String codeId) { this.codeId = codeId; }
    public String getCodeIdNm() { return codeIdNm; }
    public void setCodeIdNm(String codeIdNm) { this.codeIdNm = codeIdNm; }
    public String getCodeIdDc() { return codeIdDc; }
    public void setCodeIdDc(String codeIdDc) { this.codeIdDc = codeIdDc; }
    public String getClCode() { return clCode; }
    public void setClCode(String clCode) { this.clCode = clCode; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public String getCodeNm() { return codeNm; }
    public void setCodeNm(String codeNm) { this.codeNm = codeNm; }
    public String getCodeDc() { return codeDc; }
    public void setCodeDc(String codeDc) { this.codeDc = codeDc; }
    public int getSortOrdr() { return sortOrdr; }
    public void setSortOrdr(int sortOrdr) { this.sortOrdr = sortOrdr; }
    public String getUseAt() { return useAt; }
    public void setUseAt(String useAt) { this.useAt = useAt; }
    public String getFrstRegisterId() { return frstRegisterId; }
    public void setFrstRegisterId(String frstRegisterId) { this.frstRegisterId = frstRegisterId; }
}
