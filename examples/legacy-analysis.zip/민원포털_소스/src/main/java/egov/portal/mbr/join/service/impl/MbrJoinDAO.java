package egov.portal.mbr.join.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egov.portal.mbr.join.service.MbrVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : MbrJoinDAO.java
 * @Description : 회원가입 DAO
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.04.04      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.04.04
 */
@Repository("mbrJoinDAO")
public class MbrJoinDAO extends EgovAbstractMapper {

    /** 아이디 중복 건수(탈퇴·휴면 포함) */
    public int selectIdDupCnt(String vo) throws Exception {
        return (Integer) selectOne("mbrJoinDAO.selectIdDupCnt", vo);
    }

    /** CI 로 회원 조회 */
    public String selectMbrIdByCi(String vo) throws Exception {
        return (String) selectOne("mbrJoinDAO.selectMbrIdByCi", vo);
    }

    /** 회원 등록 */
    public void insertMbr(MbrVO vo) throws Exception {
        insert("mbrJoinDAO.insertMbr", vo);
    }

    /** 약관 동의 이력 */
    public void insertMbrAgreHist(MbrVO vo) throws Exception {
        insert("mbrJoinDAO.insertMbrAgreHist", vo);
    }

}
