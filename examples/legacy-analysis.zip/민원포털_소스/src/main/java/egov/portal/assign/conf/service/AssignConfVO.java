package egov.portal.assign.conf.service;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 배정 설정 VO
 *
 * @author jdh
 * @since 2019.11.04
 */
@Getter
@Setter
@ToString
public class AssignConfVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 부서코드 */
    private String deptCd;
    /** 담당자 아이디 */
    private String chargerId;
    /** 담당자명 */
    private String chargerNm;
    /** 배정 순번 */
    private Integer asgnOrdr;
    /** 자동배정 대상 여부 */
    private String asgnYn;
    /** 최근 배정일시 */
    private String lastAsgnDt;
    /** 등록자 */
    private String regId;
    /** 수정자 */
    private String modId;
}
