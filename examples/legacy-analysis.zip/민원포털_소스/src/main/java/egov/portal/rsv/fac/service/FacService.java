package egov.portal.rsv.fac.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : FacService.java
 * @Description : 시설 정보 (시설 등록은 운영 담당이 DB 직접 반영, 2016.06 협의)
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.05.16      pms          최초생성
 * @author 통합포털 구축 pms
 * @since 2016.05.16
 */
public interface FacService {

    /** 시설 상세 */
    FacVO selectFac(String fcltyId) throws Exception;

    /** 사용자 화면 시설 목록 */
    List<EgovMap> selectUseFacList() throws Exception;
}
