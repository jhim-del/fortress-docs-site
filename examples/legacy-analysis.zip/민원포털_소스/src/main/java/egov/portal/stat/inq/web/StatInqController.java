package egov.portal.stat.inq.web;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egov.portal.cmm.service.CmmUseService;
import egov.portal.cmm.util.PortalDateUtil;
import egov.portal.stat.inq.service.StatInqService;

/**
 * 통계 (관리자)
 *
 * @author jdh
 * @since 2019.11.11
 */
@Controller
@RequestMapping("/mng/stat/inq")
public class StatInqController {

    @Resource(name = "statInqService")
    private StatInqService statInqService;

    @Resource(name = "cmmUseService")
    private CmmUseService cmmUseService;

    private void defaultPeriod(Map<String, Object> p) {
        if (p.get("schBgnDe") == null || "".equals(p.get("schBgnDe"))) {
            String today = PortalDateUtil.getToday();
            p.put("schBgnDe", today.substring(0, 6) + "01");
            p.put("schEndDe", PortalDateUtil.addDay(today, -1));
        }
    }

    @GetMapping("/civilStat.do")
    public String civilStat(@RequestParam Map<String, Object> p, Model model) throws Exception {
        defaultPeriod(p);
        model.addAttribute("resultList", statInqService.selectCivilStat(p));
        model.addAttribute("lastBatch", statInqService.selectLastBatchLog());
        model.addAttribute("deptList", cmmUseService.selectDeptList());
        model.addAttribute("param", p);
        return "mng/stat/civilStat";
    }

    @GetMapping("/civilStatExcel.do")
    public String civilStatExcel(@RequestParam Map<String, Object> p, Model model) throws Exception {
        defaultPeriod(p);
        model.addAttribute("excelFileName", "민원통계_" + p.get("schBgnDe") + "_" + p.get("schEndDe"));
        model.addAttribute("excelHeader", new String[] {"부서", "접수", "처리", "기한초과", "이송", "초과율(%)", "평균처리일"});
        model.addAttribute("excelKeys", new String[] {"deptNm", "rcptCnt", "procCnt", "ddlnOverCnt", "trnsfCnt", "overRate", "avgProcDays"});
        model.addAttribute("excelList", statInqService.selectCivilStat(p));
        return "excelDownView";
    }

}
