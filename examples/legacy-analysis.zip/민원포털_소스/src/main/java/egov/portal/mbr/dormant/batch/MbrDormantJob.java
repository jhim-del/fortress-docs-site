package egov.portal.mbr.dormant.batch;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import egov.portal.cmm.util.PortalDateUtil;
import egov.portal.mbr.dormant.service.impl.MbrDormantDAO;
import egov.portal.noti.link.service.NotiLinkService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * 휴면 회원 전환 배치 (개인정보 유효기간제)
 * @author pms
 * @since 2016.08.08
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2016.08.08  pms       최초 생성
 *   2019.09.30  jdh       사전 안내 메일 알림 연계, 기준일 설정값으로
 * </pre>
 */
@Component("mbrDormantJob")
public class MbrDormantJob {

    private static final Logger LOGGER = LoggerFactory.getLogger(MbrDormantJob.class);

    @Resource(name = "mbrDormantDAO")
    private MbrDormantDAO mbrDormantDAO;

    @Resource(name = "notiLinkService")
    private NotiLinkService notiLinkService;

    @Value("${mbr.dormant.days:365}")
    private int dormantDays;

    @Value("${mbr.dormant.noticeDays:30}")
    private int noticeDays;

    public void run() {
        try {
            notice();
            convert();
        } catch (Exception e) {
            LOGGER.error("휴면 전환 배치 실패", e);
        }
    }

    /** 1) 전환 예정자 사전 안내 (안내 이력 없는 사람만) */
    private void notice() throws Exception {
        Map<String, Object> p = new HashMap<String, Object>();
        p.put("days", dormantDays - noticeDays);
        List<EgovMap> list = mbrDormantDAO.selectNoticeTargetList(p);
        for (EgovMap m : list) {
            Map<String, String> vars = new HashMap<String, String>();
            vars.put("이름", (String) m.get("mbrNm"));
            vars.put("전환예정일", PortalDateUtil.formatDate(PortalDateUtil.addDay(PortalDateUtil.getToday(), noticeDays), "."));
            notiLinkService.sendMail((String) m.get("emailAdres"), "MAIL_DORMANT_NOTICE", vars);
            mbrDormantDAO.insertNoticeHist((String) m.get("mbrId"));
        }
        LOGGER.info("휴면 사전 안내 {}명", list.size());
    }

    /** 2) 전환: 분리 보관 테이블로 옮기고 원 테이블 개인정보 삭제 */
    private void convert() throws Exception {
        Map<String, Object> p = new HashMap<String, Object>();
        p.put("days", dormantDays);
        int moved = mbrDormantDAO.insertDrmncyMbr(p);
        int cleared = mbrDormantDAO.updateMbrDormant(p);
        if (moved != cleared) {
            LOGGER.warn("휴면 이관 {}건 / 원 테이블 처리 {}건 불일치", moved, cleared);
        }
        LOGGER.info("휴면 전환 {}명", moved);
    }
}
