package egov.portal.appr.doc.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egov.portal.appr.doc.service.ApprDocService;
import egov.portal.appr.doc.service.ApprDocVO;
import egov.portal.appr.hist.service.ApprHistService;
import egov.portal.cmm.exception.BizException;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.fdl.idgnr.EgovIdGnrService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : ApprDocServiceImpl.java
 * @Description : 결재 문서 구현
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.06.20      kjh          최초생성
 * @ 2016.09.26      kjh          합의(AGRE)·참조(REFR) 유형
 * @ 2018.11.05      hjy          신 결재 전환: 결재 이력 ApprHistService 로 기록
 * @author 통합포털 구축 kjh
 * @since 2016.06.20
 */
@Service("apprDocService")
public class ApprDocServiceImpl extends EgovAbstractServiceImpl implements ApprDocService {

    @Resource(name = "apprDocDAO")
    private ApprDocDAO apprDocDAO;

    @Resource(name = "apprDocIdGnrService")
    private EgovIdGnrService idgen;

    @Resource(name = "apprHistService")
    private ApprHistService apprHistService;

    @Override
    public List<EgovMap> selectDocList(ApprDocVO vo) throws Exception {
        return apprDocDAO.selectDocList(vo);
    }

    @Override
    public int selectDocListCnt(ApprDocVO vo) throws Exception {
        return apprDocDAO.selectDocListCnt(vo);
    }

    @Override
    public ApprDocVO selectDoc(String docId) throws Exception {
        return apprDocDAO.selectDoc(docId);
    }

    @Override
    public List<EgovMap> selectSanctnLineList(String docId) throws Exception {
        return apprDocDAO.selectSanctnLineList(docId);
    }

    @Override
    public String insertDraft(ApprDocVO vo) throws Exception {
        if (vo.getSanctnerIds() == null || vo.getSanctnerIds().length == 0) {
            throw new BizException("appr.line.empty");
        }
        vo.setDocId(idgen.getNextStringId());
        vo.setSanctnSttus("ING");
        vo.setCurSanctnOrdr(1);
        int last = 0;
        for (int i = 0; i < vo.getSanctnerIds().length; i++) {
            if (!"REFR".equals(vo.getSanctnTys()[i])) {
                last = i + 1;
            }
        }
        vo.setLastSanctnOrdr(last);
        apprDocDAO.insertDoc(vo);

        for (int i = 0; i < vo.getSanctnerIds().length; i++) {
            Map<String, Object> line = new HashMap<String, Object>();
            line.put("docId", vo.getDocId());
            line.put("sanctnOrdr", i + 1);
            line.put("sanctnerId", vo.getSanctnerIds()[i]);
            line.put("sanctnTy", vo.getSanctnTys()[i]);
            line.put("sanctnResult", "REFR".equals(vo.getSanctnTys()[i]) ? "REFR" : "WAIT");
            apprDocDAO.insertSanctnLine(line);
        }
        apprHistService.insertHist(vo.getDocId(), 0, vo.getDrafterId(), "DRFT", null);
        return vo.getDocId();
    }

    @Override
    public void approve(ApprDocVO vo) throws Exception {
        ApprDocVO doc = apprDocDAO.selectDoc(vo.getDocId());
        EgovMap cur = apprDocDAO.selectCurLine(doc);
        if (cur == null || !vo.getLoginId().equals(cur.get("sanctnerId"))) {
            throw new BizException("fail.common.auth");
        }
        Map<String, Object> p = new HashMap<String, Object>();
        p.put("docId", vo.getDocId());
        p.put("sanctnOrdr", doc.getCurSanctnOrdr());
        p.put("sanctnResult", "OK");
        p.put("sanctnOpinion", vo.getSanctnOpinion());
        apprDocDAO.updateSanctnLine(p);

        // 다음 결재자(참조 건너뜀) 또는 완결
        int next = apprDocDAO.selectNextOrdr(p);
        if (next == 0 || doc.getCurSanctnOrdr() >= doc.getLastSanctnOrdr()) {
            doc.setSanctnSttus("CMPL");
        } else {
            doc.setCurSanctnOrdr(next);
        }
        apprDocDAO.updateDocSttus(doc);
        apprHistService.insertHist(vo.getDocId(), (Integer) p.get("sanctnOrdr"), vo.getLoginId(), "OK", vo.getSanctnOpinion());
    }

    @Override
    public void reject(ApprDocVO vo) throws Exception {
        if (vo.getSanctnOpinion() == null || vo.getSanctnOpinion().trim().isEmpty()) {
            throw new BizException("appr.rjct.opinion");
        }
        ApprDocVO doc = apprDocDAO.selectDoc(vo.getDocId());
        Map<String, Object> p = new HashMap<String, Object>();
        p.put("docId", vo.getDocId());
        p.put("sanctnOrdr", doc.getCurSanctnOrdr());
        p.put("sanctnResult", "RJCT");
        p.put("sanctnOpinion", vo.getSanctnOpinion());
        apprDocDAO.updateSanctnLine(p);
        doc.setSanctnSttus("RJCT");
        apprDocDAO.updateDocSttus(doc);
        apprHistService.insertHist(vo.getDocId(), doc.getCurSanctnOrdr(), vo.getLoginId(), "RJCT", vo.getSanctnOpinion());
    }

}
