package egov.portal.refund.req.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egov.portal.cmm.exception.BizException;
import egov.portal.cmm.util.PortalStringUtil;
import egov.portal.refund.req.service.impl.RefundReqMapper;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * 환불 신청 (입금전용계좌 결제 취소분 / PG 취소 불가 건)
 *
 * @author jdh
 * @since 2019.10.01
 */
@Service("refundReqService")
public class RefundReqService extends EgovAbstractServiceImpl {

    @Resource(name = "refundReqMapper")
    private RefundReqMapper refundReqMapper;

    @Resource(name = "propertiesService")
    private EgovPropertyService propertiesService;

    public EgovMap selectRefundTarget(Map<String, Object> p) throws Exception {
        EgovMap t = refundReqMapper.selectRefundTarget(p);
        if (t != null) {
            long amt = ((Number) t.get("refundPosblAmt")).longValue();
            long fee = amt * propertiesService.getInt("refund.feeRate") / 100;
            t.put("feeAmt", fee);
            t.put("expectAmt", amt - fee);
        }
        return t;
    }

    public void insertRefundReq(Map<String, Object> p) throws Exception {
        if (refundReqMapper.selectReqDupCnt((String) p.get("stlmId")) > 0) {
            throw new BizException("refund.req.dup");
        }
        String acnt = PortalStringUtil.removeHyphen((String) p.get("acntNo"));
        if (acnt == null || !acnt.matches("\\d{10,16}")) {
            throw new BizException("refund.acnt.invalid");
        }
        p.put("acntNo", acnt);
        p.put("reqSttus", "REQ");
        refundReqMapper.insertRefundReq(p);
    }

}
