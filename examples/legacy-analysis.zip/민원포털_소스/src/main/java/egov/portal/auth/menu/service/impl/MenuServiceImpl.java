package egov.portal.auth.menu.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egov.portal.auth.menu.service.MenuService;
import egov.portal.auth.menu.service.MenuVO;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Service("menuService")
public class MenuServiceImpl extends EgovAbstractServiceImpl implements MenuService {

    @Resource(name = "menuDAO")
    private MenuDAO menuDAO;

    @Override
    public List<MenuVO> selectAuthorMenuList(String authorCode) throws Exception {
        return menuDAO.selectAuthorMenuList(authorCode);
    }

    @Override
    public List<EgovMap> selectMenuTree() throws Exception {
        return menuDAO.selectMenuTree(null);
    }

    @Override
    public MenuVO selectMenu(int menuNo) throws Exception {
        return menuDAO.selectMenu(menuNo);
    }

    @Override
    public void saveMenu(MenuVO vo) throws Exception {
        if (vo.getMenuNo() == 0) {
            menuDAO.insertMenu(vo);
        } else {
            menuDAO.updateMenu(vo);
        }
    }

}
