package egov.portal.assign.conf.service.impl;

import java.util.List;
import java.util.Map;

import egov.portal.assign.conf.service.AssignConfVO;

import egovframework.rte.psl.dataaccess.mapper.Mapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * 배정 설정 매퍼
 *
 * @author jdh
 * @since 2019.11.04
 */
@Mapper("assignConfMapper")
public interface AssignConfMapper {

    List<EgovMap> selectDeptChargerList(String deptCd) throws Exception;
    EgovMap selectNextCharger(Map<String, Object> param) throws Exception;
    void insertAsgnHist(Map<String, Object> param) throws Exception;
    int updateLastAsgnDt(Map<String, Object> param) throws Exception;
    void mergeCharger(AssignConfVO vo) throws Exception;
    int updateAsgnYn(AssignConfVO vo) throws Exception;
    int updateAsgnOrdr(AssignConfVO vo) throws Exception;
    List<EgovMap> selectAsgnSttusByDept() throws Exception;

}
