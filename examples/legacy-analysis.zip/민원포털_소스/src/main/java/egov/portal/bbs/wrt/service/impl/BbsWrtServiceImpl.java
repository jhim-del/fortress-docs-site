package egov.portal.bbs.wrt.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egov.portal.bbs.inq.service.BbsNttVO;
import egov.portal.bbs.wrt.service.BbsWrtService;
import egov.portal.cmm.exception.BizException;
import egov.portal.cmm.file.service.FileMngService;
import egov.portal.cmm.file.service.FileVO;
import egov.portal.cmm.util.PortalScrty;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 게시물 등록 구현
 * @author lsy
 * @since 2016.04.28
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2016.04.28  lsy       최초 생성
 *   2016.06.13  lsy       답글 정렬 수정
 *   2019.10.28  sbk       비밀글
 * </pre>
 */
@Service("bbsWrtService")
public class BbsWrtServiceImpl extends EgovAbstractServiceImpl implements BbsWrtService {

    @Resource(name = "bbsWrtDAO")
    private BbsWrtDAO bbsWrtDAO;

    @Resource(name = "fileMngService")
    private FileMngService fileMngService;

    public void insertNtt(BbsNttVO vo, List<FileVO> files) throws Exception {
        if (files != null && !files.isEmpty()) {
            vo.setAtchFileId(fileMngService.insertFiles(files));
        }
        if (vo.getPassword() != null && vo.getPassword().length() > 0) {
            vo.setPassword(PortalScrty.encryptPassword(vo.getPassword(), vo.getBbsId()));
        }
        vo.setNttId(bbsWrtDAO.selectNextNttId(vo));
        vo.setNttNo(1);
        vo.setAnswerAt("N");
        vo.setAnswerLc(0);
        bbsWrtDAO.insertNtt(vo);
    }

    /**
     * 답글: 부모글과 같은 SORT_ORDR 묶음 안에서 부모 바로 아래에 오도록 NTT_NO 를 밀어낸다.
     */
    public void insertReply(BbsNttVO vo, List<FileVO> files) throws Exception {
        BbsNttVO parent = bbsWrtDAO.selectParent(vo);
        if (parent == null) {
            throw new BizException("info.nodata.msg");
        }
        bbsWrtDAO.updateNttNoShift(parent);

        if (files != null && !files.isEmpty()) {
            vo.setAtchFileId(fileMngService.insertFiles(files));
        }
        vo.setNttId(bbsWrtDAO.selectNextNttId(vo));
        vo.setParntscttNo(Long.parseLong(parent.getNttId()));
        vo.setSortOrdr(parent.getSortOrdr());
        vo.setNttNo(parent.getNttNo() + 1);
        vo.setAnswerAt("Y");
        vo.setAnswerLc(parent.getAnswerLc() + 1);
        vo.setSecretAt(parent.getSecretAt());
        bbsWrtDAO.insertNtt(vo);
    }

    public void updateNtt(BbsNttVO vo, List<FileVO> files) throws Exception {
        if (files != null && !files.isEmpty()) {
            if (vo.getAtchFileId() == null || vo.getAtchFileId().length() == 0) {
                vo.setAtchFileId(fileMngService.insertFiles(files));
            } else {
                fileMngService.addFiles(vo.getAtchFileId(), files);
            }
        }
        bbsWrtDAO.updateNtt(vo);
    }

    public void deleteNtt(BbsNttVO vo) throws Exception {
        bbsWrtDAO.deleteNtt(vo);
    }

}
