package egov.portal.cmm.util;

import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @Class Name : PortalProperties.java
 * @Description : globals.properties 조회
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.03.21      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.03.21
 */
public class PortalProperties {

    private static final Logger LOGGER = LoggerFactory.getLogger(PortalProperties.class);
    private static final String GLOBALS = "/egovframework/egovProps/globals.properties";
    private static Properties props;

    static {
        props = new Properties();
        try (InputStream in = PortalProperties.class.getResourceAsStream(GLOBALS)) {
            props.load(new java.io.InputStreamReader(in, "UTF-8"));
        } catch (Exception e) {
            LOGGER.error("globals.properties 로드 실패", e);
        }
    }

    public static String getProperty(String key) {
        String v = props.getProperty(key);
        return v == null ? "" : v.trim();
    }

    public static int getInt(String key, int dflt) {
        try {
            return Integer.parseInt(getProperty(key));
        } catch (NumberFormatException e) {
            return dflt;
        }
    }
}
