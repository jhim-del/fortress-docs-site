package egov.portal.appr.hist.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Repository("apprHistDAO")
public class ApprHistDAO extends EgovAbstractMapper {

    public void insertHist(Map<String, Object> p) throws Exception {
        insert("apprHistDAO.insertHist", p);
    }

    public List<EgovMap> selectHistList(Map<String, Object> p) throws Exception {
        return selectList("apprHistDAO.selectHistList", p);
    }

    public int selectHistListCnt(Map<String, Object> p) throws Exception {
        return (Integer) selectOne("apprHistDAO.selectHistListCnt", p);
    }

    public List<EgovMap> selectUnsentList() throws Exception {
        return selectList("apprHistDAO.selectUnsentList");
    }

    public void updateSent(EgovMap h) throws Exception {
        update("apprHistDAO.updateSent", h);
    }
}
