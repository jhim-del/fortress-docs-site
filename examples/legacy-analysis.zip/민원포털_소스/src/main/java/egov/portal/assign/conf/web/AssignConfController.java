package egov.portal.assign.conf.web;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import egov.portal.assign.conf.service.AssignConfService;
import egov.portal.assign.conf.service.AssignConfVO;
import egov.portal.cmm.LoginVO;

/**
 * 담당자 배정 설정 (관리자)
 *
 * @author jdh
 * @since 2019.11.04
 */
@Controller
@RequestMapping("/mng/assign/conf")
public class AssignConfController {

    @Resource(name = "assignConfService")
    private AssignConfService assignConfService;

    @GetMapping("/confList.do")
    public String confList(@RequestParam(value = "deptCd", required = false) String deptCd, Model model) throws Exception {
        model.addAttribute("deptSttusList", assignConfService.selectAsgnSttusByDept());
        if (deptCd != null) {
            model.addAttribute("deptCd", deptCd);
            model.addAttribute("chargerList", assignConfService.selectChargerList(deptCd));
        }
        return "mng/assign/confList";
    }

    @PostMapping("/saveCharger.do")
    @ResponseBody
    public Map<String, Object> saveCharger(AssignConfVO vo, HttpSession session) throws Exception {
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        vo.setRegId(user.getId());
        vo.setModId(user.getId());
        vo.setAsgnYn("Y");
        assignConfService.saveCharger(vo);
        return result(true, null);
    }

    @PostMapping("/toggleAsgn.do")
    @ResponseBody
    public Map<String, Object> toggleAsgn(AssignConfVO vo, HttpSession session) throws Exception {
        vo.setModId(((LoginVO) session.getAttribute("loginVO")).getId());
        assignConfService.changeAsgnYn(vo);
        return result(true, null);
    }

    @PostMapping("/saveOrdr.do")
    @ResponseBody
    public Map<String, Object> saveOrdr(@RequestBody List<AssignConfVO> list, HttpSession session) throws Exception {
        String id = ((LoginVO) session.getAttribute("loginVO")).getId();
        for (AssignConfVO vo : list) {
            vo.setModId(id);
        }
        assignConfService.changeOrdr(list);
        return result(true, null);
    }

    private Map<String, Object> result(boolean ok, String msg) {
        Map<String, Object> m = new HashMap<String, Object>();
        m.put("success", ok);
        m.put("message", msg);
        return m;
    }
}
