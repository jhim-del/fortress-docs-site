package egov.portal.appr.doc.service;

import java.io.Serializable;
import egov.portal.cmm.ComDefaultVO;

/**
 * @Class Name : ApprDocVO.java
 * @Description : 결재 문서 VO
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.06.20      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.06.20
 */
public class ApprDocVO extends ComDefaultVO {

    private static final long serialVersionUID = 481289788812378741L;

    /** 문서ID */
    private String docId;
    /** 제목 */
    private String docSj;
    /** 본문 */
    private String docCn;
    /** 문서구분 */
    private String docSeCode;
    /** 기안자 */
    private String drafterId;
    /** 기안자명 */
    private String drafterNm;
    /** 기안부서 */
    private String draftDeptCode;
    /** 기안일시 */
    private String draftPnttm;
    /** 결재상태(DRFT/ING/CMPL/RJCT) */
    private String sanctnSttus;
    /** 현재 결재순번 */
    private int curSanctnOrdr;
    /** 최종 결재순번 */
    private int lastSanctnOrdr;
    /** 관련업무 */
    private String relBizSe;
    /** 관련업무키 */
    private String relBizKey;
    /** 첨부 */
    private String atchFileId;
    /** 결재선(순서대로) */
    private String[] sanctnerIds;
    /** 결재유형 */
    private String[] sanctnTys;
    /** 결재의견 */
    private String sanctnOpinion;
    /** 처리자 */
    private String loginId;
    /** 목록구분(TODO/DRAFT/DONE) */
    private String searchBox;

    public String getDocId() { return docId; }
    public void setDocId(String docId) { this.docId = docId; }
    public String getDocSj() { return docSj; }
    public void setDocSj(String docSj) { this.docSj = docSj; }
    public String getDocCn() { return docCn; }
    public void setDocCn(String docCn) { this.docCn = docCn; }
    public String getDocSeCode() { return docSeCode; }
    public void setDocSeCode(String docSeCode) { this.docSeCode = docSeCode; }
    public String getDrafterId() { return drafterId; }
    public void setDrafterId(String drafterId) { this.drafterId = drafterId; }
    public String getDrafterNm() { return drafterNm; }
    public void setDrafterNm(String drafterNm) { this.drafterNm = drafterNm; }
    public String getDraftDeptCode() { return draftDeptCode; }
    public void setDraftDeptCode(String draftDeptCode) { this.draftDeptCode = draftDeptCode; }
    public String getDraftPnttm() { return draftPnttm; }
    public void setDraftPnttm(String draftPnttm) { this.draftPnttm = draftPnttm; }
    public String getSanctnSttus() { return sanctnSttus; }
    public void setSanctnSttus(String sanctnSttus) { this.sanctnSttus = sanctnSttus; }
    public int getCurSanctnOrdr() { return curSanctnOrdr; }
    public void setCurSanctnOrdr(int curSanctnOrdr) { this.curSanctnOrdr = curSanctnOrdr; }
    public int getLastSanctnOrdr() { return lastSanctnOrdr; }
    public void setLastSanctnOrdr(int lastSanctnOrdr) { this.lastSanctnOrdr = lastSanctnOrdr; }
    public String getRelBizSe() { return relBizSe; }
    public void setRelBizSe(String relBizSe) { this.relBizSe = relBizSe; }
    public String getRelBizKey() { return relBizKey; }
    public void setRelBizKey(String relBizKey) { this.relBizKey = relBizKey; }
    public String getAtchFileId() { return atchFileId; }
    public void setAtchFileId(String atchFileId) { this.atchFileId = atchFileId; }
    public String[] getSanctnerIds() { return sanctnerIds; }
    public void setSanctnerIds(String[] sanctnerIds) { this.sanctnerIds = sanctnerIds; }
    public String[] getSanctnTys() { return sanctnTys; }
    public void setSanctnTys(String[] sanctnTys) { this.sanctnTys = sanctnTys; }
    public String getSanctnOpinion() { return sanctnOpinion; }
    public void setSanctnOpinion(String sanctnOpinion) { this.sanctnOpinion = sanctnOpinion; }
    public String getLoginId() { return loginId; }
    public void setLoginId(String loginId) { this.loginId = loginId; }
    public String getSearchBox() { return searchBox; }
    public void setSearchBox(String searchBox) { this.searchBox = searchBox; }
}
