package egov.portal.cmm.file.service;

import java.io.Serializable;

/**
 * @Class Name : FileVO.java
 * @Description : 첨부파일 VO
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.03.28      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.03.28
 */
public class FileVO implements Serializable {

    private static final long serialVersionUID = 430322042329406295L;

    /** 첨부파일 아이디 */
    private String atchFileId;
    /** 파일연번 */
    private String fileSn;
    /** 파일저장경로 */
    private String fileStreCours;
    /** 저장파일명 */
    private String streFileNm;
    /** 원파일명 */
    private String orignlFileNm;
    /** 파일확장자 */
    private String fileExtsn;
    /** 파일내용 */
    private String fileCn;
    /** 파일크기 */
    private long fileMg;
    /** 생성일자 */
    private String creatDt;

    public String getAtchFileId() { return atchFileId; }
    public void setAtchFileId(String atchFileId) { this.atchFileId = atchFileId; }
    public String getFileSn() { return fileSn; }
    public void setFileSn(String fileSn) { this.fileSn = fileSn; }
    public String getFileStreCours() { return fileStreCours; }
    public void setFileStreCours(String fileStreCours) { this.fileStreCours = fileStreCours; }
    public String getStreFileNm() { return streFileNm; }
    public void setStreFileNm(String streFileNm) { this.streFileNm = streFileNm; }
    public String getOrignlFileNm() { return orignlFileNm; }
    public void setOrignlFileNm(String orignlFileNm) { this.orignlFileNm = orignlFileNm; }
    public String getFileExtsn() { return fileExtsn; }
    public void setFileExtsn(String fileExtsn) { this.fileExtsn = fileExtsn; }
    public String getFileCn() { return fileCn; }
    public void setFileCn(String fileCn) { this.fileCn = fileCn; }
    public long getFileMg() { return fileMg; }
    public void setFileMg(long fileMg) { this.fileMg = fileMg; }
    public String getCreatDt() { return creatDt; }
    public void setCreatDt(String creatDt) { this.creatDt = creatDt; }
}
