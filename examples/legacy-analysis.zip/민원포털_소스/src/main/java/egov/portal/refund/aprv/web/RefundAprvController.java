package egov.portal.refund.aprv.web;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egov.portal.cmm.LoginVO;
import egov.portal.cmm.util.MaskingUtil;
import egov.portal.cmm.util.PagingHelper;
import egov.portal.refund.aprv.service.RefundAprvService;
import egov.portal.refund.aprv.service.RefundAprvVO;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/**
 * 환불 승인 (관리자)
 *
 * @author jdh
 * @since 2019.10.01
 */
@Controller
@RequestMapping("/mng/refund/aprv")
public class RefundAprvController {

    @Resource(name = "refundAprvService")
    private RefundAprvService refundAprvService;

    @RequestMapping("/aprvList.do")
    public String aprvList(@ModelAttribute("searchVO") RefundAprvVO searchVO, Model model) throws Exception {
        if (searchVO.getSchSttus() == null) {
            searchVO.setSchSttus("REQ");
        }
        PaginationInfo pi = PagingHelper.of(searchVO, 20);
        int tot = refundAprvService.selectAprvListCnt(searchVO);
        pi.setTotalRecordCount(tot);
        model.addAttribute("resultList", refundAprvService.selectAprvList(searchVO));
        model.addAttribute("paginationInfo", pi);
        model.addAttribute("totCnt", tot);
        return "mng/refund/aprvList";
    }

    @GetMapping("/aprvView.do")
    public String aprvView(@RequestParam("refundSeq") Long refundSeq, Model model) throws Exception {
        RefundAprvVO vo = refundAprvService.selectRefundDetail(refundSeq);
        model.addAttribute("result", vo);
        model.addAttribute("acntMask", MaskingUtil.account(vo.getAcntNo()));
        return "mng/refund/aprvView";
    }

    @PostMapping("/approve.do")
    public String approve(RefundAprvVO vo, HttpSession session) throws Exception {
        vo.setAprvId(((LoginVO) session.getAttribute("loginVO")).getId());
        refundAprvService.approve(vo);
        return "redirect:/mng/refund/aprv/aprvView.do?refundSeq=" + vo.getRefundSeq();
    }

    @PostMapping("/reject.do")
    public String reject(RefundAprvVO vo, HttpSession session) throws Exception {
        vo.setAprvId(((LoginVO) session.getAttribute("loginVO")).getId());
        refundAprvService.reject(vo);
        return "redirect:/mng/refund/aprv/aprvList.do";
    }

    /** 이체 목록 엑셀 (회계 담당 전달용) */
    @GetMapping("/transferExcel.do")
    public String transferExcel(Model model) throws Exception {
        model.addAttribute("excelFileName", "환불이체목록");
        model.addAttribute("excelHeader", new String[] {"순번", "은행", "계좌번호", "예금주", "환불액"});
        model.addAttribute("excelKeys", new String[] {"refundSeq", "bankNm", "acntNo", "dpstrNm", "refundAmt"});
        model.addAttribute("excelList", refundAprvService.selectAprvTransferList());
        return "excelDownView";
    }
}
