package egov.portal.appr.hist.service;

import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import egov.portal.appr.hist.service.impl.ApprHistDAO;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * 결재 이력
 * @author lsy
 * @since 2016.06.22
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2016.06.22  lsy       최초 생성
 *   2016.10.10  lsy       구 전자결재 서버 동기화
 *   2018.11.05  hjy       신 결재 전환, 이력 기록 일원화
 * </pre>
 */
@Service("apprHistService")
public class ApprHistService extends EgovAbstractServiceImpl {

    private static final Logger LOGGER = LoggerFactory.getLogger(ApprHistService.class);

    @Resource(name = "apprHistDAO")
    private ApprHistDAO apprHistDAO;

    public void insertHist(String docId, int sanctnOrdr, String userId, String act, String opinion) throws Exception {
        Map<String, Object> p = new HashMap<String, Object>();
        p.put("docId", docId);
        p.put("sanctnOrdr", sanctnOrdr);
        p.put("userId", userId);
        p.put("act", act);
        p.put("opinion", opinion);
        apprHistDAO.insertHist(p);
    }

    public List<EgovMap> selectHistList(Map<String, Object> p) throws Exception {
        return apprHistDAO.selectHistList(p);
    }

    public int selectHistListCnt(Map<String, Object> p) throws Exception {
        return apprHistDAO.selectHistListCnt(p);
    }

    /**
     * @deprecated 2018 구 전자결재 연동. 신 결재 시스템 전환으로 호출처 없음
     * 구 전자결재 서버(10.1.3.20)에 미전송 결재 이력을 보낸다.
     */
    @Deprecated
    public void legacySync() {
        try {
            List<EgovMap> list = apprHistDAO.selectUnsentList();
            for (EgovMap h : list) {
                URL url = new URL("http://10.1.3.20:7001/approval/ws/sanctnHist");
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("POST");
                con.setDoOutput(true);
                con.setConnectTimeout(3000);
                try (OutputStreamWriter out = new OutputStreamWriter(con.getOutputStream(), "EUC-KR")) {
                    out.write("docId=" + h.get("docId") + "&ordr=" + h.get("sanctnOrdr") + "&act=" + h.get("act") + "&user=" + h.get("userId"));
                }
                if (con.getResponseCode() == 200) {
                    apprHistDAO.updateSent(h);
                }
            }
        } catch (Exception e) {
            LOGGER.error("구 전자결재 동기화 실패", e);
        }
    }
}
