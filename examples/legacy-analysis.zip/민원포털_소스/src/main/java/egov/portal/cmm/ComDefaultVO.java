package egov.portal.cmm;

import java.io.Serializable;

/**
 * @Class Name : ComDefaultVO.java
 * @Description : 공통 검색·페이징 VO
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.03.21      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.03.21
 */
public class ComDefaultVO implements Serializable {

    private static final long serialVersionUID = 310285064377789954L;

    /** 검색조건 */
    private String searchCondition = "";
    /** 검색Keyword */
    private String searchKeyword = "";
    /** 검색사용여부 */
    private String searchUseYn = "";
    /** 현재페이지 */
    private int pageIndex = 1;
    /** 페이지갯수 */
    private int pageUnit = 10;
    /** 페이지사이즈 */
    private int pageSize = 10;
    /** firstIndex */
    private int firstIndex = 1;
    /** lastIndex */
    private int lastIndex = 1;
    /** recordCountPerPage */
    private int recordCountPerPage = 10;
    /** 검색시작일 */
    private String searchBgnDe = "";
    /** 검색종료일 */
    private String searchEndDe = "";

    public String getSearchCondition() { return searchCondition; }
    public void setSearchCondition(String searchCondition) { this.searchCondition = searchCondition; }
    public String getSearchKeyword() { return searchKeyword; }
    public void setSearchKeyword(String searchKeyword) { this.searchKeyword = searchKeyword; }
    public String getSearchUseYn() { return searchUseYn; }
    public void setSearchUseYn(String searchUseYn) { this.searchUseYn = searchUseYn; }
    public int getPageIndex() { return pageIndex; }
    public void setPageIndex(int pageIndex) { this.pageIndex = pageIndex; }
    public int getPageUnit() { return pageUnit; }
    public void setPageUnit(int pageUnit) { this.pageUnit = pageUnit; }
    public int getPageSize() { return pageSize; }
    public void setPageSize(int pageSize) { this.pageSize = pageSize; }
    public int getFirstIndex() { return firstIndex; }
    public void setFirstIndex(int firstIndex) { this.firstIndex = firstIndex; }
    public int getLastIndex() { return lastIndex; }
    public void setLastIndex(int lastIndex) { this.lastIndex = lastIndex; }
    public int getRecordCountPerPage() { return recordCountPerPage; }
    public void setRecordCountPerPage(int recordCountPerPage) { this.recordCountPerPage = recordCountPerPage; }
    public String getSearchBgnDe() { return searchBgnDe; }
    public void setSearchBgnDe(String searchBgnDe) { this.searchBgnDe = searchBgnDe; }
    public String getSearchEndDe() { return searchEndDe; }
    public void setSearchEndDe(String searchEndDe) { this.searchEndDe = searchEndDe; }
}
