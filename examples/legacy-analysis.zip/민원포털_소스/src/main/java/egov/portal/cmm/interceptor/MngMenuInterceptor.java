package egov.portal.cmm.interceptor;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import egov.portal.auth.menu.service.MenuService;
import egov.portal.auth.menu.service.MenuVO;
import egov.portal.cmm.LoginVO;

/**
 * 관리자 화면 좌측 메뉴 세팅 + URL 권한 확인
 * <p>
 * 메뉴 목록은 권한코드별로 세션에 1회만 적재한다.
 *
 * @author ywk
 * @since 2019.07.22
 */
public class MngMenuInterceptor extends HandlerInterceptorAdapter {

    @Resource(name = "menuService")
    private MenuService menuService;

    @Override
    public boolean preHandle(HttpServletRequest req, HttpServletResponse res, Object handler) throws Exception {
        LoginVO user = (LoginVO) req.getSession().getAttribute("loginVO");
        if (user == null) {
            return true; // AuthenticInterceptor 에서 처리
        }

        @SuppressWarnings("unchecked")
        List<MenuVO> menus = (List<MenuVO>) req.getSession().getAttribute("mngMenuList");
        if (menus == null) {
            menus = menuService.selectAuthorMenuList(user.getAuthorCode());
            req.getSession().setAttribute("mngMenuList", menus);
        }

        String uri = req.getRequestURI().substring(req.getContextPath().length());
        // 목록 화면 URL 만 메뉴에 등록되어 있어 업무 폴더 단위로 비교
        String dir = uri.substring(0, uri.lastIndexOf('/') + 1);
        for (MenuVO m : menus) {
            if (m.getMenuUrl() != null && m.getMenuUrl().startsWith(dir)) {
                req.setAttribute("curMenuNo", m.getMenuNo());
                return true;
            }
        }
        if ("ROLE_ADMIN".equals(user.getAuthorCode())) {
            return true;
        }
        res.sendRedirect(req.getContextPath() + "/mng/main.do?err=auth");
        return false;
    }
}
