package egov.portal.mbr.cert.web;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egov.portal.cmm.util.PortalProperties;
import egov.portal.mbr.cert.module.CertCryptoWrapper;

/**
 * 휴대폰 본인확인 연계 (본인확인기관 모듈)
 * @author lsy
 * @since 2016.05.24
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2016.05.24  lsy       최초 생성
 *   2016.05.30  lsy       요청번호 세션 검증
 * </pre>
 */
@Controller
public class CertLinkController {

    private static final Logger LOGGER = LoggerFactory.getLogger(CertLinkController.class);

    @Resource(name = "certCryptoWrapper")
    private CertCryptoWrapper certCrypto;

    @RequestMapping("/mbr/cert/certReq.do")
    public String certReq(HttpServletRequest request, HttpSession session, ModelMap model) throws Exception {
        String reqSeq = certCrypto.newRequestNo();
        session.setAttribute("CERT_REQ_SEQ", reqSeq);

        String base = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath();
        String plain = "7:REQ_SEQ" + reqSeq.length() + ":" + reqSeq
                + "8:SITECODE" + PortalProperties.getProperty("cert.siteCode").length() + ":" + PortalProperties.getProperty("cert.siteCode")
                + "9:AUTH_TYPE1:M"
                + "7:RTN_URL" + (base + PortalProperties.getProperty("cert.returnUrl")).length() + ":" + base + PortalProperties.getProperty("cert.returnUrl")
                + "7:ERR_URL" + (base + PortalProperties.getProperty("cert.errorUrl")).length() + ":" + base + PortalProperties.getProperty("cert.errorUrl");
        model.addAttribute("encData", certCrypto.encrypt(plain));
        model.addAttribute("certFormUrl", PortalProperties.getProperty("cert.formUrl"));
        return "portal/mbr/certPop";
    }

    @RequestMapping("/mbr/cert/certReturn.do")
    public String certReturn(@RequestParam("EncodeData") String encodeData, HttpSession session, ModelMap model) throws Exception {
        Map<String, String> r = certCrypto.decrypt(encodeData);
        String reqSeq = (String) session.getAttribute("CERT_REQ_SEQ");
        if (r == null || reqSeq == null || !reqSeq.equals(r.get("REQ_SEQ"))) {
            LOGGER.warn("본인확인 요청번호 불일치");
            model.addAttribute("result", "FAIL");
            return "portal/mbr/certReturn";
        }
        java.util.HashMap<String, String> info = new java.util.HashMap<String, String>();
        info.put("name", r.get("UTF8_NAME"));
        info.put("birthDate", r.get("BIRTHDATE"));
        info.put("gender", "1".equals(r.get("GENDER")) ? "M" : "F");
        info.put("mobileNo", r.get("MOBILE_NO"));
        info.put("ci", r.get("CI"));
        info.put("di", r.get("DI"));
        session.setAttribute("certInfo", info);
        session.removeAttribute("CERT_REQ_SEQ");
        model.addAttribute("result", "OK");
        return "portal/mbr/certReturn";
    }

    @RequestMapping("/mbr/cert/certFail.do")
    public String certFail(ModelMap model) {
        model.addAttribute("result", "FAIL");
        return "portal/mbr/certReturn";
    }
}
