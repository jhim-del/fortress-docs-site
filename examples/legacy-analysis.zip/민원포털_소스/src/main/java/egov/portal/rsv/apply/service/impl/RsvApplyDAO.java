package egov.portal.rsv.apply.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import egov.portal.rsv.apply.service.RsvApplyVO;
import egov.portal.rsv.fac.service.FacVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * 시설 예약 DAO
 * @author lsy
 * @since 2016.05.20
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2016.05.20  lsy       최초 생성
 * </pre>
 */
@Repository("rsvApplyDAO")
public class RsvApplyDAO extends EgovAbstractMapper {

    /** 월별 일자 예약 현황 */
    public List<EgovMap> selectMonthResveSttus(RsvApplyVO vo) throws Exception {
        return selectList("rsvApplyDAO.selectMonthResveSttus", vo);
    }

    /** 일자 예약 목록 */
    public List<EgovMap> selectDayResveList(RsvApplyVO vo) throws Exception {
        return selectList("rsvApplyDAO.selectDayResveList", vo);
    }

    /** 시설 행 잠금 */
    public FacVO selectFacForUpdate(String vo) throws Exception {
        return (FacVO) selectOne("rsvApplyDAO.selectFacForUpdate", vo);
    }

    /** 시간 겹침 건수 */
    public int selectDupResveCnt(RsvApplyVO vo) throws Exception {
        return (Integer) selectOne("rsvApplyDAO.selectDupResveCnt", vo);
    }

    /** 예약 등록 */
    public void insertResve(RsvApplyVO vo) throws Exception {
        insert("rsvApplyDAO.insertResve", vo);
    }

    /** 예약 1건 */
    public RsvApplyVO selectResve(RsvApplyVO vo) throws Exception {
        return (RsvApplyVO) selectOne("rsvApplyDAO.selectResve", vo);
    }

    /** 나의 예약 */
    public List<EgovMap> selectMyResveList(RsvApplyVO vo) throws Exception {
        return selectList("rsvApplyDAO.selectMyResveList", vo);
    }

    /** 취소 */
    public int updateCancel(RsvApplyVO vo) throws Exception {
        return update("rsvApplyDAO.updateCancel", vo);
    }

    /** 결제 결과 반영 */
    public int updatePayResult(Map<String, Object> vo) throws Exception {
        return update("rsvApplyDAO.updatePayResult", vo);
    }

}
