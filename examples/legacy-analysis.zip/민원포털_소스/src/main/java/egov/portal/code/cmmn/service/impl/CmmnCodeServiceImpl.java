package egov.portal.code.cmmn.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egov.portal.code.cmmn.service.CmmnCodeService;
import egov.portal.code.cmmn.service.CmmnCodeVO;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : CmmnCodeServiceImpl.java
 * @Description : 공통코드 관리 구현
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.03.25      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.03.25
 */
@Service("cmmnCodeService")
public class CmmnCodeServiceImpl extends EgovAbstractServiceImpl implements CmmnCodeService {

    @Resource(name = "cmmnCodeDAO")
    private CmmnCodeDAO cmmnCodeDAO;

    @Override
    public List<EgovMap> selectCodeIdList(CmmnCodeVO vo) throws Exception {
        return cmmnCodeDAO.selectCodeIdList(vo);
    }

    @Override
    public List<EgovMap> selectCodeDetailList(String codeId) throws Exception {
        return cmmnCodeDAO.selectCodeDetailList(codeId);
    }

    @Override
    public void saveCodeId(CmmnCodeVO vo) throws Exception {
        if (cmmnCodeDAO.updateCodeId(vo) == 0) {
            cmmnCodeDAO.insertCodeId(vo);
        }
    }

    /** 상세코드: 이미 쓰고 있는 코드는 삭제 대신 사용여부 N */
    @Override
    public void saveCodeDetail(CmmnCodeVO vo) throws Exception {
        if (cmmnCodeDAO.updateCodeDetail(vo) == 0) {
            cmmnCodeDAO.insertCodeDetail(vo);
        }
    }
}
