package egov.portal.stat.daily.service.impl;

import java.util.Map;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

/**
 * 일 통계 집계 DAO
 * @author pms
 * @since 2016.07.04
 */
@Repository("statDailyDAO")
public class StatDailyDAO extends EgovAbstractMapper {

    public void deleteCivilStat(Map<String, Object> p) {
        delete("statDailyDAO.deleteCivilStat", p);
    }

    public int insertCivilStat(Map<String, Object> p) {
        return insert("statDailyDAO.insertCivilStat", p);
    }

    public void deleteRsvStat(Map<String, Object> p) {
        delete("statDailyDAO.deleteRsvStat", p);
    }

    public int insertRsvStat(Map<String, Object> p) {
        return insert("statDailyDAO.insertRsvStat", p);
    }

    public void insertBatchLog(Map<String, Object> p) {
        insert("statDailyDAO.insertBatchLog", p);
    }
}
