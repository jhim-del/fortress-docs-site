package egov.portal.cmm.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : CmmUseService.java
 * @Description : 공통코드·휴일 조회 (화면 select 박스, 기한 계산용)
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.03.25      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.03.25
 */
public interface CmmUseService {

    /** 공통코드 상세 목록 */
    List<EgovMap> selectCmmCodeDetail(String codeId) throws Exception;

    /** 기간 내 공휴일(yyyyMMdd) 집합 */
    java.util.Set<String> selectRestdeSet(String bgnde, String endde) throws Exception;

    /** 부서 목록(인사 연계 테이블) */
    List<EgovMap> selectDeptList() throws Exception;

    /** 재직 직원 목록 (결재자 선택 등) */
    List<EgovMap> selectEmplList(String deptCode) throws Exception;
}
