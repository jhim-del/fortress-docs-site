package egov.portal.bbs.inq.web;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import egov.portal.bbs.inq.service.BbsInqService;
import egov.portal.bbs.inq.service.BbsNttVO;
import egov.portal.bbs.mstr.service.BbsMstrService;
import egov.portal.cmm.LoginVO;
import egov.portal.cmm.file.service.FileMngService;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/**
 * @Class Name : BbsInqController.java
 * @Description : 게시물 목록·상세 (사용자)
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.04.26      kjh          최초생성
 * @ 2019.10.28      sbk          비밀글은 작성자·관리자만
 * @author 통합포털 구축 kjh
 * @since 2016.04.26
 */
@Controller
public class BbsInqController {

    @Resource(name = "bbsInqService")
    private BbsInqService bbsInqService;

    @Resource(name = "bbsMstrService")
    private BbsMstrService bbsMstrService;

    @Resource(name = "fileMngService")
    private FileMngService fileMngService;

    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

    /**
     * 게시물 목록
     */
    @RequestMapping("/bbs/inq/nttList.do")
    public String selectNttList(@ModelAttribute("searchVO") BbsNttVO searchVO, ModelMap model) throws Exception {
        searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
        searchVO.setPageSize(propertiesService.getInt("pageSize"));

        PaginationInfo paginationInfo = new PaginationInfo();
        paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
        paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
        paginationInfo.setPageSize(searchVO.getPageSize());

        searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
        searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
        searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

        int totCnt = bbsInqService.selectNttListCnt(searchVO);
        paginationInfo.setTotalRecordCount(totCnt);

        model.addAttribute("bbsMstr", bbsMstrService.selectBbsMstr(searchVO.getBbsId()));
        model.addAttribute("noticeList", bbsInqService.selectNoticeNttList(searchVO.getBbsId()));
        model.addAttribute("resultList", bbsInqService.selectNttList(searchVO));
        model.addAttribute("resultCnt", totCnt);
        model.addAttribute("paginationInfo", paginationInfo);
        return "portal/bbs/nttList";
    }

    /**
     * 게시물 상세
     */
    @RequestMapping("/bbs/inq/nttView.do")
    public String selectNttView(@ModelAttribute("searchVO") BbsNttVO searchVO, HttpSession session, ModelMap model) throws Exception {
        BbsNttVO ntt = bbsInqService.selectNtt(searchVO, true);
        if ("Y".equals(ntt.getSecretAt())) {
            LoginVO user = (LoginVO) session.getAttribute("loginVO");
            boolean owner = user != null && user.getId().equals(ntt.getNtcrId());
            boolean admin = user != null && "USR".equals(user.getUserSe());
            if (!owner && !admin) {
                return "redirect:/bbs/inq/nttList.do?bbsId=" + ntt.getBbsId() + "&secretDeny=Y";
            }
        }
        model.addAttribute("result", ntt);
        if (ntt.getAtchFileId() != null) {
            model.addAttribute("fileList", fileMngService.selectFileList(ntt.getAtchFileId()));
        }
        return "portal/bbs/nttView";
    }
}
