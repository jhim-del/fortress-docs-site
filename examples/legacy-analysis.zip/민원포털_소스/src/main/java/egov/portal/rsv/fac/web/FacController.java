package egov.portal.rsv.fac.web;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egov.portal.cmm.file.service.FileMngService;
import egov.portal.rsv.fac.service.FacService;
import egov.portal.rsv.fac.service.FacVO;

/**
 * @Class Name : FacController.java
 * @Description : 시설 안내(사용자)
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.05.16      pms          최초생성
 * @ 2016.06.30      pms          관리자 시설 등록 화면 제외(운영 협의)
 * @author 통합포털 구축 pms
 * @since 2016.05.16
 */
@Controller
public class FacController {

    @Resource(name = "facService")
    private FacService facService;

    @Resource(name = "fileMngService")
    private FileMngService fileMngService;

    @RequestMapping("/rsv/fac/facInfo.do")
    public String facInfo(@RequestParam("fcltyId") String fcltyId, ModelMap model) throws Exception {
        FacVO fac = facService.selectFac(fcltyId);
        model.addAttribute("result", fac);
        if (fac.getAtchFileId() != null) {
            model.addAttribute("photoList", fileMngService.selectFileList(fac.getAtchFileId()));
        }
        return "portal/rsv/facInfo";
    }
}
