package egov.portal.sec.login.web;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egov.portal.cmm.LoginVO;
import egov.portal.cmm.exception.BizException;
import egov.portal.sec.login.service.LoginService;

/**
 * @Class Name : LoginController.java
 * @Description : 로그인·로그아웃
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.04.01      kjh          최초생성
 * @ 2016.11.14      chw          로그인 후 원래 화면 복귀
 * @author 통합포털 구축 kjh
 * @since 2016.04.01
 */
@Controller
public class LoginController {

    @Resource(name = "loginService")
    private LoginService loginService;

    @RequestMapping("/sec/login/loginForm.do")
    public String loginForm(@RequestParam(value = "returnUrl", required = false) String returnUrl, ModelMap model) {
        model.addAttribute("returnUrl", returnUrl);
        return "portal/login/loginForm";
    }

    @RequestMapping("/sec/login/actionLogin.do")
    public String actionLogin(@ModelAttribute("loginVO") LoginVO loginVO, @RequestParam(value = "returnUrl", required = false) String returnUrl,
                              HttpServletRequest request, ModelMap model) throws Exception {
        loginVO.setIp(request.getRemoteAddr());
        try {
            LoginVO user = loginService.actionLogin(loginVO);
            request.getSession().invalidate();
            request.getSession(true).setAttribute("loginVO", user);
        } catch (BizException e) {
            model.addAttribute("loginMessage", e.getMessageKey());
            model.addAttribute("returnUrl", returnUrl);
            return "portal/login/loginForm";
        }
        // 외부 URL 로 돌려보내지 않도록 내부 경로만 허용
        if (returnUrl != null && returnUrl.startsWith("/") && !returnUrl.startsWith("//")) {
            return "redirect:" + returnUrl;
        }
        return "redirect:/main.do";
    }

    @RequestMapping("/sec/login/mngLoginForm.do")
    public String mngLoginForm() {
        return "mng/login/mngLoginForm";
    }

    @RequestMapping("/sec/login/actionMngLogin.do")
    public String actionMngLogin(@ModelAttribute("loginVO") LoginVO loginVO, HttpServletRequest request, ModelMap model) throws Exception {
        loginVO.setIp(request.getRemoteAddr());
        try {
            LoginVO user = loginService.actionMngLogin(loginVO);
            request.getSession().invalidate();
            request.getSession(true).setAttribute("loginVO", user);
        } catch (BizException e) {
            model.addAttribute("loginMessage", e.getMessageKey());
            return "mng/login/mngLoginForm";
        }
        return "redirect:/mng/main.do";
    }

    @RequestMapping("/sec/login/logout.do")
    public String logout(HttpSession session) {
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        session.invalidate();
        return user != null && "USR".equals(user.getUserSe()) ? "redirect:/sec/login/mngLoginForm.do" : "redirect:/main.do";
    }
}
