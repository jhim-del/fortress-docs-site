package egov.portal.refund.req.web;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egov.portal.cmm.LoginVO;
import egov.portal.cmm.service.CmmUseService;
import egov.portal.refund.req.service.RefundReqService;

/**
 * 환불 신청 (사용자)
 *
 * @author jdh
 * @since 2019.10.01
 */
@Controller
public class RefundReqController {

    @Resource(name = "refundReqService")
    private RefundReqService refundReqService;

    @Resource(name = "cmmUseService")
    private CmmUseService cmmUseService;

    @GetMapping("/refund/req/reqForm.do")
    public String reqForm(@RequestParam("bizSe") String bizSe, @RequestParam("bizKey") String bizKey,
                          HttpSession session, Model model) throws Exception {
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        Map<String, Object> p = new HashMap<String, Object>();
        p.put("bizSe", bizSe);
        p.put("bizKey", bizKey);
        p.put("mbrId", user.getId());
        model.addAttribute("target", refundReqService.selectRefundTarget(p));
        model.addAttribute("bankList", cmmUseService.selectCmmCodeDetail("BNK001"));
        return "portal/refund/reqForm";
    }

    @PostMapping("/refund/req/reqSave.do")
    public String reqSave(@RequestParam Map<String, Object> p, HttpSession session) throws Exception {
        LoginVO user = (LoginVO) session.getAttribute("loginVO");
        p.put("mbrId", user.getId());
        refundReqService.insertRefundReq(p);
        return "redirect:/rsv/apply/myRsvList.do?refundReq=Y";
    }

}
