package egov.portal.civil.req.service.impl;

import java.util.List;
import java.util.Map;

import egov.portal.civil.req.service.CivilReqVO;

import egovframework.rte.psl.dataaccess.mapper.Mapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * 민원 신청 매퍼
 *
 * @author ywk
 * @since 2019.07.15
 */
@Mapper("civilReqMapper")
public interface CivilReqMapper {

    EgovMap selectAfairInfo(String afairCode) throws Exception;
    List<EgovMap> selectAfairList() throws Exception;
    // 접수번호 채번 (연도별 일련번호, 행 잠금)
    Integer selectRcptSeqForUpdate(String rcptYear) throws Exception;
    int updateRcptSeq(Map<String, Object> param) throws Exception;
    void insertRcptSeq(String rcptYear) throws Exception;
    void insertCivilRcpt(CivilReqVO vo) throws Exception;
    void insertProcHist(Map<String, Object> param) throws Exception;
    int updateAsgnResult(CivilReqVO vo) throws Exception;
    List<EgovMap> selectMyReqList(CivilReqVO vo) throws Exception;
    int selectMyReqListCnt(CivilReqVO vo) throws Exception;
    CivilReqVO selectMyReqDetail(CivilReqVO vo) throws Exception;
    EgovMap selectMyReqSttus(String applcntId) throws Exception;
    int updateWithdraw(CivilReqVO vo) throws Exception;

}
