package egov.portal.auth.menu.web;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egov.portal.auth.menu.service.MenuService;
import egov.portal.auth.menu.service.MenuVO;

/**
 * @Class Name : MenuController.java
 * @Description : 메뉴 관리
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.03.30      kjh          최초생성
 * @ 2019.07.22      ywk          트리 화면
 * @author 통합포털 구축 kjh
 * @since 2016.03.30
 */
@Controller
public class MenuController {

    @Resource(name = "menuService")
    private MenuService menuService;

    @RequestMapping("/mng/auth/menu/menuMng.do")
    public String menuMng() {
        return "mng/auth/menuMng";
    }

    @RequestMapping("/mng/auth/menu/menuTree.do")
    public String menuTree(ModelMap model) throws Exception {
        model.addAttribute("tree", menuService.selectMenuTree());
        return "jsonView";
    }

    @RequestMapping("/mng/auth/menu/menuDetail.do")
    public String menuDetail(@RequestParam("menuNo") int menuNo, ModelMap model) throws Exception {
        model.addAttribute("menu", menuService.selectMenu(menuNo));
        return "jsonView";
    }

    @RequestMapping("/mng/auth/menu/menuSave.do")
    public String menuSave(@ModelAttribute MenuVO vo, ModelMap model) throws Exception {
        menuService.saveMenu(vo);
        model.addAttribute("result", "OK");
        return "jsonView";
    }

}
