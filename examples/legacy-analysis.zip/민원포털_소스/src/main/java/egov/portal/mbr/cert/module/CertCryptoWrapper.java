package egov.portal.mbr.cert.module;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.idcert.module.CertCrypto;

import egov.portal.cmm.util.PortalProperties;

/**
 * 본인확인기관 제공 모듈(WEB-INF/lib/idcert-module-1.2.jar) 래퍼
 * 모듈 반환코드: 0 정상, -1 암호화 시스템 오류, -2 입력 데이터 오류, -9 사이트 정보 오류
 * @author lsy
 * @since 2016.05.24
 */
@Component("certCryptoWrapper")
public class CertCryptoWrapper {

    public String newRequestNo() {
        CertCrypto c = new CertCrypto();
        return c.getRequestNO(PortalProperties.getProperty("cert.siteCode"));
    }

    public String encrypt(String plain) {
        CertCrypto c = new CertCrypto();
        int ret = c.fnEncode(PortalProperties.getProperty("cert.siteCode"), PortalProperties.getProperty("cert.sitePw"), plain);
        if (ret != 0) {
            throw new IllegalStateException("본인확인 암호화 오류 " + ret);
        }
        return c.getCipherData();
    }

    public Map<String, String> decrypt(String cipher) {
        CertCrypto c = new CertCrypto();
        int ret = c.fnDecode(PortalProperties.getProperty("cert.siteCode"), PortalProperties.getProperty("cert.sitePw"), cipher);
        if (ret != 0) {
            return null;
        }
        return parse(c.getPlainData());
    }

    /** "길이:키길이:값" 형식 파싱 (모듈 매뉴얼 4.2) */
    private Map<String, String> parse(String plain) {
        Map<String, String> m = new HashMap<String, String>();
        int i = 0;
        while (i < plain.length()) {
            int c1 = plain.indexOf(':', i);
            int keyLen = Integer.parseInt(plain.substring(i, c1));
            String key = plain.substring(c1 + 1, c1 + 1 + keyLen);
            int c2 = plain.indexOf(':', c1 + 1 + keyLen);
            int valLen = Integer.parseInt(plain.substring(c1 + 1 + keyLen, c2));
            m.put(key, plain.substring(c2 + 1, c2 + 1 + valLen));
            i = c2 + 1 + valLen;
        }
        return m;
    }
}
