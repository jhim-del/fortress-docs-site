package egov.portal.auth.menu.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : MenuService.java
 * @Description : 메뉴 관리
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.03.30      kjh          최초생성
 * @author 통합포털 구축 kjh
 * @since 2016.03.30
 */
public interface MenuService {

    /** 권한별 메뉴 (좌측 메뉴) */
    List<MenuVO> selectAuthorMenuList(String authorCode) throws Exception;

    /** 메뉴 트리 (관리 화면) */
    List<EgovMap> selectMenuTree() throws Exception;

    /** 메뉴 1건 */
    MenuVO selectMenu(int menuNo) throws Exception;

    /** 메뉴 저장 */
    void saveMenu(MenuVO vo) throws Exception;
}
