package egov.portal.cmm;

import java.io.Serializable;

/**
 * @Class Name : LoginVO.java
 * @Description : 로그인 세션 VO
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.03.21      kjh          최초생성
 * @ 2019.09.02      ywk          회원등급 추가(환불 VIP)
 * @author 통합포털 구축 kjh
 * @since 2016.03.21
 */
public class LoginVO implements Serializable {

    private static final long serialVersionUID = 196150699897055582L;

    /** 아이디 */
    private String id;
    /** 이름 */
    private String name;
    /** 비밀번호 */
    private String password;
    /** 사용자구분(GNR:일반회원, USR:업무사용자) */
    private String userSe;
    /** 이메일 */
    private String email;
    /** 휴대전화 */
    private String mbtlnum;
    /** 부서코드 */
    private String deptCode;
    /** 부서명 */
    private String deptNm;
    /** 권한코드 */
    private String authorCode;
    /** 접속IP */
    private String ip;
    /** 회원등급 */
    private String mbrGrdCode;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getUserSe() { return userSe; }
    public void setUserSe(String userSe) { this.userSe = userSe; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getMbtlnum() { return mbtlnum; }
    public void setMbtlnum(String mbtlnum) { this.mbtlnum = mbtlnum; }
    public String getDeptCode() { return deptCode; }
    public void setDeptCode(String deptCode) { this.deptCode = deptCode; }
    public String getDeptNm() { return deptNm; }
    public void setDeptNm(String deptNm) { this.deptNm = deptNm; }
    public String getAuthorCode() { return authorCode; }
    public void setAuthorCode(String authorCode) { this.authorCode = authorCode; }
    public String getIp() { return ip; }
    public void setIp(String ip) { this.ip = ip; }
    public String getMbrGrdCode() { return mbrGrdCode; }
    public void setMbrGrdCode(String mbrGrdCode) { this.mbrGrdCode = mbrGrdCode; }
}
