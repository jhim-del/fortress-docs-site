package egov.portal.sec.login.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egov.portal.cmm.LoginVO;
import egov.portal.cmm.exception.BizException;
import egov.portal.cmm.util.PortalProperties;
import egov.portal.cmm.util.PortalScrty;
import egov.portal.sec.login.service.LoginService;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * @Class Name : LoginServiceImpl.java
 * @Description : 로그인 구현
 * @Modification Information
 * @  수정일         수정자          수정내용
 * @ -----------   ---------   -------------------------------
 * @ 2016.04.01      kjh          최초생성
 * @ 2017.02.14      pms          비밀번호 실패 잠금, MD5 → SHA-256 전환
 * @ 2019.09.02      ywk          회원등급 세션 적재
 * @author 통합포털 구축 kjh
 * @since 2016.04.01
 */
@Service("loginService")
public class LoginServiceImpl extends EgovAbstractServiceImpl implements LoginService {

    @Resource(name = "loginDAO")
    private LoginDAO loginDAO;

    @Override
    public LoginVO actionLogin(LoginVO vo) throws Exception {
        EgovMap mbr = loginDAO.selectMbrForLogin(vo.getId());
        if (mbr == null) {
            throw new BizException("fail.common.login");
        }
        if ("D".equals(mbr.get("mbrSttus"))) {
            throw new BizException("mbr.dormant");
        }
        int maxFail = PortalProperties.getInt("Globals.MaxLoginFailCnt", 5);
        if ("Y".equals(mbr.get("lockAt"))) {
            throw new BizException("fail.common.login.lock", maxFail);
        }

        String saved = (String) mbr.get("password");
        String enc = PortalScrty.encryptPassword(vo.getPassword(), vo.getId());
        boolean ok = enc.equals(saved);
        // 2017.02 이전 가입자: MD5 로 맞으면 SHA-256 으로 바꿔 저장
        if (!ok && saved != null && saved.length() == 32 && saved.equals(PortalScrty.encryptMd5(vo.getPassword()))) {
            loginDAO.updateMbrPassword(vo.getId(), enc);
            ok = true;
        }
        if (!ok) {
            loginDAO.updateLoginFail(vo.getId(), maxFail);
            throw new BizException("fail.common.login");
        }

        loginDAO.updateLoginSuccess(vo.getId());
        LoginVO user = new LoginVO();
        user.setId(vo.getId());
        user.setName((String) mbr.get("mbrNm"));
        user.setEmail((String) mbr.get("emailAdres"));
        user.setMbtlnum((String) mbr.get("mbtlnum"));
        user.setMbrGrdCode((String) mbr.get("mbrGrdCode"));
        user.setUserSe("GNR");
        user.setIp(vo.getIp());
        return user;
    }

    @Override
    public LoginVO actionMngLogin(LoginVO vo) throws Exception {
        EgovMap emp = loginDAO.selectEmplyrForLogin(vo.getId());
        if (emp == null || !"P".equals(emp.get("emplyrSttusCode"))) {
            throw new BizException("fail.common.login");
        }
        if ("Y".equals(emp.get("lockAt"))) {
            throw new BizException("fail.common.login.lock", 5);
        }
        if (!PortalScrty.encryptPassword(vo.getPassword(), vo.getId()).equals(emp.get("password"))) {
            loginDAO.updateEmplyrLoginFail(vo.getId());
            throw new BizException("fail.common.login");
        }
        loginDAO.updateEmplyrLoginSuccess(vo.getId());

        LoginVO user = new LoginVO();
        user.setId(vo.getId());
        user.setName((String) emp.get("userNm"));
        user.setDeptCode((String) emp.get("deptCode"));
        user.setDeptNm((String) emp.get("deptNm"));
        user.setAuthorCode((String) emp.get("authorCode"));
        user.setUserSe("USR");
        user.setIp(vo.getIp());
        return user;
    }
}
