package egov.portal.refund.batch;

import java.util.HashMap;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import egov.portal.refund.aprv.service.impl.RefundAprvMapper;

/**
 * 환불 마감 배치: 전일까지 승인된 건을 이체 완료(DONE)로 바꾼다
 * <p>
 * 2020.06 hjy: 회계 이체 확인 전에 DONE 이 되는 문제로 스케줄 해제(context-scheduling.xml), 수동 처리
 *
 * @author jdh
 * @since 2019.10.14
 */
@Component("refundCloseJob")
public class RefundCloseJob {

    private static final Logger LOGGER = LoggerFactory.getLogger(RefundCloseJob.class);

    @Resource(name = "refundAprvMapper")
    private RefundAprvMapper refundAprvMapper;

    public void close() {
        try {
            int n = refundAprvMapper.updateDone(new HashMap<String, Object>());
            LOGGER.info("환불 마감 {}건", n);
        } catch (Exception e) {
            LOGGER.error("환불 마감 실패", e);
        }
    }
}
