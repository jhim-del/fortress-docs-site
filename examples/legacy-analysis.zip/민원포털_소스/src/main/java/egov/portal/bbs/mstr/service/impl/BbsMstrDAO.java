package egov.portal.bbs.mstr.service.impl;

import org.springframework.stereotype.Repository;

import egov.portal.bbs.mstr.service.BbsMstrVO;
import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

@Repository("bbsMstrDAO")
public class BbsMstrDAO extends EgovAbstractMapper {

    public BbsMstrVO selectBbsMstr(String bbsId) {
        return selectOne("bbsMstrDAO.selectBbsMstr", bbsId);
    }
}
