<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>결재 문서</title>
<link rel="stylesheet" href="<c:url value='/css/mng/mng.css'/>">
<script>
function fn_sanctn(act) {
    var f = document.sanctnForm;
    if (act == "RJCT" && f.sanctnOpinion.value == "") { alert("반려 의견을 입력하십시오."); return; }
    var msg = {OK: "승인하시겠습니까?", RJCT: "반려하시겠습니까?"}[act];
    if (!confirm(msg)) return;
    f.act.value = act;
    f.submit();
}
</script>
</head>
<body>
<div id="wrap">
<jsp:include page="/WEB-INF/jsp/mng/include/mngLeft.jsp"/>
<div id="container">
    <h2>결재 문서</h2>
    <table class="sanctn_box">
        <tr>
            <c:forEach var="l" items="${lineList}">
            <c:if test="${l.sanctnTy ne 'REFR'}">
            <th><c:out value="${l.ofcpsNm}"/><c:if test="${l.sanctnTy eq 'AGRE'}">(합의)</c:if></th>
            </c:if>
            </c:forEach>
        </tr>
        <tr>
            <c:forEach var="l" items="${lineList}">
            <c:if test="${l.sanctnTy ne 'REFR'}">
            <td class="${l.sanctnOrdr eq result.curSanctnOrdr and result.sanctnSttus eq 'ING' ? 'cur' : ''}">
                <c:out value="${l.userNm}"/><br>
                <c:choose><c:when test="${l.sanctnResult eq 'OK'}"><span class="stamp">승인</span></c:when>
                    <c:when test="${l.sanctnResult eq 'RJCT'}"><span class="stamp rjct">반려</span></c:when></c:choose><br>
                <small>${l.sanctnPnttm}</small>
            </td>
            </c:if>
            </c:forEach>
        </tr>
    </table>
    <table class="board_view">
        <tr><th>문서번호</th><td>${result.docId}</td><th>기안</th><td><c:out value="${result.drafterNm}"/> ${result.draftPnttm}</td></tr>
        <tr><th>제목</th><td colspan="3"><c:out value="${result.docSj}"/></td></tr>
        <tr><th>본문</th><td colspan="3"><div class="doc_cn"><c:out value="${result.docCn}" escapeXml="false"/></div></td></tr>
        <c:if test="${not empty result.relBizSe}">
        <tr><th>관련 업무</th><td colspan="3">${result.relBizSe} / ${result.relBizKey}</td></tr>
        </c:if>
    </table>
    <h3>결재 의견</h3>
    <ul class="opinion">
        <c:forEach var="l" items="${lineList}"><c:if test="${not empty l.sanctnOpinion}"><li><strong><c:out value="${l.userNm}"/></strong> <c:out value="${l.sanctnOpinion}"/></li></c:if></c:forEach>
    </ul>
    <form name="sanctnForm" method="post" action="<c:url value='/mng/appr/doc/sanctn.do'/>">
        <input type="hidden" name="docId" value="${result.docId}">
        <input type="hidden" name="act">
        <c:if test="${result.sanctnSttus eq 'ING'}">
        <textarea name="sanctnOpinion" rows="3" cols="80" title="결재 의견"></textarea>
        <div class="btn_area">
            <span class="btn_b"><a href="#" onclick="fn_sanctn('OK'); return false;">승인</a></span>
            <span class="btn_b"><a href="#" onclick="fn_sanctn('RJCT'); return false;">반려</a></span>
        </div>
        </c:if>
    </form>
</div>
</div>
</body>
</html>
