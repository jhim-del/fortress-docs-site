<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<script>
    alert("<spring:message code='${exception.messageKey}' arguments='${exception.args}' text='처리할 수 없습니다.'/>");
    history.back();
</script>
