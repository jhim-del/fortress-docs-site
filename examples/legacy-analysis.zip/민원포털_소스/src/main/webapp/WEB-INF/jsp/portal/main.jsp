<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<%@ include file="/WEB-INF/jsp/cmm/include/head.jsp" %>
<%-- 2016 팝업창 관리 기능은 2019 고도화 때 제거(메인 배너로 대체) --%>
</head>
<body>
<%@ include file="/WEB-INF/jsp/cmm/include/header.jsp" %>
<div id="content" class="main">
    <section class="quick">
        <a href="<c:url value='/civil/req/reqAgree.do'/>" class="q1">민원 신청</a>
        <a href="<c:url value='/civil/req/myReqList.do'/>" class="q2">처리 현황 조회</a>
        <a href="<c:url value='/rsv/apply/calendar.do'/>" class="q3">시설 예약</a>
    </section>

    <c:if test="${not empty myCivilSttus}">
    <section class="my_civil">
        <h2>나의 민원 현황</h2>
        <ul>
            <li>접수 <strong><c:out value="${myCivilSttus.rcptCnt}"/></strong>건</li>
            <li>처리중 <strong><c:out value="${myCivilSttus.ingCnt}"/></strong>건</li>
            <li>처리완료 <strong><c:out value="${myCivilSttus.cmplCnt}"/></strong>건</li>
        </ul>
    </section>
    </c:if>

    <section class="notice">
        <h2>공지사항</h2>
        <ul>
            <c:forEach var="n" items="${noticeList}">
            <li><a href="<c:url value='/bbs/inq/nttView.do?bbsId=${n.bbsId}&nttId=${n.nttId}'/>"><c:out value="${n.nttSj}"/></a>
                <span class="date"><c:out value="${n.frstRegistPnttm}"/></span></li>
            </c:forEach>
        </ul>
        <a href="<c:url value='/bbs/inq/nttList.do?bbsId=BBSMSTR_000000000001'/>" class="more">더보기</a>
    </section>
</div>
<%@ include file="/WEB-INF/jsp/cmm/include/footer.jsp" %>
</body>
</html>
