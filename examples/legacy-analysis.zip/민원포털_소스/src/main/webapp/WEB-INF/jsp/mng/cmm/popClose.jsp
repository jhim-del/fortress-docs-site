<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<script>
    alert("${closeMsg}");
    if (opener) { opener.location.reload(); }
    self.close();
</script>
