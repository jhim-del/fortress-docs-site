<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>결재함</title>
<link rel="stylesheet" href="<c:url value='/css/mng/mng.css'/>">
<script src="<c:url value='/js/portal/common.js'/>"></script>
</head>
<body>
<div id="wrap">
<jsp:include page="/WEB-INF/jsp/mng/include/mngLeft.jsp"/>
<div id="container">
    <h2>결재함</h2>
    <ul class="tab">
        <li class="${searchVO.searchBox eq 'TODO' ? 'on' : ''}"><a href="?searchBox=TODO">결재할 문서</a></li>
        <li class="${searchVO.searchBox eq 'DRAFT' ? 'on' : ''}"><a href="?searchBox=DRAFT">기안한 문서</a></li>
        <li class="${searchVO.searchBox eq 'DONE' ? 'on' : ''}"><a href="?searchBox=DONE">결재한 문서</a></li>
        <li class="${searchVO.searchBox eq 'REFR' ? 'on' : ''}"><a href="?searchBox=REFR">참조 문서</a></li>
    </ul>
    <form:form commandName="searchVO" name="listForm" method="get">
        <form:hidden path="searchBox"/>
        <form:hidden path="pageIndex"/>
        <form:input path="searchKeyword" title="제목"/> <span class="btn_s"><a href="#" onclick="fn_egov_search(); return false;">검색</a></span>
        <span class="btn_b right"><a href="<c:url value='/mng/appr/doc/draftForm.do'/>">기안</a></span>
    </form:form>
    <table class="board_list">
        <thead><tr><th>문서번호</th><th>구분</th><th>제목</th><th>기안자</th><th>기안부서</th><th>기안일시</th><th>진행</th><th>현재 결재자</th><th>상태</th></tr></thead>
        <tbody>
        <c:forEach var="d" items="${resultList}">
        <tr>
            <td>${d.docId}</td><td>${d.docSeNm}</td>
            <td class="left"><a href="<c:url value='/mng/appr/doc/docView.do?docId=${d.docId}'/>"><c:out value="${d.docSj}"/></a></td>
            <td><c:out value="${d.drafterNm}"/></td><td><c:out value="${d.draftDeptNm}"/></td><td>${d.draftPnttm}</td>
            <td>${d.progrs}</td><td><c:out value="${d.curSanctnerNm}"/></td>
            <td><c:choose><c:when test="${d.sanctnSttus eq 'ING'}">진행</c:when><c:when test="${d.sanctnSttus eq 'CMPL'}">완결</c:when>
                <c:when test="${d.sanctnSttus eq 'RJCT'}">반려</c:when><c:otherwise>임시</c:otherwise></c:choose></td>
        </tr>
        </c:forEach>
        </tbody>
    </table>
    <div class="paging"><ui:pagination paginationInfo="${paginationInfo}" type="image" jsFunction="fn_egov_link_page"/></div>
</div>
</div>
</body>
</html>
