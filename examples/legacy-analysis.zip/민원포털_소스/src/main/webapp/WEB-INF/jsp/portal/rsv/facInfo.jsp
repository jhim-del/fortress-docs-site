<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<%@ include file="/WEB-INF/jsp/cmm/include/head.jsp" %>
</head>
<body>
<%@ include file="/WEB-INF/jsp/cmm/include/header.jsp" %>
<div id="content" class="sub">
    <h2 class="tit"><c:out value="${result.fcltyNm}"/></h2>
    <div class="fac_info">
        <dl>
            <dt>위치</dt><dd><c:out value="${result.lc}"/></dd>
            <dt>수용인원</dt><dd>${result.aceptncNmpr}명</dd>
            <dt>운영시간</dt><dd>${fn:substring(result.opnBeginTime,0,2)}:${fn:substring(result.opnBeginTime,2,4)} ~ ${fn:substring(result.opnEndTime,0,2)}:${fn:substring(result.opnEndTime,2,4)}</dd>
            <dt>이용료</dt><dd><c:choose><c:when test="${result.useChrge eq 0}">무료</c:when><c:otherwise>시간당 ${result.useChrge}원</c:otherwise></c:choose></dd>
        </dl>
        <div class="dc"><c:out value="${result.fcltyDc}" escapeXml="false"/></div>
    </div>
    <div class="btn_area"><a href="<c:url value='/rsv/apply/calendar.do?fcltyId=${result.fcltyId}'/>" class="btn btn-primary">예약하기</a></div>
</div>
<%@ include file="/WEB-INF/jsp/cmm/include/footer.jsp" %>
</body>
</html>
