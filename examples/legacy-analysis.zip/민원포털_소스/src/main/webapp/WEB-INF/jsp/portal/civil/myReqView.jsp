<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<%@ include file="/WEB-INF/jsp/cmm/include/head.jsp" %>
<script>
function fn_withdraw() {
    if (!confirm("민원을 취하하시겠습니까? 취하한 민원은 되돌릴 수 없습니다.")) return;
    document.withdrawForm.submit();
}
</script>
</head>
<body>
<%@ include file="/WEB-INF/jsp/cmm/include/header.jsp" %>
<div id="content" class="sub">
    <h2 class="tit">나의 민원 상세</h2>
    <table class="tbl-view">
        <colgroup><col style="width:18%"><col style="width:32%"><col style="width:18%"><col></colgroup>
        <tr><th>접수번호</th><td><c:out value="${result.civilRcptNo}"/></td><th>민원 사무</th><td><c:out value="${result.afairNm}"/></td></tr>
        <tr><th>접수일</th><td><c:out value="${result.rcptDt}"/></td><th>처리기한</th><td><c:out value="${result.procDdlnDt}"/></td></tr>
        <tr><th>처리상태</th><td colspan="3"><c:out value="${result.procSttusNm}"/></td></tr>
        <tr><th>제목</th><td colspan="3"><c:out value="${result.civilSj}"/></td></tr>
        <tr><th>내용</th><td colspan="3" class="cn"><c:out value="${result.civilCn}" escapeXml="true"/></td></tr>
        <tr><th>첨부파일</th><td colspan="3">
            <c:forEach var="f" items="${fileList}">
                <a href="<c:url value='/cmm/fms/FileDown.do?atchFileId=${f.atchFileId}&fileSn=${f.fileSn}'/>"><c:out value="${f.orignlFileNm}"/></a><br>
            </c:forEach></td></tr>
    </table>

    <c:if test="${result.procSttusCode eq 'CMPL'}">
    <h3 class="stit">처리 결과</h3>
    <div class="result-box"><c:out value="${result.procResultCn}"/></div>
    </c:if>

    <form name="withdrawForm" method="post" action="<c:url value='/civil/req/myReqWithdraw.do'/>">
        <input type="hidden" name="civilRcptNo" value="${result.civilRcptNo}">
    </form>
    <div class="btn-area">
        <c:if test="${result.procSttusCode eq 'RCPT' or result.procSttusCode eq 'WAIT_MANUAL'}">
            <a href="#" class="btn" onclick="fn_withdraw(); return false;">취하</a>
        </c:if>
        <a href="<c:url value='/civil/req/myReqList.do'/>" class="btn btn-primary">목록</a>
    </div>
</div>
<%@ include file="/WEB-INF/jsp/cmm/include/footer.jsp" %>
</body>
</html>
