<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<%@ include file="/WEB-INF/jsp/cmm/include/head.jsp" %>
</head>
<body>
<%@ include file="/WEB-INF/jsp/cmm/include/header.jsp" %>
<div id="content" class="sub">
    <h2 class="tit">답글 쓰기</h2>
    <div class="parent_box">
        <strong>원글</strong> <c:out value="${parent.nttSj}"/>
    </div>
    <form name="replyForm" method="post" action="<c:url value='/bbs/wrt/replySave.do'/>" enctype="multipart/form-data">
        <input type="hidden" name="bbsId" value="${parent.bbsId}">
        <input type="hidden" name="nttId" value="${parent.nttId}">
        <table class="tbl_form">
            <tr><th>제목</th><td><input type="text" name="nttSj" size="70" value="RE: <c:out value='${parent.nttSj}'/>"></td></tr>
            <tr><th>내용</th><td><textarea name="nttCn" rows="12" cols="80"></textarea></td></tr>
            <tr><th>첨부파일</th><td><input type="file" name="file_1"></td></tr>
        </table>
        <div class="btn_area right"><input type="submit" class="btn btn-primary" value="등록"></div>
    </form>
</div>
<%@ include file="/WEB-INF/jsp/cmm/include/footer.jsp" %>
</body>
</html>
