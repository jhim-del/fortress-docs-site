<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>환불 승인</title>
<link rel="stylesheet" href="<c:url value='/css/mng/mng.css'/>">
<script src="<c:url value='/js/lib/jquery-1.12.4.min.js'/>"></script>
<script src="<c:url value='/js/portal/common.js'/>"></script>
</head>
<body>
<div id="wrap">
<jsp:include page="/WEB-INF/jsp/mng/include/mngLeft.jsp"/>
<div id="container">
    <h2>환불 승인</h2>
    <form name="listForm" method="get">
        <input type="hidden" name="pageIndex" value="${searchVO.pageIndex}">
        <div class="search-box">
            <select name="schSttus">
                <option value="REQ" ${searchVO.schSttus eq 'REQ' ? 'selected' : ''}>신청</option>
                <option value="APRV" ${searchVO.schSttus eq 'APRV' ? 'selected' : ''}>승인(이체대기)</option>
                <option value="DONE" ${searchVO.schSttus eq 'DONE' ? 'selected' : ''}>완료</option>
                <option value="RJCT" ${searchVO.schSttus eq 'RJCT' ? 'selected' : ''}>반려</option>
            </select>
            <input type="text" name="schMbrNm" value="<c:out value='${searchVO.schMbrNm}'/>" placeholder="회원명">
            <button type="button" class="btn" onclick="fn_egov_search();">조회</button>
            <a href="<c:url value='/mng/refund/aprv/transferExcel.do'/>" class="btn">이체 목록 엑셀</a>
        </div>
    </form>
    <p class="total">총 ${totCnt}건</p>
    <table class="tbl-list">
        <thead><tr><th>순번</th><th>신청일</th><th>회원</th><th>등급</th><th>결제 내용</th><th>신청액</th><th>수수료</th><th>환불액</th><th>상태</th><th>경과일</th></tr></thead>
        <tbody>
        <c:forEach var="r" items="${resultList}">
            <tr>
                <td><a href="<c:url value='/mng/refund/aprv/aprvView.do?refundSeq=${r.refundSeq}'/>">${r.refundSeq}</a></td>
                <td>${r.regDt}</td>
                <td><c:out value="${r.mbrNm}"/></td>
                <td>${r.mbrGrdCode eq 'GRD_V' ? 'VIP' : '일반'}</td>
                <td class="al"><c:out value="${r.goodsNm}"/></td>
                <td class="ar"><fmt:formatNumber value="${r.reqAmt}"/></td>
                <td class="ar"><fmt:formatNumber value="${r.feeAmt}"/></td>
                <td class="ar"><fmt:formatNumber value="${r.refundAmt}"/></td>
                <td>${r.reqSttusNm}</td>
                <td><c:if test="${r.reqSttus eq 'REQ' and r.elapsedDays >= 5}"><span class="red">${r.elapsedDays}일</span></c:if></td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
    <div class="paging"><ui:pagination paginationInfo="${paginationInfo}" type="image" jsFunction="fn_egov_link_page"/></div>
</div>
</div>
</body>
</html>
