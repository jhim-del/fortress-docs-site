<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>결재선 지정</title>
<link rel="stylesheet" href="<c:url value='/css/mng/pop.css'/>">
<script src="<c:url value='/js/lib/jquery-1.12.4.min.js'/>"></script>
<script>
function fn_add(id, nm, ofcps) {
    if ($("#line li[data-id='" + id + "']").length) return;
    $("#line").append('<li data-id="' + id + '"><select class="ty"><option value="APRV">결재</option><option value="AGRE">합의</option><option value="REFR">참조</option></select> '
        + nm + ' (' + ofcps + ') <a href="#" onclick="$(this).parent().remove(); return false;">삭제</a></li>');
}
function fn_apply() {
    var items = [];
    $("#line li").each(function() { items.push({id: $(this).data("id"), ty: $(this).find(".ty").val(), label: $(this).text()}); });
    if (items.length == 0) { alert("결재자를 지정하십시오."); return; }
    opener.fn_setLine(items);
    self.close();
}
</script>
</head>
<body class="pop">
<h1>결재선 지정</h1>
<div class="pop_cols">
    <div class="col">
        <h2>직원</h2>
        <ul class="empl">
            <c:forEach var="e" items="${emplList}">
            <li><a href="#" onclick="fn_add('${e.emplyrId}','<c:out value="${e.userNm}"/>','<c:out value="${e.ofcpsNm}"/>'); return false;"><c:out value="${e.deptNm}"/> <c:out value="${e.userNm}"/> <c:out value="${e.ofcpsNm}"/></a></li>
            </c:forEach>
        </ul>
    </div>
    <div class="col">
        <h2>결재선 (위에서부터 순서)</h2>
        <ol id="line"></ol>
    </div>
</div>
<div class="btn_area"><a href="#" class="btn_b" onclick="fn_apply(); return false;">적용</a></div>
</body>
</html>
