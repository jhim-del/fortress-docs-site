<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>환불 상세</title>
<link rel="stylesheet" href="<c:url value='/css/mng/mng.css'/>">
<script>
function fn_approve() {
    if (confirm("환불액 <fmt:formatNumber value='${result.refundAmt}'/>원으로 승인하시겠습니까?")) document.aprvForm.submit();
}
function fn_reject() {
    var r = prompt("반려 사유를 입력하십시오.");
    if (!r) return;
    document.rjctForm.rjctRsn.value = r;
    document.rjctForm.submit();
}
</script>
</head>
<body>
<div id="wrap">
<jsp:include page="/WEB-INF/jsp/mng/include/mngLeft.jsp"/>
<div id="container">
    <h2>환불 상세</h2>
    <table class="tbl-view">
        <tr><th>회원</th><td><c:out value="${result.mbrNm}"/> (${result.mbrGrdCode eq 'GRD_V' ? 'VIP' : '일반'})</td><th>신청일</th><td>${result.regDt}</td></tr>
        <tr><th>결제일</th><td>${result.stlmDe}</td><th>상태</th><td>${result.reqSttus}</td></tr>
        <tr><th>신청액</th><td><fmt:formatNumber value="${result.reqAmt}"/>원</td><th>수수료(${result.feeRate}%)</th><td><fmt:formatNumber value="${result.feeAmt}"/>원</td></tr>
        <tr><th>환불액</th><td colspan="3"><strong><fmt:formatNumber value="${result.refundAmt}"/>원</strong></td></tr>
        <tr><th>환불 계좌</th><td colspan="3">${result.bankCd} ${acntMask} (<c:out value="${result.dpstrNm}"/>)</td></tr>
        <c:if test="${result.reqSttus eq 'RJCT'}"><tr><th>반려 사유</th><td colspan="3"><c:out value="${result.rjctRsn}"/></td></tr></c:if>
    </table>
    <form name="aprvForm" method="post" action="<c:url value='/mng/refund/aprv/approve.do'/>"><input type="hidden" name="refundSeq" value="${result.refundSeq}"></form>
    <form name="rjctForm" method="post" action="<c:url value='/mng/refund/aprv/reject.do'/>"><input type="hidden" name="refundSeq" value="${result.refundSeq}"><input type="hidden" name="rjctRsn"></form>
    <div class="btn-area">
        <c:if test="${result.reqSttus eq 'REQ'}">
            <button type="button" class="btn btn-primary" onclick="fn_approve();">승인</button>
            <button type="button" class="btn" onclick="fn_reject();">반려</button>
        </c:if>
        <a href="<c:url value='/mng/refund/aprv/aprvList.do'/>" class="btn">목록</a>
    </div>
</div>
</div>
</body>
</html>
