<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>결재 이력</title>
<link href="<c:url value='/css/mng/mng.css'/>" rel="stylesheet" type="text/css">
<script src="<c:url value='/js/portal/common.js'/>"></script>
</head>
<body>
<div id="wrap">
<jsp:include page="/WEB-INF/jsp/mng/include/mngLeft.jsp"/>
<div id="container">
<h2>결재 이력</h2>
<form name="listForm" method="get">
    <input type="hidden" name="pageIndex" value="1">
    기간 <input type="text" name="bgnde" value="${searchMap.bgnde}" size="8"> ~ <input type="text" name="endde" value="${searchMap.endde}" size="8">
    처리자 <input type="text" name="userNm" value="<c:out value='${searchMap.userNm}'/>" size="10">
    구분 <select name="act"><option value="">전체</option><option value="DRFT">기안</option><option value="OK">승인</option><option value="RJCT">반려</option></select>
    <input type="submit" value="조회" class="btn_s">
</form>
<table class="board_list">
    <tr><th>일시</th><th>문서</th><th>순번</th><th>처리자</th><th>부서</th><th>구분</th><th>의견</th></tr>
    <c:forEach var="h" items="${resultList}">
    <tr><td>${h.actPnttm}</td><td class="left"><a href="<c:url value='/mng/appr/doc/docView.do?docId=${h.docId}'/>"><c:out value="${h.docSj}"/></a></td>
        <td>${h.sanctnOrdr}</td><td><c:out value="${h.userNm}"/></td><td><c:out value="${h.deptNm}"/></td><td>${h.act}</td><td class="left"><c:out value="${h.opinion}"/></td></tr>
    </c:forEach>
</table>
<div class="paging"><ui:pagination paginationInfo="${paginationInfo}" type="image" jsFunction="fn_egov_link_page"/></div>
</div>
</div>
</body>
</html>
