<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<%@ include file="/WEB-INF/jsp/cmm/include/head.jsp" %>
</head>
<body>
<%@ include file="/WEB-INF/jsp/cmm/include/header.jsp" %>
<div id="content" class="sub">
    <h2 class="tit">회원가입</h2>
    <ol class="step"><li>약관 동의·본인확인</li><li>정보 입력</li><li class="on">가입 완료</li></ol>
    <div class="complete-box"><p><strong><c:out value="${mbrVO.mbrNm}"/></strong>님, 가입을 환영합니다.</p></div>
    <div class="btn_area"><a href="<c:url value='/sec/login/loginForm.do'/>" class="btn btn-primary">로그인</a></div>
</div>
<%@ include file="/WEB-INF/jsp/cmm/include/footer.jsp" %>
</body>
</html>
