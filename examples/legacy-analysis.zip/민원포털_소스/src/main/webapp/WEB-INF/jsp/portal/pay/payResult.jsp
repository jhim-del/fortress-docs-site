<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<%@ include file="/WEB-INF/jsp/cmm/include/head.jsp" %>
</head>
<body>
<%@ include file="/WEB-INF/jsp/cmm/include/header.jsp" %>
<div id="content" class="sub">
    <h2 class="tit">결제 결과</h2>
    <c:choose>
        <c:when test="${result.stlmSttus eq 'PAID' and result.stlmTy eq 'VBANK'}">
            <div class="complete-box">
                <p>입금전용계좌가 발급되었습니다. 입금이 확인되면 예약이 확정됩니다.</p>
                <p>계좌 <strong><c:out value="${result.vbankNo}"/></strong> / 입금기한 <c:out value="${result.vbankDdln}"/></p>
                <p>금액 <fmt:formatNumber value="${result.stlmAmt}"/>원</p>
            </div>
        </c:when>
        <c:when test="${result.stlmSttus eq 'PAID'}">
            <div class="complete-box">
                <p>결제가 완료되었습니다.</p>
                <p>금액 <fmt:formatNumber value="${result.stlmAmt}"/>원 / 승인번호 <c:out value="${result.apprNo}"/></p>
            </div>
        </c:when>
        <c:otherwise>
            <div class="complete-box fail"><p>결제에 실패했습니다. 다시 시도해 주십시오.</p></div>
        </c:otherwise>
    </c:choose>
    <div class="btn-area"><a href="<c:url value='/rsv/apply/myRsvList.do'/>" class="btn btn-primary">나의 예약</a></div>
</div>
<%@ include file="/WEB-INF/jsp/cmm/include/footer.jsp" %>
</body>
</html>
