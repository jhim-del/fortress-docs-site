<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<%@ include file="/WEB-INF/jsp/cmm/include/head.jsp" %>
<script>
function fn_apply() {
    var f = document.rsvApplyVO;
    if (f.usePurps.value.length < 2) { alert("이용 목적을 입력하십시오."); return; }
    var n = parseInt(f.nmpr.value, 10);
    if (isNaN(n) || n < 1) { alert("이용 인원을 입력하십시오."); return; }
    if (n > ${fac.aceptncNmpr}) { alert("수용 인원(${fac.aceptncNmpr}명)을 넘었습니다."); return; }
    if (!$("#agreeRule").is(":checked")) { alert("이용 수칙에 동의해 주십시오."); return; }
    f.submit();
}
</script>
</head>
<body>
<%@ include file="/WEB-INF/jsp/cmm/include/header.jsp" %>
<div id="content" class="sub">
    <h2 class="tit">예약 신청</h2>
    <form:form commandName="rsvApplyVO" name="rsvApplyVO" method="post" action="${pageContext.request.contextPath}/rsv/apply/apply.do">
    <form:hidden path="fcltyId"/>
    <form:hidden path="resveDe"/>
    <form:hidden path="beginTime"/>
    <form:hidden path="endTime"/>
    <table class="tbl_form">
        <tr><th>시설</th><td><c:out value="${fac.fcltyNm}"/> (<c:out value="${fac.lc}"/>)</td></tr>
        <tr><th>일시</th><td>${fn:substring(rsvApplyVO.resveDe,0,4)}.${fn:substring(rsvApplyVO.resveDe,4,6)}.${fn:substring(rsvApplyVO.resveDe,6,8)}
            ${fn:substring(rsvApplyVO.beginTime,0,2)}:${fn:substring(rsvApplyVO.beginTime,2,4)} ~ ${fn:substring(rsvApplyVO.endTime,0,2)}:${fn:substring(rsvApplyVO.endTime,2,4)}</td></tr>
        <tr><th><label for="applcntNm">신청자</label></th><td><form:input path="applcntNm" id="applcntNm" readonly="true"/></td></tr>
        <tr><th><label for="mbtlnum">연락처</label></th><td><form:input path="mbtlnum" id="mbtlnum" maxlength="13"/></td></tr>
        <tr><th><label for="usePurps">이용 목적</label></th><td><form:input path="usePurps" id="usePurps" size="50" maxlength="100"/></td></tr>
        <tr><th><label for="nmpr">이용 인원</label></th><td><form:input path="nmpr" id="nmpr" size="4"/> 명 (최대 ${fac.aceptncNmpr}명)</td></tr>
        <c:if test="${fac.useChrge > 0}">
        <tr><th>이용료</th><td>시간당 ${fac.useChrge}원 · 신청 후 결제 화면으로 이동합니다.</td></tr>
        </c:if>
    </table>
    <div class="rule_box">
        <h3>이용 수칙</h3>
        <ul>
            <li>예약 시간 10분 전부터 입실할 수 있습니다.</li>
            <li>시설 내 취식은 금지합니다.</li>
            <li>무단 불참 2회 시 1개월간 예약이 제한됩니다.</li>
        </ul>
        <label><input type="checkbox" id="agreeRule"> 위 수칙을 확인했습니다.</label>
    </div>
    <div class="btn_area"><a href="#" class="btn btn-primary" onclick="fn_apply(); return false;">신청</a></div>
    </form:form>
</div>
<%@ include file="/WEB-INF/jsp/cmm/include/footer.jsp" %>
</body>
</html>
