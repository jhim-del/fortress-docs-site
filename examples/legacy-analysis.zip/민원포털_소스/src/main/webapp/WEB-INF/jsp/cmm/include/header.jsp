<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<div id="skip"><a href="#content">본문 바로가기</a></div>
<header id="header">
    <h1 class="logo"><a href="<c:url value='/main.do'/>">통합 민원 포털</a></h1>
    <div class="util">
        <c:choose>
            <c:when test="${empty sessionScope.loginVO}">
                <a href="<c:url value='/sec/login/loginForm.do'/>">로그인</a>
                <a href="<c:url value='/mbr/join/joinAgree.do'/>">회원가입</a>
            </c:when>
            <c:otherwise>
                <span><c:out value="${sessionScope.loginVO.name}"/>님</span>
                <a href="<c:url value='/sec/login/logout.do'/>">로그아웃</a>
            </c:otherwise>
        </c:choose>
    </div>
    <nav id="gnb">
        <ul>
            <li><a href="<c:url value='/civil/req/reqAgree.do'/>">민원신청</a></li>
            <li><a href="<c:url value='/civil/req/myReqList.do'/>">나의 민원</a></li>
            <li><a href="<c:url value='/rsv/apply/calendar.do'/>">시설예약</a></li>
            <li><a href="<c:url value='/bbs/inq/nttList.do?bbsId=BBSMSTR_000000000001'/>">공지사항</a></li>
            <li><a href="<c:url value='/bbs/inq/nttList.do?bbsId=BBSMSTR_000000000002'/>">묻고답하기</a></li>
        </ul>
    </nav>
</header>
