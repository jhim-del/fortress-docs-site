<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>통합 민원 포털 관리자</title>
<link rel="stylesheet" href="<c:url value='/css/mng/mng.css'/>">
<c:if test="${param.err eq 'auth'}"><script>alert("해당 메뉴 권한이 없습니다.");</script></c:if>
</head>
<body>
<div id="wrap">
<jsp:include page="/WEB-INF/jsp/mng/include/mngLeft.jsp"/>
<div id="container">
    <h2><c:out value="${sessionScope.loginVO.deptNm}"/> <c:out value="${sessionScope.loginVO.name}"/>님</h2>
    <ul class="dash">
        <li><a href="<c:url value='/mng/civil/proc/procList.do'/>">민원 처리</a></li>
        <li><a href="<c:url value='/mng/appr/doc/docList.do?searchBox=TODO'/>">결재할 문서</a></li>
        <li><a href="<c:url value='/mng/refund/aprv/aprvList.do'/>">환불 승인</a></li>
    </ul>
</div>
</div>
</body>
</html>
