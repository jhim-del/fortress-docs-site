<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%-- 2019 고도화: 메뉴 하드코딩 → 권한별 메뉴(MngMenuInterceptor) --%>
<div id="lnb">
    <ul class="depth1">
        <c:forEach var="m" items="${sessionScope.mngMenuList}">
            <c:if test="${m.upperMenuNo eq 0}">
                <li class="${m.menuNo eq curMenuNo ? 'on' : ''}">
                    <a href="#"><c:out value="${m.menuNm}"/></a>
                    <ul class="depth2">
                        <c:forEach var="s" items="${sessionScope.mngMenuList}">
                            <c:if test="${s.upperMenuNo eq m.menuNo and s.displayAt eq 'Y'}">
                                <li><a href="<c:url value='${s.menuUrl}'/>"><c:out value="${s.menuNm}"/></a></li>
                            </c:if>
                        </c:forEach>
                    </ul>
                </li>
            </c:if>
        </c:forEach>
    </ul>
</div>
<%--
<ul>
    <li><a href="/mng/civil/proc/procList.do">민원처리</a></li>
    <li><a href="/mng/rsv/mng/rsvMngList.do">예약관리</a></li>
    <li><a href="/mng/bbs/mstr/mstrList.do">게시판관리</a></li>
</ul>
--%>
