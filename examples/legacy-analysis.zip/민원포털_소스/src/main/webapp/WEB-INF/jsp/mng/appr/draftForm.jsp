<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>기안</title>
<link rel="stylesheet" href="<c:url value='/css/mng/mng.css'/>">
<script src="<c:url value='/js/lib/jquery-1.12.4.min.js'/>"></script>
<script>
function fn_linePop() {
    window.open("<c:url value='/mng/appr/doc/lineSelectPop.do'/>", "linePop", "width=760,height=560");
}
/* lineSelectPop 에서 호출 */
function fn_setLine(items) {
    var html = "";
    $.each(items, function(i, it) {
        html += '<li>' + it.label + '<input type="hidden" name="sanctnerIds" value="' + it.id + '"><input type="hidden" name="sanctnTys" value="' + it.ty + '"></li>';
    });
    $("#lineView").html(html);
}
function fn_draft() {
    var f = document.apprDocVO;
    if (f.docSj.value == "") { alert("제목을 입력하십시오."); return; }
    if ($("#lineView li").length == 0) { alert("<spring:message code='appr.line.empty'/>"); return; }
    if (confirm("상신하시겠습니까?")) f.submit();
}
</script>
</head>
<body>
<div id="wrap">
<jsp:include page="/WEB-INF/jsp/mng/include/mngLeft.jsp"/>
<div id="container">
    <h2>기안</h2>
    <form:form commandName="apprDocVO" method="post" action="${pageContext.request.contextPath}/mng/appr/doc/draft.do">
    <table class="board_view">
        <tr><th>문서구분</th><td><form:select path="docSeCode"><form:option value="GNRL">일반</form:option><form:option value="CIVIL">민원 처리</form:option><form:option value="RFND">환불</form:option></form:select></td></tr>
        <tr><th>제목</th><td><form:input path="docSj" size="70"/></td></tr>
        <tr><th>결재선</th><td><ol id="lineView"></ol><span class="btn_s"><a href="#" onclick="fn_linePop(); return false;">결재선 지정</a></span></td></tr>
        <tr><th>본문</th><td><form:textarea path="docCn" rows="15" cols="90"/></td></tr>
        <tr><th>관련 업무</th><td><form:input path="relBizSe" size="8"/> <form:input path="relBizKey" size="20" title="관련 업무 키"/></td></tr>
    </table>
    <div class="btn_area right"><span class="btn_b"><a href="#" onclick="fn_draft(); return false;">상신</a></span></div>
    </form:form>
</div>
</div>
</body>
</html>
