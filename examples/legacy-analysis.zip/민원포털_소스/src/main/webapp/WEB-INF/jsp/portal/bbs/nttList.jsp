<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<%@ include file="/WEB-INF/jsp/cmm/include/head.jsp" %>
<script type="text/javaScript" language="javascript">
function fn_egov_inqire_notice(nttId) {
    document.subForm.nttId.value = nttId;
    document.subForm.action = "<c:url value='/bbs/inq/nttView.do'/>";
    document.subForm.submit();
}
</script>
</head>
<body>
<%@ include file="/WEB-INF/jsp/cmm/include/header.jsp" %>
<div id="content" class="sub">
    <h2 class="tit"><c:out value="${bbsMstr.bbsNm}"/></h2>

    <form name="listForm" action="<c:url value='/bbs/inq/nttList.do'/>" method="post">
    <input type="hidden" name="bbsId" value="<c:out value='${searchVO.bbsId}'/>">
    <input type="hidden" name="pageIndex" value="<c:out value='${searchVO.pageIndex}'/>">
    <div class="board_search">
        <select name="searchCondition" title="검색조건">
            <option value="0" <c:if test="${searchVO.searchCondition == '0'}">selected="selected"</c:if>>제목</option>
            <option value="1" <c:if test="${searchVO.searchCondition == '1'}">selected="selected"</c:if>>내용</option>
            <option value="2" <c:if test="${searchVO.searchCondition == '2'}">selected="selected"</c:if>>작성자</option>
        </select>
        <input name="searchKeyword" type="text" size="35" value="<c:out value='${searchVO.searchKeyword}'/>" maxlength="35" title="검색어">
        <input type="submit" value="검색" class="btn_s">
    </div>
    </form>

    <p class="total">전체 <strong><c:out value="${resultCnt}"/></strong>건 (<c:out value="${searchVO.pageIndex}"/>/<c:out value="${paginationInfo.totalPageCount}"/> 페이지)</p>
    <table class="board_list" summary="번호, 제목, 작성자, 작성일, 조회수">
        <caption>게시물 목록</caption>
        <colgroup><col width="8%"><col><col width="12%"><col width="12%"><col width="8%"></colgroup>
        <thead><tr><th>번호</th><th>제목</th><th>작성자</th><th>작성일</th><th>조회</th></tr></thead>
        <tbody>
        <c:forEach var="n" items="${noticeList}">
        <tr class="notice">
            <td><span class="ico_notice">공지</span></td>
            <td class="left"><a href="#" onclick="fn_egov_inqire_notice('${n.nttId}'); return false;"><c:out value="${n.nttSj}"/></a></td>
            <td><c:out value="${n.ntcrNm}"/></td><td>${n.frstRegistPnttm}</td><td>${n.rdcnt}</td>
        </tr>
        </c:forEach>
        <c:forEach var="r" items="${resultList}" varStatus="status">
        <tr>
            <td><c:out value="${(searchVO.pageIndex-1) * searchVO.pageSize + status.count}"/></td>
            <td class="left">
                <c:if test="${r.answerAt == 'Y'}"><span style="padding-left:${r.answerLc * 12}px">ㄴ</span></c:if>
                <c:if test="${r.secretAt == 'Y'}"><img src="<c:url value='/images/ico_lock.gif'/>" alt="비밀글"></c:if>
                <a href="#" onclick="fn_egov_inqire_notice('${r.nttId}'); return false;"><c:out value="${r.nttSj}"/></a>
                <c:if test="${r.fileCnt > 0}"><img src="<c:url value='/images/ico_file.gif'/>" alt="첨부"></c:if>
            </td>
            <td><c:out value="${r.ntcrNm}"/></td>
            <td><c:out value="${r.frstRegistPnttm}"/></td>
            <td><c:out value="${r.rdcnt}"/></td>
        </tr>
        </c:forEach>
        <c:if test="${fn:length(resultList) == 0}">
        <tr><td colspan="5"><spring:message code="info.nodata.msg"/></td></tr>
        </c:if>
        </tbody>
    </table>
    <div class="paging"><ui:pagination paginationInfo="${paginationInfo}" type="image" jsFunction="fn_egov_link_page"/></div>
    <c:if test="${bbsMstr.bbsTyCode ne 'NOTICE'}">
    <div class="btn_area right"><a href="<c:url value='/bbs/wrt/nttForm.do?bbsId=${searchVO.bbsId}'/>" class="btn btn-primary">글쓰기</a></div>
    </c:if>

    <form name="subForm" method="post">
        <input type="hidden" name="bbsId" value="<c:out value='${searchVO.bbsId}'/>">
        <input type="hidden" name="nttId">
        <input type="hidden" name="pageIndex" value="<c:out value='${searchVO.pageIndex}'/>">
        <input type="hidden" name="searchCondition" value="<c:out value='${searchVO.searchCondition}'/>">
        <input type="hidden" name="searchKeyword" value="<c:out value='${searchVO.searchKeyword}'/>">
    </form>
</div>
<%@ include file="/WEB-INF/jsp/cmm/include/footer.jsp" %>
</body>
</html>
