<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<%@ include file="/WEB-INF/jsp/cmm/include/head.jsp" %>
<script src="<c:url value='/js/portal/rsvCalendar.js'/>"></script>
<script>
var RSV = {
    ctx: "${pageContext.request.contextPath}",
    fcltyId: "${searchVO.fcltyId}",
    ym: "${searchVO.searchYm}",
    loggedIn: ${not empty sessionScope.loginVO}
};
$(function() {
    RsvCalendar.init(RSV, ${fn:length(dayList) > 0 ? 'true' : 'false'});
});
</script>
</head>
<body>
<%@ include file="/WEB-INF/jsp/cmm/include/header.jsp" %>
<div id="content" class="sub">
    <h2 class="tit">시설 예약</h2>
    <div class="fac_select">
        <form name="calForm" method="get">
            <select name="fcltyId" onchange="this.form.submit();" title="시설 선택">
                <c:forEach var="f" items="${facList}">
                <option value="${f.fcltyId}" <c:if test="${f.fcltyId eq searchVO.fcltyId}">selected</c:if>><c:out value="${f.fcltyNm}"/></option>
                </c:forEach>
            </select>
            <input type="hidden" name="searchYm" value="${searchVO.searchYm}">
        </form>
        <a href="<c:url value='/rsv/fac/facInfo.do?fcltyId=${searchVO.fcltyId}'/>">시설 안내</a>
    </div>

    <div class="cal_head">
        <a href="#" class="prev" onclick="RsvCalendar.move(-1); return false;">이전 달</a>
        <strong>${fn:substring(searchVO.searchYm,0,4)}년 ${fn:substring(searchVO.searchYm,4,6)}월</strong>
        <a href="#" class="next" onclick="RsvCalendar.move(1); return false;">다음 달</a>
    </div>
    <table class="calendar" id="calTbl">
        <thead><tr><th class="sun">일</th><th>월</th><th>화</th><th>수</th><th>목</th><th>금</th><th class="sat">토</th></tr></thead>
        <tbody></tbody>
    </table>
    <script>
    var DAYS = [
        <c:forEach var="d" items="${dayList}" varStatus="s">{de:"${d.de}", cnt:${d.resveCnt}, rest:"${d.restdeAt}", restNm:"<c:out value='${d.restdeNm}'/>"}<c:if test="${!s.last}">,</c:if></c:forEach>
    ];
    </script>

    <div id="slotArea" class="slot_area" style="display:none">
        <h3><span id="selDe"></span> 예약 가능 시간</h3>
        <ul id="slotList"></ul>
        <form name="applyForm" method="post" action="<c:url value='/rsv/apply/applyForm.do'/>">
            <input type="hidden" name="fcltyId" value="${searchVO.fcltyId}">
            <input type="hidden" name="resveDe">
            <input type="hidden" name="beginTime">
            <input type="hidden" name="endTime">
            <button type="button" class="btn btn-primary" onclick="RsvCalendar.apply();">예약 신청</button>
        </form>
    </div>
</div>
<%@ include file="/WEB-INF/jsp/cmm/include/footer.jsp" %>
</body>
</html>
