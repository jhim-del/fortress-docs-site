<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<script>
    alert("접근 권한이 없습니다.");
    location.href = "<c:url value='/main.do'/>";
</script>
