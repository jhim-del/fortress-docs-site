<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<%@ include file="/WEB-INF/jsp/cmm/include/head.jsp" %>
<script>
function fn_req() {
    var f = document.reqForm;
    if (f.bankCd.value == "") { alert("은행을 선택하십시오."); return; }
    if (!/^\d{10,16}$/.test(f.acntNo.value.replace(/-/g, ""))) { alert("계좌번호를 확인하십시오."); return; }
    if (f.dpstrNm.value == "") { alert("예금주를 입력하십시오."); return; }
    if (confirm("환불을 신청하시겠습니까?")) f.submit();
}
</script>
</head>
<body>
<%@ include file="/WEB-INF/jsp/cmm/include/header.jsp" %>
<div id="content" class="sub">
    <h2 class="tit">환불 신청</h2>
    <c:choose>
    <c:when test="${empty target}">
        <p class="nodata">환불 신청 대상이 아닙니다.</p>
    </c:when>
    <c:otherwise>
    <form name="reqForm" method="post" action="<c:url value='/refund/req/reqSave.do'/>">
        <input type="hidden" name="stlmId" value="${target.stlmId}">
        <input type="hidden" name="reqAmt" value="${target.refundPosblAmt}">
        <table class="tbl-form">
            <tr><th>결제 내용</th><td><c:out value="${target.goodsNm}"/></td></tr>
            <tr><th>환불 대상 금액</th><td><fmt:formatNumber value="${target.refundPosblAmt}"/>원</td></tr>
            <tr><th>환불 수수료</th><td><fmt:formatNumber value="${target.feeAmt}"/>원 (10%)</td></tr>
            <tr><th>환불 예정 금액</th><td><strong><fmt:formatNumber value="${target.expectAmt}"/>원</strong></td></tr>
            <tr><th>은행</th><td><select name="bankCd"><option value="">선택</option>
                <c:forEach var="b" items="${bankList}"><option value="${b.code}"><c:out value="${b.codeNm}"/></option></c:forEach></select></td></tr>
            <tr><th>계좌번호</th><td><input type="text" name="acntNo" maxlength="20"></td></tr>
            <tr><th>예금주</th><td><input type="text" name="dpstrNm" maxlength="20"></td></tr>
            <tr><th>사유</th><td><input type="text" name="reqRsn" class="w-full" value="시설 예약 취소"></td></tr>
        </table>
        <p class="help">관리자 확인 후 영업일 기준 5일 이내 입금됩니다.</p>
        <div class="btn-area"><button type="button" class="btn btn-primary" onclick="fn_req();">신청</button></div>
    </form>
    </c:otherwise>
    </c:choose>
</div>
<%@ include file="/WEB-INF/jsp/cmm/include/footer.jsp" %>
</body>
</html>
