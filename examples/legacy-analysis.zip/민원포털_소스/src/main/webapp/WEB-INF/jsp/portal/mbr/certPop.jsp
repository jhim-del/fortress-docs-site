<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<html>
<head>
<meta charset="utf-8">
<title>휴대폰 본인확인</title>
</head>
<body onload="document.certForm.submit();">
<form name="certForm" method="post" action="${certFormUrl}">
    <input type="hidden" name="svcType" value="MOBILE">
    <input type="hidden" name="EncodeData" value="${encData}">
</form>
</body>
</html>
