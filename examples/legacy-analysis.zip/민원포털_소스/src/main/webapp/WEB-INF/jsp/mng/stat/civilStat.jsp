<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>민원 통계</title>
<link rel="stylesheet" href="<c:url value='/css/mng/mng.css'/>">
<script src="<c:url value='/js/lib/jquery-1.12.4.min.js'/>"></script>
<script src="<c:url value='/js/mng/statChart.js'/>"></script>
<script>
var STAT = [
    <c:forEach var="r" items="${resultList}" varStatus="s">
    {label: "<c:out value='${empty r.deptNm ? (empty r.afairNm ? r.statYm : r.afairNm) : r.deptNm}'/>", rcpt: ${r.rcptCnt}, proc: ${r.procCnt}, over: ${r.ddlnOverCnt}}<c:if test="${!s.last}">,</c:if>
    </c:forEach>
];
$(function() {
    StatChart.bar("statCanvas", STAT, [
        {key: "rcpt", name: "접수", color: "#4a78c2"},
        {key: "proc", name: "처리", color: "#5aa469"},
        {key: "over", name: "기한초과", color: "#d9534f"}
    ]);
});
</script>
</head>
<body>
<div id="wrap">
<jsp:include page="/WEB-INF/jsp/mng/include/mngLeft.jsp"/>
<div id="container">
    <h2>민원 통계</h2>
    <p class="guide">일 통계 집계 결과를 보여 줍니다. 마지막 집계: <strong>${lastBatch.statDe}</strong> (${lastBatch.execDt}, ${lastBatch.batchResult eq 'S' ? '정상' : '실패'})</p>
    <form name="searchForm" method="get">
        <div class="search-box">
            <input type="text" name="schBgnDe" value="${param.schBgnDe}" size="8"> ~ <input type="text" name="schEndDe" value="${param.schEndDe}" size="8">
            <select name="groupBy">
                <option value="dept" ${param.groupBy eq 'dept' ? 'selected' : ''}>부서별</option>
                <option value="afair" ${param.groupBy eq 'afair' ? 'selected' : ''}>사무별</option>
                <option value="month" ${param.groupBy eq 'month' ? 'selected' : ''}>월별</option>
            </select>
            <select name="schDeptCode"><option value="">부서 전체</option>
                <c:forEach var="d" items="${deptList}"><option value="${d.deptCode}" ${param.schDeptCode eq d.deptCode ? 'selected' : ''}><c:out value="${d.deptNm}"/></option></c:forEach>
            </select>
            <button type="submit" class="btn">조회</button>
            <a href="<c:url value='/mng/stat/inq/civilStatExcel.do'/>?schBgnDe=${param.schBgnDe}&schEndDe=${param.schEndDe}" class="btn">엑셀</a>
        </div>
    </form>
    <canvas id="statCanvas" width="960" height="300"></canvas>
    <table class="tbl-list">
        <thead><tr><th>구분</th><th>접수</th><th>처리</th><th>기한초과</th><th>이송</th><th>초과율</th><th>평균 처리일</th></tr></thead>
        <tbody>
        <c:forEach var="r" items="${resultList}">
            <tr><td class="al"><c:out value="${empty r.deptNm ? (empty r.afairNm ? r.statYm : r.afairNm) : r.deptNm}"/></td>
                <td>${r.rcptCnt}</td><td>${r.procCnt}</td><td>${r.ddlnOverCnt}</td><td>${r.trnsfCnt}</td>
                <td>${r.overRate}%</td><td>${r.avgProcDays}</td></tr>
        </c:forEach>
        </tbody>
    </table>
</div>
</div>
</body>
</html>
