<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<%@ include file="/WEB-INF/jsp/cmm/include/head.jsp" %>
<script>
var maxFile = ${bbsMstr.atchPosblFileNumber};
function fn_save() {
    var f = document.bbsNttVO;
    if ($.trim(f.nttSj.value) == "") { alert("제목을 입력하십시오."); f.nttSj.focus(); return; }
    if ($.trim(f.nttCn.value) == "") { alert("내용을 입력하십시오."); f.nttCn.focus(); return; }
    <c:if test="${empty sessionScope.loginVO}">
    if (f.ntcrNm.value == "" || f.password.value.length < 4) { alert("작성자와 비밀번호(4자 이상)를 입력하십시오."); return; }
    </c:if>
    if ($("input[type=file]").filter(function() { return this.value != ""; }).length > maxFile) {
        alert("첨부파일은 " + maxFile + "개까지 가능합니다.");
        return;
    }
    if (confirm("<spring:message code='common.save.msg'/>")) f.submit();
}
</script>
</head>
<body>
<%@ include file="/WEB-INF/jsp/cmm/include/header.jsp" %>
<div id="content" class="sub">
    <h2 class="tit"><c:out value="${bbsMstr.bbsNm}"/> 글쓰기</h2>
    <form:form commandName="bbsNttVO" name="bbsNttVO" method="post" action="${pageContext.request.contextPath}/bbs/wrt/nttSave.do" enctype="multipart/form-data">
    <input type="hidden" name="bbsId" value="${bbsMstr.bbsId}">
    <form:hidden path="nttId"/>
    <form:hidden path="atchFileId"/>
    <table class="tbl_form">
        <c:if test="${empty sessionScope.loginVO}">
        <tr><th>작성자</th><td><form:input path="ntcrNm" maxlength="20"/></td></tr>
        <tr><th>비밀번호</th><td><form:password path="password" maxlength="20"/> <span class="help">수정·삭제·비밀글 확인에 사용</span></td></tr>
        </c:if>
        <tr><th><label for="nttSj">제목</label></th><td><form:input path="nttSj" id="nttSj" size="70" maxlength="200"/></td></tr>
        <c:if test="${bbsMstr.secretPosblAt eq 'Y'}">
        <tr><th>비밀글</th><td><label><form:checkbox path="secretAt" value="Y"/> 작성자와 관리자만 볼 수 있습니다.</label></td></tr>
        </c:if>
        <tr><th><label for="nttCn">내용</label></th><td><form:textarea path="nttCn" id="nttCn" rows="15" cols="80"/></td></tr>
        <c:if test="${bbsMstr.fileAtchPosblAt eq 'Y'}">
        <tr><th>첨부파일</th><td>
            <c:forEach begin="1" end="${bbsMstr.atchPosblFileNumber}" var="i"><input type="file" name="file_${i}"><br></c:forEach></td></tr>
        </c:if>
    </table>
    <div class="btn_area right">
        <a href="#" class="btn btn-primary" onclick="fn_save(); return false;">저장</a>
        <a href="<c:url value='/bbs/inq/nttList.do?bbsId=${bbsMstr.bbsId}'/>" class="btn">목록</a>
    </div>
    </form:form>
</div>
<%@ include file="/WEB-INF/jsp/cmm/include/footer.jsp" %>
</body>
</html>
