<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<%@ include file="/WEB-INF/jsp/cmm/include/head.jsp" %>
<script src="<c:url value='/js/portal/addrPopup.js'/>"></script>
<script>
var idChecked = false;

function fn_idCheck() {
    var id = $("#mbrId").val();
    if (!/^[a-z][a-z0-9]{5,19}$/.test(id)) {
        alert("아이디는 영문 소문자로 시작하는 6~20자 영문·숫자입니다.");
        return;
    }
    $.getJSON("<c:url value='/mbr/join/idDupCheck.do'/>", {mbrId: id}, function(d) {
        if (d.dupCnt > 0) {
            alert("이미 사용 중인 아이디입니다.");
            idChecked = false;
        } else {
            alert("사용할 수 있는 아이디입니다.");
            idChecked = true;
            $("#mbrId").prop("readonly", true);
        }
    });
}

function fn_join() {
    var f = document.mbrVO;
    if (!idChecked) { alert("아이디 중복 확인을 해 주십시오."); return; }
    var pw = f.password.value;
    if (!/^(?=.*[A-Za-z])(?=.*\d)(?=.*[^A-Za-z\d]).{9,20}$/.test(pw)) {
        alert("<spring:message code='mbr.pw.rule'/>");
        return;
    }
    if (pw != f.passwordCnfirm.value) { alert("비밀번호가 일치하지 않습니다."); return; }
    if (f.emailAdres.value != "" && !/^[\w.-]+@[\w-]+(\.[\w-]+)+$/.test(f.emailAdres.value)) {
        alert("이메일 형식을 확인하십시오.");
        return;
    }
    f.submit();
}
</script>
</head>
<body>
<%@ include file="/WEB-INF/jsp/cmm/include/header.jsp" %>
<div id="content" class="sub">
    <h2 class="tit">회원가입</h2>
    <ol class="step"><li>약관 동의·본인확인</li><li class="on">정보 입력</li><li>가입 완료</li></ol>
    <form:form commandName="mbrVO" name="mbrVO" method="post" action="${pageContext.request.contextPath}/mbr/join/join.do">
    <form:hidden path="emailRecptnAt"/>
    <form:hidden path="smsRecptnAt"/>
    <table class="tbl_form">
        <tr><th>이름</th><td><c:out value="${mbrVO.mbrNm}"/> <span class="help">(본인확인 정보)</span></td></tr>
        <tr><th><label for="mbrId">아이디</label></th><td><form:input path="mbrId" id="mbrId" maxlength="20"/> <a href="#" class="btn_s" onclick="fn_idCheck(); return false;">중복확인</a></td></tr>
        <tr><th><label for="password">비밀번호</label></th><td><form:password path="password" id="password" maxlength="20"/> <span class="help">영문·숫자·특수문자 조합 9~20자</span></td></tr>
        <tr><th><label for="passwordCnfirm">비밀번호 확인</label></th><td><form:password path="passwordCnfirm" id="passwordCnfirm" maxlength="20"/></td></tr>
        <tr><th>휴대전화</th><td><c:out value="${mbrVO.mbtlnum}"/></td></tr>
        <tr><th><label for="emailAdres">이메일</label></th><td><form:input path="emailAdres" id="emailAdres" maxlength="100" size="40"/></td></tr>
        <tr><th>주소</th><td>
            <form:input path="zip" id="zip" readonly="true" size="6"/> <a href="#" class="btn_s" onclick="fn_addrPopup('zip','adres','detailAdres'); return false;">주소검색</a><br>
            <form:input path="adres" id="adres" readonly="true" size="50"/> <form:input path="detailAdres" id="detailAdres" size="30" title="상세주소"/></td></tr>
    </table>
    <div class="btn_area"><a href="#" class="btn btn-primary" onclick="fn_join(); return false;">가입</a></div>
    </form:form>
</div>
<%@ include file="/WEB-INF/jsp/cmm/include/footer.jsp" %>
</body>
</html>
