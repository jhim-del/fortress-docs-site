<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8" isErrorPage="true"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="ko">
<head><meta charset="utf-8"><title>오류</title></head>
<body>
<div class="error_wrap">
    <h2>데이터 처리 중 오류가 발생했습니다.</h2>
    <p>같은 문제가 반복되면 담당자에게 화면과 시각을 알려 주십시오.</p>
    <a href="javascript:history.back();">이전 화면</a>
</div>
</body>
</html>
