<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<!DOCTYPE html>
<html lang="ko">
<head>
<%@ include file="/WEB-INF/jsp/cmm/include/head.jsp" %>
</head>
<body>
<%@ include file="/WEB-INF/jsp/cmm/include/header.jsp" %>
<div id="content" class="sub">
    <h2 class="tit">나의 민원</h2>
    <form name="listForm" method="get" action="<c:url value='/civil/req/myReqList.do'/>">
        <input type="hidden" name="pageIndex" value="${searchVO.pageIndex}">
        <div class="search-box">
            <select name="schYear" title="접수연도">
                <option value="">전체 연도</option>
                <c:forEach var="y" begin="2016" end="2021">
                    <option value="${y}" ${searchVO.schYear eq y ? 'selected' : ''}>${y}</option>
                </c:forEach>
            </select>
            <select name="schSttus" title="처리상태">
                <option value="">전체 상태</option>
                <option value="RCPT" ${searchVO.schSttus eq 'RCPT' ? 'selected' : ''}>접수</option>
                <option value="PROC" ${searchVO.schSttus eq 'PROC' ? 'selected' : ''}>처리중</option>
                <option value="CMPL" ${searchVO.schSttus eq 'CMPL' ? 'selected' : ''}>처리완료</option>
            </select>
            <button type="button" class="btn" onclick="fn_egov_search();">조회</button>
        </div>
    </form>
    <p class="total">전체 <strong><fmt:formatNumber value="${totCnt}"/></strong>건</p>
    <table class="tbl-list">
        <caption>나의 민원 목록</caption>
        <thead><tr><th>접수번호</th><th>민원 사무</th><th>제목</th><th>접수일</th><th>처리기한</th><th>상태</th></tr></thead>
        <tbody>
        <c:forEach var="r" items="${resultList}">
            <tr>
                <td><c:out value="${r.civilRcptNo}"/></td>
                <td><c:out value="${r.afairNm}"/></td>
                <td class="al"><a href="<c:url value='/civil/req/myReqView.do?civilRcptNo=${r.civilRcptNo}'/>"><c:out value="${r.civilSj}"/></a></td>
                <td><c:out value="${fn:substring(r.rcptDt,0,4)}.${fn:substring(r.rcptDt,4,6)}.${fn:substring(r.rcptDt,6,8)}"/></td>
                <td><c:out value="${fn:substring(r.procDdlnDt,0,4)}.${fn:substring(r.procDdlnDt,4,6)}.${fn:substring(r.procDdlnDt,6,8)}"/></td>
                <td><span class="sttus ${r.procSttusCode}"><c:out value="${r.procSttusNm}"/></span></td>
            </tr>
        </c:forEach>
        <c:if test="${empty resultList}">
            <tr><td colspan="6" class="nodata">신청한 민원이 없습니다.</td></tr>
        </c:if>
        </tbody>
    </table>
    <div class="paging"><ui:pagination paginationInfo="${paginationInfo}" type="image" jsFunction="fn_egov_link_page"/></div>
</div>
<%@ include file="/WEB-INF/jsp/cmm/include/footer.jsp" %>
</body>
</html>
