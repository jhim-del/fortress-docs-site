<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>메뉴 관리</title>
<link rel="stylesheet" href="<c:url value='/css/mng/mng.css'/>">
<script src="<c:url value='/js/lib/jquery-1.12.4.min.js'/>"></script>
<script src="<c:url value='/js/mng/menuTree.js'/>"></script>
<script>
$(function() {
    MenuTree.load("<c:url value='/mng/auth/menu/menuTree.do'/>", "#tree", function(id) {
        $.getJSON("<c:url value='/mng/auth/menu/menuDetail.do'/>", {menuNo: id}, function(d) {
            var f = document.menuForm, m = d.menu;
            f.menuNo.value = m.menuNo; f.upperMenuNo.value = m.upperMenuNo; f.menuNm.value = m.menuNm;
            f.menuUrl.value = m.menuUrl || ""; f.menuDc.value = m.menuDc || ""; f.displayAt.value = m.displayAt; f.useAt.value = m.useAt;
        });
    });
});
function fn_save() {
    $.post("<c:url value='/mng/auth/menu/menuSave.do'/>", $(document.menuForm).serialize(), function() {
        alert("저장했습니다.");
        location.reload();
    });
}
function fn_new() {
    var f = document.menuForm, up = f.menuNo.value || 0;
    f.reset(); f.menuNo.value = 0; f.upperMenuNo.value = up;
}
</script>
</head>
<body>
<div id="wrap">
<jsp:include page="/WEB-INF/jsp/mng/include/mngLeft.jsp"/>
<div id="container" class="cols">
    <h2>메뉴 관리</h2>
    <div class="col-left"><ul id="tree" class="tree"></ul></div>
    <div class="col-right">
        <form name="menuForm">
            <input type="hidden" name="menuNo" value="0">
            <table class="tbl-view">
                <tr><th>상위 메뉴번호</th><td><input type="text" name="upperMenuNo" readonly></td></tr>
                <tr><th>메뉴명</th><td><input type="text" name="menuNm"></td></tr>
                <tr><th>URL</th><td><input type="text" name="menuUrl" size="50"></td></tr>
                <tr><th>설명</th><td><input type="text" name="menuDc" size="50"></td></tr>
                <tr><th>좌측 표시</th><td><select name="displayAt"><option value="Y">표시</option><option value="N">숨김</option></select></td></tr>
                <tr><th>사용</th><td><select name="useAt"><option value="Y">사용</option><option value="N">미사용</option></select></td></tr>
            </table>
            <button type="button" class="btn" onclick="fn_new();">하위 메뉴 추가</button>
            <button type="button" class="btn btn-primary" onclick="fn_save();">저장</button>
        </form>
    </div>
</div>
</div>
</body>
</html>
