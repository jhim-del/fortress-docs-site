<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>공통코드 관리</title>
<link rel="stylesheet" href="<c:url value='/css/mng/mng.css'/>">
<script>
function fn_editDetail(code, nm, dc, ordr, useAt) {
    var f = document.detailForm;
    f.code.value = code; f.code.readOnly = true;
    f.codeNm.value = nm; f.codeDc.value = dc; f.sortOrdr.value = ordr; f.useAt.value = useAt;
}
function fn_newDetail() {
    var f = document.detailForm;
    f.reset(); f.code.readOnly = false;
}
</script>
</head>
<body>
<div id="wrap">
<jsp:include page="/WEB-INF/jsp/mng/include/mngLeft.jsp"/>
<div id="container" class="cols">
    <h2>공통코드 관리</h2>
    <div class="col-left">
        <form name="searchForm" method="get">
            <select name="searchCondition"><option value="CodeId">코드ID</option><option value="CodeIdNm" <c:if test="${searchVO.searchCondition eq 'CodeIdNm'}">selected</c:if>>코드명</option></select>
            <input type="text" name="searchKeyword" value="<c:out value='${searchVO.searchKeyword}'/>" size="12">
            <input type="submit" value="조회" class="btn_s">
        </form>
        <table class="board_list">
            <tr><th>분류</th><th>코드ID</th><th>코드명</th><th>상세</th><th>사용</th></tr>
            <c:forEach var="c" items="${codeIdList}">
            <tr class="${c.codeId eq selCodeId ? 'on' : ''}">
                <td>${c.clCode}</td>
                <td><a href="?selCodeId=${c.codeId}&searchCondition=${searchVO.searchCondition}&searchKeyword=${searchVO.searchKeyword}">${c.codeId}</a></td>
                <td class="left"><c:out value="${c.codeIdNm}"/></td><td>${c.detailCnt}</td><td>${c.useAt}</td>
            </tr>
            </c:forEach>
        </table>
    </div>
    <div class="col-right">
        <c:if test="${not empty selCodeId}">
        <h3>${selCodeId} 상세코드</h3>
        <table class="board_list">
            <tr><th>코드</th><th>코드명</th><th>설명</th><th>순서</th><th>사용</th></tr>
            <c:forEach var="d" items="${detailList}">
            <tr><td><a href="#" onclick="fn_editDetail('${d.code}','<c:out value="${d.codeNm}"/>','<c:out value="${d.codeDc}"/>','${d.sortOrdr}','${d.useAt}'); return false;">${d.code}</a></td>
                <td class="left"><c:out value="${d.codeNm}"/></td><td class="left"><c:out value="${d.codeDc}"/></td><td>${d.sortOrdr}</td><td>${d.useAt}</td></tr>
            </c:forEach>
        </table>
        <form name="detailForm" method="post" action="<c:url value='/mng/code/cmmn/saveCodeDetail.do'/>">
            <input type="hidden" name="codeId" value="${selCodeId}">
            코드 <input type="text" name="code" size="8"> 코드명 <input type="text" name="codeNm" size="15">
            설명 <input type="text" name="codeDc" size="20"> 순서 <input type="text" name="sortOrdr" size="3">
            <select name="useAt"><option value="Y">사용</option><option value="N">미사용</option></select>
            <input type="submit" value="저장" class="btn_s"> <input type="button" value="신규" class="btn_s" onclick="fn_newDetail();">
        </form>
        </c:if>
    </div>
</div>
</div>
</body>
</html>
