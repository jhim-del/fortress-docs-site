<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<%@ include file="/WEB-INF/jsp/cmm/include/head.jsp" %>
</head>
<body>
<%@ include file="/WEB-INF/jsp/cmm/include/header.jsp" %>
<div id="content" class="sub">
    <h2 class="tit">민원 신청</h2>
    <ol class="step"><li>1. 사무 선택·동의</li><li>2. 신청서 작성</li><li class="on">3. 접수 완료</li></ol>
    <div class="complete-box">
        <p>민원이 정상적으로 접수되었습니다.</p>
        <p>접수번호 <strong><c:out value="${rcptNo}"/></strong></p>
        <p class="help">처리 상황은 [나의 민원]에서 확인하실 수 있습니다.</p>
    </div>
    <div class="btn-area">
        <a href="<c:url value='/civil/req/myReqList.do'/>" class="btn btn-primary">나의 민원</a>
        <a href="<c:url value='/main.do'/>" class="btn">메인</a>
    </div>
</div>
<%@ include file="/WEB-INF/jsp/cmm/include/footer.jsp" %>
</body>
</html>
