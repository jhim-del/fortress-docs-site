<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>민원 처리 | 통합 민원 포털 관리자</title>
<link rel="stylesheet" href="<c:url value='/css/mng/mng.css'/>">
<script src="<c:url value='/js/lib/jquery-1.12.4.min.js'/>"></script>
<script src="<c:url value='/js/portal/common.js'/>"></script>
<script type="text/javaScript" language="javascript">
function fn_view(no) {
    document.listForm.civilRcptNo.value = no;
    document.listForm.action = "<c:url value='/mng/civil/proc/procView.do'/>";
    document.listForm.submit();
}
</script>
</head>
<body>
<div id="wrap">
<jsp:include page="/WEB-INF/jsp/mng/include/mngLeft.jsp"/>
<div id="container">
    <h2>민원 처리</h2>
    <form:form commandName="searchVO" name="listForm" method="post" action="${pageContext.request.contextPath}/mng/civil/proc/procList.do">
    <input type="hidden" name="civilRcptNo">
    <form:hidden path="pageIndex"/>
    <div class="search_box">
        <ul>
            <li>
                <label for="searchSttus">상태</label>
                <form:select path="searchSttus" id="searchSttus">
                    <form:option value="">전체</form:option>
                    <form:options items="${sttusList}" itemValue="code" itemLabel="codeNm"/>
                </form:select>
            </li>
            <li>
                <label for="searchDeptCode">부서</label>
                <form:select path="searchDeptCode" id="searchDeptCode">
                    <form:option value="">전체</form:option>
                    <form:options items="${deptList}" itemValue="deptCode" itemLabel="deptNm"/>
                </form:select>
            </li>
            <li>
                <label>접수일</label>
                <form:input path="searchBgnDe" cssClass="datepicker" size="10"/> ~ <form:input path="searchEndDe" cssClass="datepicker" size="10"/>
            </li>
            <li>
                <label><form:checkbox path="searchDdlnOverAt" value="Y"/> 기한 초과만</label>
            </li>
            <li>
                <form:select path="searchCondition">
                    <form:option value="sj">제목</form:option>
                    <form:option value="rcptNo">접수번호</form:option>
                    <form:option value="applcnt">신청인</form:option>
                </form:select>
                <form:input path="searchKeyword" size="20" title="검색어"/>
                <span class="btn_b"><a href="#" onclick="fn_egov_search(); return false;">조회</a></span>
            </li>
        </ul>
    </div>
    </form:form>

    <p class="total">총 <strong><c:out value="${totCnt}"/></strong>건</p>
    <table class="board_list">
        <colgroup>
            <col width="11%"><col width="13%"><col><col width="8%"><col width="9%"><col width="9%"><col width="10%"><col width="9%"><col width="8%">
        </colgroup>
        <thead>
        <tr><th>접수번호</th><th>민원 사무</th><th>제목</th><th>신청인</th><th>접수일</th><th>처리기한</th><th>담당부서</th><th>담당자</th><th>상태</th></tr>
        </thead>
        <tbody>
        <c:forEach var="r" items="${resultList}" varStatus="st">
        <tr class="${r.ddlnOverAt eq 'Y' ? 'over' : ''}">
            <td><c:out value="${r.civilRcptNo}"/></td>
            <td><c:out value="${r.afairNm}"/></td>
            <td class="left"><a href="#" onclick="fn_view('${r.civilRcptNo}'); return false;"><c:out value="${r.civilSj}"/></a>
                <c:if test="${r.trnsfCnt > 0}"><span class="tag">이송 ${r.trnsfCnt}</span></c:if></td>
            <td><c:out value="${r.applcntNm}"/></td>
            <td><c:out value="${r.rcptDt}"/></td>
            <td><c:out value="${r.procDdlnDt}"/></td>
            <td><c:out value="${r.deptNm}"/></td>
            <td><c:out value="${empty r.chargerNm ? '-' : r.chargerNm}"/></td>
            <td><c:out value="${r.procSttusNm}"/></td>
        </tr>
        </c:forEach>
        <c:if test="${fn:length(resultList) == 0}">
        <tr><td colspan="9">조회된 민원이 없습니다.</td></tr>
        </c:if>
        </tbody>
    </table>
    <div class="paging"><ui:pagination paginationInfo="${paginationInfo}" type="image" jsFunction="fn_egov_link_page"/></div>
</div>
</div>
</body>
</html>
