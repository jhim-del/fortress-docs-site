<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>민원 상세 | 통합 민원 포털 관리자</title>
<link rel="stylesheet" href="<c:url value='/css/mng/mng.css'/>">
<script src="<c:url value='/js/lib/jquery-1.12.4.min.js'/>"></script>
<script type="text/javaScript" language="javascript">
function fn_regist() {
    var f = document.procForm;
    if ($.trim(f.procResultCn.value) == "") {
        alert("처리 결과를 입력하십시오.");
        f.procResultCn.focus();
        return;
    }
    if (confirm("처리 완료하시겠습니까? 완료 후에는 수정할 수 없습니다.")) {
        f.action = "<c:url value='/mng/civil/proc/procRegist.do'/>";
        f.submit();
    }
}
function fn_trnsf() {
    window.open("<c:url value='/mng/civil/proc/trnsfPop.do'/>?civilRcptNo=${result.civilRcptNo}", "trnsf", "width=520,height=420");
}
function fn_asgn() {
    var f = document.asgnForm;
    if (f.chargerId.value == "") { alert("담당자를 선택하십시오."); return; }
    f.submit();
}
</script>
</head>
<body>
<div id="wrap">
<jsp:include page="/WEB-INF/jsp/mng/include/mngLeft.jsp"/>
<div id="container">
    <h2>민원 상세</h2>
    <table class="board_view">
        <colgroup><col width="15%"><col width="35%"><col width="15%"><col width="35%"></colgroup>
        <tr><th>접수번호</th><td><c:out value="${result.civilRcptNo}"/></td><th>민원 사무</th><td><c:out value="${result.afairNm}"/></td></tr>
        <tr><th>신청인</th><td><c:out value="${result.applcntNm}"/></td><th>연락처</th><td><c:out value="${result.applcntMbtlnum}"/></td></tr>
        <tr><th>접수일</th><td><c:out value="${result.rcptDt}"/></td><th>처리기한</th><td><c:out value="${result.procDdlnDt}"/></td></tr>
        <tr><th>제목</th><td colspan="3"><c:out value="${result.civilSj}"/></td></tr>
        <tr><th>내용</th><td colspan="3"><pre class="cn"><c:out value="${result.civilCn}"/></pre></td></tr>
    </table>

    <c:if test="${not empty chargerList}">
    <h3>담당자 배정</h3>
    <form name="asgnForm" method="post" action="<c:url value='/mng/civil/proc/asgnManual.do'/>">
        <input type="hidden" name="civilRcptNo" value="${result.civilRcptNo}">
        <select name="chargerId">
            <option value="">선택</option>
            <c:forEach var="c" items="${chargerList}">
            <option value="${c.chargerId}"><c:out value="${c.userNm}"/> (<c:out value="${c.ofcpsNm}"/>)</option>
            </c:forEach>
        </select>
        <span class="btn_s"><a href="#" onclick="fn_asgn(); return false;">배정</a></span>
    </form>
    </c:if>

    <h3>처리 결과</h3>
    <form name="procForm" method="post">
        <input type="hidden" name="civilRcptNo" value="${result.civilRcptNo}">
        <c:choose>
            <c:when test="${result.procSttusCode eq 'CMPL'}">
                <div class="result"><c:out value="${result.procResultCn}"/> (처리일 <c:out value="${result.procDt}"/>)</div>
            </c:when>
            <c:otherwise>
                <textarea name="procResultCn" rows="8" style="width:98%" title="처리 결과"></textarea>
                <div class="btn_area">
                    <span class="btn_b"><a href="#" onclick="fn_regist(); return false;">처리완료</a></span>
                    <span class="btn_b"><a href="#" onclick="fn_trnsf(); return false;">이송</a></span>
                </div>
            </c:otherwise>
        </c:choose>
    </form>

    <h3>처리 이력</h3>
    <table class="board_list">
        <thead><tr><th>순번</th><th>상태</th><th>내용</th><th>처리자</th><th>일시</th></tr></thead>
        <tbody>
        <c:forEach var="h" items="${histList}">
        <tr><td>${h.histSn}</td><td><c:out value="${h.procSttusNm}"/></td><td class="left"><c:out value="${h.procCn}"/></td>
            <td><c:out value="${h.processrNm}"/></td><td>${h.procPnttm}</td></tr>
        </c:forEach>
        </tbody>
    </table>

    <c:if test="${not empty trnsfList}">
    <h3>이송 이력</h3>
    <ul class="trnsf">
        <c:forEach var="t" items="${trnsfList}">
        <li>${t.trnsfDt} <c:out value="${t.beforeDeptNm}"/> → <c:out value="${t.afterDeptNm}"/> : <c:out value="${t.trnsfResn}"/></li>
        </c:forEach>
    </ul>
    </c:if>
    <div class="btn_area right"><span class="btn_b"><a href="<c:url value='/mng/civil/proc/procList.do'/>">목록</a></span></div>
</div>
</div>
</body>
</html>
