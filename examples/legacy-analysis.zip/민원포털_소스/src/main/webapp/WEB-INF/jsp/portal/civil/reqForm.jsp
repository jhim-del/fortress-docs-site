<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<%@ include file="/WEB-INF/jsp/cmm/include/head.jsp" %>
<script src="<c:url value='/js/portal/addrPopup.js'/>"></script>
<script>
var MAX_FILE = 3;

function fn_addFile() {
    if ($(".file-row").length >= MAX_FILE) {
        alert("첨부파일은 " + MAX_FILE + "개까지 가능합니다.");
        return;
    }
    var idx = $(".file-row").length + 1;
    $("#fileArea").append('<div class="file-row"><input type="file" name="file_' + idx + '" title="첨부파일 ' + idx + '"></div>');
}

function fn_submit() {
    var f = document.civilReqVO;
    if (isEmpty(f.applcntNm.value)) { alert("성명을 입력하십시오."); f.applcntNm.focus(); return; }
    if (!/^01[016789]\d{7,8}$/.test(f.applcntMbtlnum.value.replace(/-/g, ""))) {
        alert("휴대전화 번호를 확인하십시오."); f.applcntMbtlnum.focus(); return;
    }
    if (isEmpty(f.civilSj.value)) { alert("제목을 입력하십시오."); f.civilSj.focus(); return; }
    if (f.civilCn.value.length < 10) { alert("내용을 10자 이상 입력하십시오."); f.civilCn.focus(); return; }
    if (f.civilCn.value.length > 4000) { alert("내용은 4000자까지 입력할 수 있습니다."); return; }
    if (!confirm("민원을 신청하시겠습니까?")) return;
    $("#btnSubmit").prop("disabled", true);
    f.submit();
}

$(function() {
    $("#civilCn").on("keyup", function() { $("#cnLen").text(this.value.length); });
});
</script>
</head>
<body>
<%@ include file="/WEB-INF/jsp/cmm/include/header.jsp" %>
<div id="content" class="sub">
    <h2 class="tit">민원 신청</h2>
    <ol class="step"><li>1. 사무 선택·동의</li><li class="on">2. 신청서 작성</li><li>3. 접수 완료</li></ol>

    <div class="info-box">
        <strong><c:out value="${afair.afairNm}"/></strong>
        처리기간 <c:out value="${afair.procPd}"/>일 (토·일·공휴일 제외)
    </div>

    <form:form modelAttribute="civilReqVO" name="civilReqVO" method="post" action="${pageContext.request.contextPath}/civil/req/submit.do" enctype="multipart/form-data">
        <form:hidden path="afairCode"/>
        <table class="tbl-form">
            <caption>민원 신청서</caption>
            <colgroup><col style="width:18%"><col></colgroup>
            <tbody>
            <tr><th scope="row"><label for="applcntNm">성명</label> <em class="req">*</em></th>
                <td><form:input path="applcntNm" id="applcntNm" maxlength="30" cssClass="w200"/></td></tr>
            <tr><th scope="row"><label for="applcntMbtlnum">휴대전화</label> <em class="req">*</em></th>
                <td><form:input path="applcntMbtlnum" id="applcntMbtlnum" maxlength="13" cssClass="w200" placeholder="01012345678"/>
                    <p class="help">접수·처리 결과를 문자로 알려 드립니다.</p></td></tr>
            <tr><th scope="row"><label for="applcntEmail">이메일</label></th>
                <td><form:input path="applcntEmail" id="applcntEmail" maxlength="100" cssClass="w300"/></td></tr>
            <tr><th scope="row">주소</th>
                <td><form:input path="zip" id="zip" readonly="true" cssClass="w100"/>
                    <a href="#" class="btn btn-sm" onclick="fn_addrPopup('zip', 'adres', 'detailAdres'); return false;">주소검색</a><br>
                    <form:input path="adres" id="adres" readonly="true" cssClass="w400"/>
                    <form:input path="detailAdres" id="detailAdres" maxlength="100" cssClass="w300" title="상세주소"/></td></tr>
            <tr><th scope="row"><label for="civilSj">제목</label> <em class="req">*</em></th>
                <td><form:input path="civilSj" id="civilSj" maxlength="200" cssClass="w-full"/></td></tr>
            <tr><th scope="row"><label for="civilCn">내용</label> <em class="req">*</em></th>
                <td><form:textarea path="civilCn" id="civilCn" rows="12" cssClass="w-full"/>
                    <p class="count"><span id="cnLen">0</span> / 4000</p></td></tr>
            <tr><th scope="row">공개여부</th>
                <td><label><form:radiobutton path="othbcAt" value="N"/> 비공개</label>
                    <label><form:radiobutton path="othbcAt" value="Y"/> 공개</label></td></tr>
            <tr><th scope="row">첨부파일</th>
                <td><div id="fileArea"><div class="file-row"><input type="file" name="file_1" title="첨부파일 1"></div></div>
                    <a href="#" class="btn btn-sm" onclick="fn_addFile(); return false;">추가</a>
                    <p class="help">hwp, pdf, 이미지, office 문서 / 파일당 10MB</p></td></tr>
            </tbody>
        </table>
        <div class="btn-area">
            <a href="<c:url value='/civil/req/reqAgree.do'/>" class="btn">이전</a>
            <button type="button" id="btnSubmit" class="btn btn-primary" onclick="fn_submit();">신청</button>
        </div>
    </form:form>
</div>
<%@ include file="/WEB-INF/jsp/cmm/include/footer.jsp" %>
</body>
</html>
