<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<%@ include file="/WEB-INF/jsp/cmm/include/head.jsp" %>
<script>
function fn_next() {
    var f = document.agreeForm;
    if (!$("input[name=afairCode]:checked").length) {
        alert("신청할 민원 사무를 선택하십시오.");
        return;
    }
    if (!$("#agre1").is(":checked") || !$("#agre2").is(":checked")) {
        alert("필수 동의 항목에 동의해 주십시오.");
        return;
    }
    f.agreAt.value = "Y";
    f.submit();
}
</script>
</head>
<body>
<%@ include file="/WEB-INF/jsp/cmm/include/header.jsp" %>
<div id="content" class="sub">
    <h2 class="tit">민원 신청</h2>
    <ol class="step"><li class="on">1. 사무 선택·동의</li><li>2. 신청서 작성</li><li>3. 접수 완료</li></ol>

    <form name="agreeForm" method="post" action="<c:url value='/civil/req/reqForm.do'/>">
        <input type="hidden" name="agreAt" value="">
        <div class="tbl-wrap">
            <table class="tbl-list">
                <caption>신청 가능 민원 사무</caption>
                <colgroup><col style="width:8%"><col><col style="width:15%"><col style="width:20%"><col style="width:12%"></colgroup>
                <thead><tr><th scope="col">선택</th><th scope="col">민원 사무</th><th scope="col">처리기간</th><th scope="col">담당부서</th><th scope="col">수수료</th></tr></thead>
                <tbody>
                <c:forEach var="a" items="${afairList}">
                    <tr>
                        <td><input type="radio" name="afairCode" value="${a.afairCode}" title="${a.afairNm} 선택"></td>
                        <td class="al"><c:out value="${a.afairNm}"/></td>
                        <td><c:out value="${a.procPd}"/><c:choose><c:when test="${a.procPdSe eq 'H'}">시간</c:when><c:otherwise>일</c:otherwise></c:choose></td>
                        <td><c:out value="${a.chrgDeptNm}"/></td>
                        <td><c:choose><c:when test="${a.feeAmt > 0}"><fmt:formatNumber value="${a.feeAmt}"/>원</c:when><c:otherwise>없음</c:otherwise></c:choose></td>
                    </tr>
                </c:forEach>
                </tbody>
            </table>
        </div>

        <div class="agree-box">
            <h3>개인정보 수집·이용 동의 (필수)</h3>
            <div class="scroll">
                1. 수집 항목: 성명, 휴대전화, 이메일, 주소<br>
                2. 수집 목적: 민원 접수 및 처리 결과 통지<br>
                3. 보유 기간: 민원 처리 완료 후 5년 (공공기록물 관리에 관한 법률)<br>
                4. 동의를 거부할 수 있으나, 거부 시 온라인 민원 신청이 제한됩니다.
            </div>
            <label><input type="checkbox" id="agre1"> 동의합니다.</label>
        </div>
        <div class="agree-box">
            <h3>민원 처리 정보 제3자 제공 동의 (필수)</h3>
            <div class="scroll">
                이송이 필요한 경우 소관 기관에 신청 내용과 연락처를 제공합니다.
            </div>
            <label><input type="checkbox" id="agre2"> 동의합니다.</label>
        </div>
        <div class="btn-area">
            <a href="#" class="btn btn-primary" onclick="fn_next(); return false;">다음</a>
        </div>
    </form>
</div>
<%@ include file="/WEB-INF/jsp/cmm/include/footer.jsp" %>
</body>
</html>
