<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>통합 민원 포털 관리자</title>
<link href="<c:url value='/css/mng/login.css'/>" rel="stylesheet" type="text/css">
</head>
<body class="mng_login">
<div class="login_box">
    <h1>통합 민원 포털 관리자</h1>
    <c:if test="${not empty loginMessage}"><p class="err"><spring:message code="${loginMessage}" arguments="5"/></p></c:if>
    <form name="loginForm" method="post" action="<c:url value='/sec/login/actionMngLogin.do'/>">
        <input type="text" name="id" placeholder="직원 아이디" title="아이디"><br>
        <input type="password" name="password" placeholder="비밀번호" title="비밀번호"><br>
        <input type="submit" value="로그인">
    </form>
    <p class="notice">관리자 화면 접속 기록은 개인정보 보호법에 따라 보관됩니다.</p>
</div>
</body>
</html>
