<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<script>
<% if ("OK".equals(request.getAttribute("result"))) { %>
    opener.fn_certDone();
<% } else { %>
    alert("본인확인에 실패했습니다. 다시 시도해 주십시오.");
<% } %>
    self.close();
</script>
