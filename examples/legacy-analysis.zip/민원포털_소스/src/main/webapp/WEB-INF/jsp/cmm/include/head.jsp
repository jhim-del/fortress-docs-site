<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>통합 민원 포털</title>
<link rel="stylesheet" href="<c:url value='/css/portal/common.css'/>">
<link rel="stylesheet" href="<c:url value='/css/portal/layout.css'/>">
<script src="<c:url value='/js/lib/jquery-1.12.4.min.js'/>"></script>
<script src="<c:url value='/js/portal/common.js'/>"></script>
