<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<footer id="footer">
    <ul class="policy">
        <li><a href="#" onclick="fn_open_policy('privacy'); return false;"><strong>개인정보처리방침</strong></a></li>
        <li><a href="#" onclick="fn_open_policy('terms'); return false;">이용약관</a></li>
        <li><a href="#" onclick="fn_open_policy('email'); return false;">이메일무단수집거부</a></li>
    </ul>
    <p class="copy">Copyright &copy; 통합 민원 포털. All rights reserved.</p>
</footer>
