<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<%@ include file="/WEB-INF/jsp/cmm/include/head.jsp" %>
<script>
<c:if test="${not empty message}">alert("${message}");</c:if>
function fn_cert() {
    if (!$("#agreTerms").is(":checked") || !$("#agrePrivacy").is(":checked")) {
        alert("필수 약관에 동의해 주십시오.");
        return;
    }
    window.open("<c:url value='/mbr/cert/certReq.do'/>", "certPop", "width=500,height=550,scrollbars=yes");
}
/* 본인확인 팝업에서 호출 */
function fn_certDone() {
    var f = document.agreForm;
    f.emailAgre.value = $("#agreEmail").is(":checked") ? "Y" : "N";
    f.smsAgre.value = $("#agreSms").is(":checked") ? "Y" : "N";
    f.submit();
}
</script>
</head>
<body>
<%@ include file="/WEB-INF/jsp/cmm/include/header.jsp" %>
<div id="content" class="sub">
    <h2 class="tit">회원가입</h2>
    <ol class="step"><li class="on">약관 동의·본인확인</li><li>정보 입력</li><li>가입 완료</li></ol>
    <div class="terms">
        <h3>이용약관 (필수)</h3>
        <div class="scroll"><jsp:include page="/WEB-INF/jsp/portal/mbr/inc/terms.jsp"/></div>
        <label><input type="checkbox" id="agreTerms"> 이용약관에 동의합니다.</label>
    </div>
    <div class="terms">
        <h3>개인정보 수집·이용 (필수)</h3>
        <div class="scroll">
            수집 항목: 아이디, 비밀번호, 이름, 생년월일, 성별, 휴대전화, 이메일, 주소, 연계정보(CI)<br>
            이용 목적: 회원 식별, 민원·예약 서비스 제공, 공지 전달<br>
            보유 기간: 회원 탈퇴 시까지 (1년 미이용 시 휴면 전환 후 분리 보관)
        </div>
        <label><input type="checkbox" id="agrePrivacy"> 동의합니다.</label>
    </div>
    <div class="terms optional">
        <label><input type="checkbox" id="agreEmail"> (선택) 이메일 수신 동의</label>
        <label><input type="checkbox" id="agreSms"> (선택) 문자 수신 동의</label>
    </div>
    <form name="agreForm" method="post" action="<c:url value='/mbr/join/joinForm.do'/>">
        <input type="hidden" name="emailAgre">
        <input type="hidden" name="smsAgre">
    </form>
    <div class="btn_area"><a href="#" class="btn btn-primary" onclick="fn_cert(); return false;">휴대폰 본인확인</a></div>
</div>
<%@ include file="/WEB-INF/jsp/cmm/include/footer.jsp" %>
</body>
</html>
