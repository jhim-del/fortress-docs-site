<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>담당자 배정 설정</title>
<link rel="stylesheet" href="<c:url value='/css/mng/mng.css'/>">
<script src="<c:url value='/js/lib/jquery-1.12.4.min.js'/>"></script>
<script src="<c:url value='/js/portal/common.js'/>"></script>
<script>
var deptCd = "${deptCd}";

function fn_toggle(chargerId, yn) {
    Ajax.post("<c:url value='/mng/assign/conf/toggleAsgn.do'/>", {deptCd: deptCd, chargerId: chargerId, asgnYn: yn}, function() {
        location.reload();
    });
}

function fn_move(btn, dir) {
    var tr = $(btn).closest("tr");
    if (dir < 0) tr.prev().before(tr); else tr.next().after(tr);
}

function fn_saveOrdr() {
    var list = [];
    $("#chargerTbl tbody tr").each(function(i) {
        list.push({deptCd: deptCd, chargerId: $(this).data("id"), asgnOrdr: i + 1});
    });
    $.ajax({
        url: "<c:url value='/mng/assign/conf/saveOrdr.do'/>",
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify(list),
        success: function() { alert("순번을 저장했습니다."); }
    });
}

function fn_addCharger() {
    var id = $("#newChargerId").val();
    if (!id) return;
    Ajax.post("<c:url value='/mng/assign/conf/saveCharger.do'/>", {deptCd: deptCd, chargerId: id}, function() { location.reload(); });
}
</script>
</head>
<body>
<div id="wrap">
<jsp:include page="/WEB-INF/jsp/mng/include/mngLeft.jsp"/>
<div id="container" class="cols">
    <h2>담당자 배정 설정</h2>
    <p class="guide">민원 접수 시 부서별 순번에 따라 자동 배정됩니다. 휴가·출장 중인 담당자는 자동으로 제외됩니다.</p>

    <div class="col-left">
        <table class="tbl-list">
            <thead><tr><th>부서</th><th>담당자</th><th>배정중</th><th>수동대기</th></tr></thead>
            <tbody>
            <c:forEach var="d" items="${deptSttusList}">
                <tr class="${d.deptCode eq deptCd ? 'on' : ''}">
                    <td class="al"><a href="?deptCd=${d.deptCode}"><c:out value="${d.deptNm}"/></a></td>
                    <td>${d.chargerCnt}</td>
                    <td>${d.activeCnt}</td>
                    <td><c:if test="${d.waitCnt > 0}"><strong class="red">${d.waitCnt}</strong></c:if></td>
                </tr>
            </c:forEach>
            </tbody>
        </table>
    </div>

    <div class="col-right">
        <c:if test="${not empty deptCd}">
        <table class="tbl-list" id="chargerTbl">
            <thead><tr><th>순번</th><th>담당자</th><th>직위</th><th>처리중</th><th>최근 배정</th><th>부재</th><th>자동배정</th><th>이동</th></tr></thead>
            <tbody>
            <c:forEach var="c" items="${chargerList}" varStatus="s">
                <tr data-id="${c.chargerId}">
                    <td>${s.count}</td>
                    <td><c:out value="${c.userNm}"/></td>
                    <td><c:out value="${c.ofcpsNm}"/></td>
                    <td>${c.ingCnt}</td>
                    <td>${c.lastAsgnDt}</td>
                    <td>${c.absnceYn eq 'Y' ? '부재' : ''}</td>
                    <td><c:choose>
                        <c:when test="${c.asgnYn eq 'Y'}"><button type="button" onclick="fn_toggle('${c.chargerId}','N')">해제</button></c:when>
                        <c:otherwise><button type="button" onclick="fn_toggle('${c.chargerId}','Y')">지정</button></c:otherwise>
                    </c:choose></td>
                    <td><button type="button" onclick="fn_move(this,-1)">▲</button><button type="button" onclick="fn_move(this,1)">▼</button></td>
                </tr>
            </c:forEach>
            </tbody>
        </table>
        <div class="btn-area">
            <input type="text" id="newChargerId" placeholder="직원 아이디">
            <button type="button" class="btn" onclick="fn_addCharger()">담당자 추가</button>
            <button type="button" class="btn btn-primary" onclick="fn_saveOrdr()">순번 저장</button>
        </div>
        </c:if>
    </div>
</div>
</div>
</body>
</html>
