<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8" isErrorPage="true"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>오류</title>
<link rel="stylesheet" href="<c:url value='/css/portal/common.css'/>">
</head>
<body>
<div class="error_wrap">
    <h2>요청을 처리하는 중 문제가 발생했습니다.</h2>
    <p>잠시 후 다시 시도해 주십시오. 문제가 계속되면 고객센터로 문의해 주십시오.</p>
    <a href="<c:url value='/main.do'/>" class="btn">메인으로</a>
</div>
</body>
</html>
