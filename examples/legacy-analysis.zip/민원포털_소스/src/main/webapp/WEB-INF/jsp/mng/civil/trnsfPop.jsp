<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>민원 이송</title>
<link rel="stylesheet" href="<c:url value='/css/mng/pop.css'/>">
<script>
function fn_save() {
    var f = document.trnsfForm;
    if (f.trnsfDeptCode.value == "") { alert("이송 부서를 선택하십시오."); return; }
    if (f.trnsfResn.value.length < 5) { alert("이송 사유를 5자 이상 입력하십시오."); return; }
    if (confirm("이송하시겠습니까? 처리기한이 이송일 기준으로 다시 계산됩니다.")) f.submit();
}
</script>
</head>
<body class="pop">
<h1>민원 이송</h1>
<form name="trnsfForm" method="post" action="<c:url value='/mng/civil/proc/trnsf.do'/>">
    <input type="hidden" name="civilRcptNo" value="${civilRcptNo}">
    <table class="board_view">
        <tr><th>접수번호</th><td>${civilRcptNo}</td></tr>
        <tr><th>이송 부서</th><td>
            <select name="trnsfDeptCode">
                <option value="">선택</option>
                <c:forEach var="d" items="${deptList}">
                <option value="${d.deptCode}"><c:out value="${d.deptNm}"/></option>
                </c:forEach>
            </select></td></tr>
        <tr><th>이송 사유</th><td><textarea name="trnsfResn" rows="5" cols="45"></textarea></td></tr>
    </table>
    <div class="btn_area"><a href="#" class="btn_b" onclick="fn_save(); return false;">이송</a> <a href="#" class="btn_b" onclick="self.close(); return false;">닫기</a></div>
</form>
</body>
</html>
