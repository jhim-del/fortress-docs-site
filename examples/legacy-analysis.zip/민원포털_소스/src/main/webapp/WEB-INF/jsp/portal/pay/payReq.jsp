<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>결제</title>
</head>
<body onload="document.pgForm.submit();">
<p style="text-align:center;margin-top:80px">결제 화면으로 이동합니다. 잠시만 기다려 주십시오.</p>
<form name="pgForm" method="post" action="${pgFormUrl}" accept-charset="UTF-8">
    <c:forEach var="e" items="${pgParams}">
    <input type="hidden" name="${e.key}" value="<c:out value='${e.value}'/>">
    </c:forEach>
</form>
</body>
</html>
