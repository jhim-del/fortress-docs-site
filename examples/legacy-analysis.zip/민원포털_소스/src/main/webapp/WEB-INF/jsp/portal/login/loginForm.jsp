<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<%@ include file="/WEB-INF/jsp/cmm/include/head.jsp" %>
<script>
<c:if test="${not empty loginMessage}">
alert("<spring:message code='${loginMessage}' arguments='5'/>");
</c:if>
<c:if test="${param.msg eq 'pwChanged'}">alert("비밀번호가 변경되었습니다. 다시 로그인해 주십시오.");</c:if>
function fn_login() {
    var f = document.loginForm;
    if (f.id.value == "") { alert("아이디를 입력하십시오."); f.id.focus(); return false; }
    if (f.password.value == "") { alert("비밀번호를 입력하십시오."); f.password.focus(); return false; }
    if ($("#saveId").is(":checked")) setCookie("saveId", f.id.value, 30); else setCookie("saveId", "", -1);
    return true;
}
$(function() {
    var s = getCookie("saveId");
    if (s) { document.loginForm.id.value = s; $("#saveId").prop("checked", true); }
});
</script>
</head>
<body>
<%@ include file="/WEB-INF/jsp/cmm/include/header.jsp" %>
<div id="content" class="sub login">
    <h2 class="tit">로그인</h2>
    <form name="loginForm" method="post" action="<c:url value='/sec/login/actionLogin.do'/>" onsubmit="return fn_login();">
        <input type="hidden" name="returnUrl" value="<c:out value='${returnUrl}'/>">
        <fieldset>
            <legend>로그인</legend>
            <input type="text" name="id" maxlength="20" placeholder="아이디" title="아이디">
            <input type="password" name="password" maxlength="20" placeholder="비밀번호" title="비밀번호">
            <label><input type="checkbox" id="saveId"> 아이디 저장</label>
            <button type="submit" class="btn btn-primary">로그인</button>
        </fieldset>
    </form>
    <ul class="links">
        <li><a href="<c:url value='/mbr/join/joinAgree.do'/>">회원가입</a></li>
        <li><a href="<c:url value='/mbr/find/idFind.do'/>">아이디 찾기</a></li>
        <li><a href="<c:url value='/mbr/find/pwFind.do'/>">비밀번호 찾기</a></li>
    </ul>
</div>
<%@ include file="/WEB-INF/jsp/cmm/include/footer.jsp" %>
</body>
</html>
