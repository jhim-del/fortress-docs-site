<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<%@ include file="/WEB-INF/jsp/cmm/include/head.jsp" %>
<script>
function fn_delete() {
    if (confirm("<spring:message code='common.delete.msg'/>")) {
        document.frm.action = "<c:url value='/bbs/wrt/nttDelete.do'/>";
        document.frm.submit();
    }
}
</script>
</head>
<body>
<%@ include file="/WEB-INF/jsp/cmm/include/header.jsp" %>
<div id="content" class="sub">
    <h2 class="tit"><c:out value="${result.bbsNm}"/></h2>
    <div class="board_view">
        <h3 class="sj"><c:out value="${result.nttSj}"/></h3>
        <ul class="info">
            <li>작성자 <c:out value="${result.ntcrNm}"/></li>
            <li>작성일 <c:out value="${result.frstRegistPnttm}"/></li>
            <li>조회 <c:out value="${result.rdcnt}"/></li>
        </ul>
        <div class="cn"><c:out value="${fn:replace(result.nttCn, crlf, '<br>')}" escapeXml="false"/></div>
        <c:if test="${not empty fileList}">
        <dl class="file">
            <dt>첨부파일</dt>
            <dd><c:forEach var="f" items="${fileList}">
                <a href="<c:url value='/cmm/fms/FileDown.do?atchFileId=${f.atchFileId}&fileSn=${f.fileSn}'/>"><c:out value="${f.orignlFileNm}"/></a>
                (<c:out value="${f.fileMg}"/> byte)<br>
            </c:forEach></dd>
        </dl>
        </c:if>
    </div>
    <form name="frm" method="post">
        <input type="hidden" name="bbsId" value="${result.bbsId}">
        <input type="hidden" name="nttId" value="${result.nttId}">
    </form>
    <div class="btn_area right">
        <c:if test="${result.replyPosblAt eq 'Y' and not empty sessionScope.loginVO}">
            <a href="<c:url value='/bbs/wrt/replyForm.do?bbsId=${result.bbsId}&nttId=${result.nttId}'/>" class="btn">답글</a>
        </c:if>
        <c:if test="${sessionScope.loginVO.id eq result.ntcrId}">
            <a href="<c:url value='/bbs/wrt/nttForm.do?bbsId=${result.bbsId}&nttId=${result.nttId}'/>" class="btn">수정</a>
            <a href="#" class="btn" onclick="fn_delete(); return false;">삭제</a>
        </c:if>
        <a href="<c:url value='/bbs/inq/nttList.do?bbsId=${result.bbsId}'/>" class="btn btn-primary">목록</a>
    </div>
</div>
<%@ include file="/WEB-INF/jsp/cmm/include/footer.jsp" %>
</body>
</html>
