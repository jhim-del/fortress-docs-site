<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<%@ include file="/WEB-INF/jsp/cmm/include/head.jsp" %>
<script>
function fn_cancel(resveId) {
    $.getJSON("<c:url value='/rsv/apply/pnlty.do'/>", {resveId: resveId}, function(d) {
        var msg = d.pnltyAmt > 0 ? "취소 위약금 " + numberWithCommas(d.pnltyAmt) + "원이 발생합니다. 취소하시겠습니까?" : "예약을 취소하시겠습니까?";
        if (!confirm(msg)) return;
        var f = document.cancelForm;
        f.resveId.value = resveId;
        f.submit();
    });
}
</script>
</head>
<body>
<%@ include file="/WEB-INF/jsp/cmm/include/header.jsp" %>
<div id="content" class="sub">
    <h2 class="tit">나의 예약</h2>
    <div class="info_box">
        <strong>취소 안내</strong>
        <ul>
            <li>이용일 3일 전까지: 무료 취소</li>
            <li>이용일 2일 전 ~ 1일 전: 이용료의 30%</li>
            <li>이용 당일: 이용료의 50%</li>
            <li>입금전용계좌로 결제한 경우 취소 후 환불 계좌를 입력해야 환불됩니다.</li>
        </ul>
    </div>
    <table class="tbl_list">
        <thead><tr><th>시설</th><th>이용일</th><th>시간</th><th>인원</th><th>이용료</th><th>상태</th><th>취소</th></tr></thead>
        <tbody>
        <c:forEach var="r" items="${resultList}">
        <tr>
            <td><c:out value="${r.fcltyNm}"/></td>
            <td>${fn:substring(r.resveDe,0,4)}.${fn:substring(r.resveDe,4,6)}.${fn:substring(r.resveDe,6,8)}</td>
            <td>${fn:substring(r.beginTime,0,2)}:${fn:substring(r.beginTime,2,4)}~${fn:substring(r.endTime,0,2)}:${fn:substring(r.endTime,2,4)}</td>
            <td>${r.nmpr}</td>
            <td>${r.chrgeAmt}<c:if test="${r.pnltyAmt > 0}"> (위약금 ${r.pnltyAmt})</c:if></td>
            <td>${r.resveSttusNm}</td>
            <td><c:if test="${r.canclPosblAt eq 'Y'}"><a href="#" class="btn_s" onclick="fn_cancel('${r.resveId}'); return false;">취소</a></c:if></td>
        </tr>
        </c:forEach>
        </tbody>
    </table>
    <form name="cancelForm" method="post" action="<c:url value='/rsv/apply/cancel.do'/>">
        <input type="hidden" name="resveId">
        <input type="hidden" name="canclResn" value="사용자 취소">
    </form>
</div>
<%@ include file="/WEB-INF/jsp/cmm/include/footer.jsp" %>
</body>
</html>
