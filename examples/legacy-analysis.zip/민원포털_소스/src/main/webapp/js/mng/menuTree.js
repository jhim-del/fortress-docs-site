/**
 * 메뉴 트리
 * 2019.07 ywk
 */
var MenuTree = (function() {
    function build(rows) {
        var byParent = {};
        $.each(rows, function(i, r) {
            (byParent[r.parent] = byParent[r.parent] || []).push(r);
        });
        function li(r) {
            var kids = byParent[r.id] || [];
            var html = '<li data-id="' + r.id + '" draggable="true"><span class="' + (r.useAt == "N" ? "off" : "") + '">' + r.text + '</span>';
            if (kids.length) {
                html += "<ul>";
                $.each(kids, function(i, k) { html += li(k); });
                html += "</ul>";
            }
            return html + "</li>";
        }
        var out = "";
        $.each(byParent[0] || [], function(i, r) { out += li(r); });
        return out;
    }

    return {
        load: function(url, sel, onSelect) {
            $.getJSON(url, function(d) {
                var $root = $(sel).html(build(d.tree));
                $root.on("click", "li > span", function(e) {
                    $root.find("span.on").removeClass("on");
                    $(this).addClass("on");
                    onSelect($(this).parent().data("id"));
                    e.stopPropagation();
                });
            });
        }
    };
})();
