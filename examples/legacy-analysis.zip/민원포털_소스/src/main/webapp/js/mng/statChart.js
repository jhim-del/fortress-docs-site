/**
 * 통계 막대 그래프 (외부 라이브러리 반입 불가로 canvas 직접 그림)
 * 2019.11 jdh
 */
var StatChart = {
    bar: function(canvasId, rows, series) {
        var cv = document.getElementById(canvasId);
        if (!cv || !cv.getContext || rows.length == 0) return;
        var ctx = cv.getContext("2d"), W = cv.width, H = cv.height;
        var padL = 50, padB = 40, padT = 30, plotW = W - padL - 10, plotH = H - padB - padT;
        var max = 0, i, j;
        for (i = 0; i < rows.length; i++)
            for (j = 0; j < series.length; j++) max = Math.max(max, rows[i][series[j].key]);
        max = max == 0 ? 10 : Math.ceil(max * 1.1);

        ctx.clearRect(0, 0, W, H);
        ctx.font = "12px 'Malgun Gothic'";
        ctx.strokeStyle = "#ddd";
        ctx.fillStyle = "#666";
        for (i = 0; i <= 5; i++) {
            var y = padT + plotH - plotH * i / 5;
            ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(W - 10, y); ctx.stroke();
            ctx.fillText(Math.round(max * i / 5), 5, y + 4);
        }

        var groupW = plotW / rows.length, barW = Math.min(18, (groupW - 10) / series.length);
        for (i = 0; i < rows.length; i++) {
            var gx = padL + groupW * i + (groupW - barW * series.length) / 2;
            for (j = 0; j < series.length; j++) {
                var v = rows[i][series[j].key], h = plotH * v / max;
                ctx.fillStyle = series[j].color;
                ctx.fillRect(gx + barW * j, padT + plotH - h, barW - 2, h);
            }
            ctx.fillStyle = "#333";
            var lb = rows[i].label.length > 6 ? rows[i].label.substr(0, 6) + ".." : rows[i].label;
            ctx.fillText(lb, padL + groupW * i + 4, H - padB + 16);
        }

        for (j = 0; j < series.length; j++) {
            ctx.fillStyle = series[j].color;
            ctx.fillRect(padL + j * 90, 8, 12, 12);
            ctx.fillStyle = "#333";
            ctx.fillText(series[j].name, padL + j * 90 + 16, 18);
        }
    }
};
