/**
 * 시설 예약 달력
 * 2016.05 lsy / 2019.08 jdh 시간 칸 다중 선택
 */
var RsvCalendar = (function() {
    var cfg, selDe, selSlots = [];

    function pad(n) { return n < 10 ? "0" + n : "" + n; }

    function render() {
        var y = parseInt(cfg.ym.substr(0, 4), 10), m = parseInt(cfg.ym.substr(4, 2), 10) - 1;
        var first = new Date(y, m, 1).getDay();
        var today = new Date(), todayStr = today.getFullYear() + pad(today.getMonth() + 1) + pad(today.getDate());
        var html = "<tr>", col = 0, i;
        for (i = 0; i < first; i++, col++) html += "<td></td>";
        for (i = 0; i < DAYS.length; i++, col++) {
            if (col > 0 && col % 7 == 0) html += "</tr><tr>";
            var d = DAYS[i], cls = [], label = parseInt(d.de.substr(6, 2), 10);
            if (col % 7 == 0 || d.rest == "Y") cls.push("sun");
            if (col % 7 == 6) cls.push("sat");
            if (d.de < todayStr) cls.push("past");
            html += '<td class="' + cls.join(" ") + '" data-de="' + d.de + '">'
                  + '<span class="day">' + label + '</span>'
                  + (d.rest == "Y" ? '<em>' + d.restNm + '</em>' : '')
                  + (d.cnt > 0 ? '<span class="cnt">예약 ' + d.cnt + '</span>' : '')
                  + '</td>';
        }
        while (col % 7 != 0) { html += "<td></td>"; col++; }
        html += "</tr>";
        $("#calTbl tbody").html(html);
        $("#calTbl td[data-de]").not(".past").on("click", function() { pick($(this).data("de")); });
    }

    function pick(de) {
        selDe = String(de);
        selSlots = [];
        $("#calTbl td").removeClass("on");
        $('#calTbl td[data-de="' + selDe + '"]').addClass("on");
        $("#selDe").text(selDe.substr(0, 4) + "." + selDe.substr(4, 2) + "." + selDe.substr(6, 2));
        $.getJSON(cfg.ctx + "/rsv/apply/timeSlot.do", {fcltyId: cfg.fcltyId, resveDe: selDe}, function(data) {
            var li = "";
            $.each(data.slotList, function(i, s) {
                var t = s.beginTime.substr(0, 2) + ":" + s.beginTime.substr(2, 2) + "~" + s.endTime.substr(0, 2) + ":" + s.endTime.substr(2, 2);
                li += s.posblAt == "Y"
                    ? '<li><label><input type="checkbox" value="' + s.beginTime + '|' + s.endTime + '"> ' + t + '</label></li>'
                    : '<li class="off">' + t + ' (예약됨)</li>';
            });
            $("#slotList").html(li || "<li>예약 가능한 시간이 없습니다.</li>");
            $("#slotArea").show();
        });
    }

    /* 연속된 칸만 한 번에 신청 가능 */
    function apply() {
        if (!cfg.loggedIn) {
            alert("로그인 후 예약할 수 있습니다.");
            location.href = cfg.ctx + "/sec/login/loginForm.do?returnUrl=" + encodeURIComponent(location.pathname + location.search);
            return;
        }
        var arr = $("#slotList input:checked").map(function() { return this.value.split("|"); }).get();
        if (arr.length == 0) { alert("시간을 선택하십시오."); return; }
        for (var i = 2; i < arr.length; i += 2) {
            if (arr[i] != arr[i - 1]) { alert("연속된 시간만 선택할 수 있습니다."); return; }
        }
        var f = document.applyForm;
        f.resveDe.value = selDe;
        f.beginTime.value = arr[0];
        f.endTime.value = arr[arr.length - 1];
        f.submit();
    }

    function move(diff) {
        var y = parseInt(cfg.ym.substr(0, 4), 10), m = parseInt(cfg.ym.substr(4, 2), 10) - 1 + diff;
        var d = new Date(y, m, 1);
        document.calForm.searchYm.value = d.getFullYear() + pad(d.getMonth() + 1);
        document.calForm.submit();
    }

    return {
        init: function(c, hasData) { cfg = c; if (hasData) render(); },
        move: move,
        apply: apply
    };
})();
