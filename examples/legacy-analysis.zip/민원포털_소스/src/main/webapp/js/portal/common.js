/**
 * 통합 민원 포털 공통 스크립트
 * 2016.04 kjh 최초 / 2019.07 ywk ajax 공통 추가
 */

/* 페이지 이동 (ui:pagination jsFunction) */
function fn_egov_link_page(pageNo) {
    var f = document.listForm;
    f.pageIndex.value = pageNo;
    f.submit();
}

function fn_egov_search() {
    var f = document.listForm;
    f.pageIndex.value = 1;
    f.submit();
}

function isEmpty(v) {
    return v == null || $.trim(v) == "";
}

function numberWithCommas(x) {
    return String(x).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function onlyNumber(obj) {
    obj.value = obj.value.replace(/[^0-9]/g, "");
}

/* yyyyMMdd 유효성 */
function isValidDate(s) {
    if (!/^\d{8}$/.test(s)) return false;
    var y = parseInt(s.substr(0, 4), 10), m = parseInt(s.substr(4, 2), 10) - 1, d = parseInt(s.substr(6, 2), 10);
    var dt = new Date(y, m, d);
    return dt.getFullYear() == y && dt.getMonth() == m && dt.getDate() == d;
}

function getCookie(name) {
    var arr = document.cookie.split("; ");
    for (var i = 0; i < arr.length; i++) {
        var kv = arr[i].split("=");
        if (kv[0] == name) return unescape(kv[1]);
    }
    return "";
}

function setCookie(name, value, days) {
    var d = new Date();
    d.setDate(d.getDate() + days);
    document.cookie = name + "=" + escape(value) + "; path=/; expires=" + d.toGMTString() + ";";
}

function fn_open_policy(type) {
    window.open("/cmm/policy.do?type=" + type, "policy", "width=720,height=680,scrollbars=yes");
}

/* 2019 고도화: ajax 공통 (401 이면 로그인으로) */
var Ajax = {
    post: function(url, data, success) {
        $.ajax({
            url: url,
            type: "POST",
            data: data,
            dataType: "json",
            success: success,
            error: function(xhr) {
                if (xhr.status == 401) {
                    alert("로그인이 필요합니다.");
                    location.href = "/sec/login/loginForm.do?returnUrl=" + encodeURIComponent(location.pathname);
                    return;
                }
                alert("처리 중 오류가 발생했습니다.");
            }
        });
    },
    get: function(url, data, success) {
        $.getJSON(url, data, success);
    }
};

// 2016 구축 당시 IE8 대응
// if (!Array.prototype.indexOf) {
//     Array.prototype.indexOf = function(o) { for (var i = 0; i < this.length; i++) if (this[i] === o) return i; return -1; };
// }
