/*
 * 주소 검색: 기관 공통 주소 검색 서비스(별도 시스템, 내부망) 팝업
 * 2016.05 lsy 자체 주소 DB 팝업 → 2019.08 ywk 기관 공통 서비스로 변경 (주소 DB 월 갱신 부담)
 */
var ADDR_SVC_URL = "http://10.1.2.15/addrsvc/popup.do";
var _addrTarget = {};

function fn_addrPopup(zipId, addrId, detailId) {
    _addrTarget = {zip: zipId, addr: addrId, detail: detailId};
    var ret = encodeURIComponent(location.protocol + "//" + location.host + "/cmm/addrCallback.jsp");
    window.open(ADDR_SVC_URL + "?returnUrl=" + ret + "&resultType=4", "addrPop", "width=570,height=520,scrollbars=yes,resizable=yes");
}

/* addrCallback.jsp 에서 호출 */
function fn_addrCallback(zip, roadAddr, detail) {
    document.getElementById(_addrTarget.zip).value = zip;
    document.getElementById(_addrTarget.addr).value = roadAddr;
    var d = document.getElementById(_addrTarget.detail);
    if (d) {
        d.value = detail || "";
        d.focus();
    }
}
