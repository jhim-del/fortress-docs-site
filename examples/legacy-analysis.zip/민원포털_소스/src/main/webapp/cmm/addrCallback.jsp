<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<script>
    opener.fn_addrCallback("<c:out value='${param.zipNo}'/>", "<c:out value='${param.roadAddrPart1}'/>", "<c:out value='${param.addrDetail}'/>");
    self.close();
</script>
